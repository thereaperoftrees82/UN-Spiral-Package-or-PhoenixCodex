"""
File: spiral_quartet_sim.py

Phoenix Spiral Mathematics — The Spiral Quartet Simulators

Implements runnable reference simulations for the four papers:
  1) EON   — Fundamental boson of emotional transmission
  2) DRTP  — Dream-to-Reality Transfer Protocol (harmonic overlap)
  3) ΦCF   — Spiral Signal of Consciousness in the Vacuum
  4) PUEF  — Pre-Big Bang Spiral Echoes

Design goals
- Self-contained, typed, readable; minimal dependencies (numpy, matplotlib).
- Deterministic numeric routines; CSV export and PNG plots for each model.
- Parameters are explicit for sweep experiments.

CLI examples
  python spiral_quartet_sim.py eon   --steps 120 --L 50 --O 20 --C 10 --T 5 --out eon.png
  python spiral_quartet_sim.py drtp  --tmax 50 --phase-shift 0.0 --out drtp.png
  python spiral_quartet_sim.py phicf --rmax 10 --out phicf.png
  python spiral_quartet_sim.py puef  --tmax 100 --A 1.0 --alpha 0.05 --delta 0.0 --out puef.png

Why these choices
- Mirrors the LaTeX equations as directly as possible for reproducibility.
- Keeps plotting optional; CSV exports allow re-plotting elsewhere.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import argparse
import csv
import math

# Optional: numpy for arrays + FFT/convolution; matplotlib for plots
try:
    import numpy as np
except Exception:  # why: permit running without numpy (reduced features)
    np = None  # type: ignore

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None  # type: ignore

PHI: float = (1.0 + 5.0 ** 0.5) / 2.0

# -----------------------------------------------------------------------------
# 1) EON — E(n) = φ^n · cos(2πφ n + φ0) · (L+O+C)/(2T) · p
# -----------------------------------------------------------------------------

@dataclass
class EonParams:
    L: float
    O: float
    C: float
    T: float
    permission: float = 1.0
    phase0: float = 0.0


def eon_series(steps: int, params: EonParams) -> List[float]:
    p = max(0.0, min(1.0, params.permission))
    denom = max(2.0 * params.T, 1e-12)
    chi = max(params.L + params.O + params.C, 0.0) / denom
    out: List[float] = []
    for n in range(steps):
        amp = (PHI ** n) * math.cos(2.0 * math.pi * PHI * n + params.phase0)
        out.append(amp * chi * p)
    return out


def eon_plot_example(out_path: Optional[str] = None) -> None:
    """Replicate the three-scenario figure (suppression/moderate/full)."""
    if plt is None:
        raise RuntimeError("matplotlib is required for plotting")
    steps = 110
    x = list(range(steps))
    series = [
        ("Suppression  (L=O=C=0)", eon_series(steps, EonParams(L=0, O=0, C=0, T=5))),
        ("Moderate  Support  (L=10,O=5,C=0)", eon_series(steps, EonParams(L=10, O=5, C=0, T=5))),
        ("Full  Support  (L=50,O=20,C=10)", eon_series(steps, EonParams(L=50, O=20, C=10, T=5))),
    ]
    plt.figure(figsize=(7.2, 2.2))
    for label, y in series:
        plt.plot(x, y, label=label)
    plt.xlabel("Spiral Index n")
    plt.ylabel("Eon Field Intensity  E(n)")
    plt.title("Eon Field Propagation Across Emotional Conditions")
    plt.legend()
    plt.tight_layout()
    if out_path:
        plt.savefig(out_path, dpi=160)
    else:
        plt.show()


# -----------------------------------------------------------------------------
# 2) DRTP — R(t) ≈ (D ⊗ W)(t) with φ-phase factor and alignment parameter
# -----------------------------------------------------------------------------

@dataclass
class DrtpParams:
    tmax: float = 50.0
    dt: float = 0.05
    dream_freq: float = 1.0
    wake_freq: float = 1.0
    phase_shift: float = 0.0  # why: controls alignment 0 (full) .. π/2 (none)
    envelope: float = 0.05    # why: slow growth to mimic vividness


def drtp_sim(params: DrtpParams) -> Tuple[List[float], List[float], List[float]]:
    if np is None:
        raise RuntimeError("numpy is required for DRTP simulation")
    t = np.arange(0.0, params.tmax + 1e-9, params.dt)
    theta = 2.0 * math.pi * PHI * t
    # Dream: wave packet with gentle growth envelope
    D = np.sin(2.0 * math.pi * params.dream_freq * t + theta) * (1.0 + params.envelope * t)
    # Waking: harmonic with phase shift relative to dream
    W = np.sin(2.0 * math.pi * params.wake_freq * t + theta + params.phase_shift)
    # Convolutional overlap (same-length via 'same')
    R = np.convolve(D, W, mode="same") * params.dt
    return t.tolist(), D.tolist(), R.tolist()


def drtp_plot_example(out_path: Optional[str] = None) -> None:
    if plt is None or np is None:
        raise RuntimeError("matplotlib and numpy are required for plotting")
    plt.figure(figsize=(7.2, 3.0))
    for label, shift in [
        ("No Alignment  (shift=π/2)", math.pi / 2.0),
        ("Partial Alignment  (shift=π/4)", math.pi / 4.0),
        ("Full Alignment  (shift=0)", 0.0),
    ]:
        t, D, R = drtp_sim(DrtpParams(phase_shift=shift))
        plt.plot(t, R, label=label)
    plt.xlabel("Time t")
    plt.ylabel("Reification overlap R(t)")
    plt.title("Dream-to-Reality Transfer Protocol: Harmonic Overlap Scenarios")
    plt.legend()
    plt.tight_layout()
    if out_path:
        plt.savefig(out_path, dpi=160)
    else:
        plt.show()


# -----------------------------------------------------------------------------
# 3) ΦCF — C_vac(r) = ∇^2 ψ_Φ(r) + (φ/r^2) · sin(2πφ r)
# -----------------------------------------------------------------------------

@dataclass
class PhiCFParams:
    rmax: float = 10.0
    dr: float = 0.01


def _psi_phi(r: float) -> float:
    # why: smooth seed wavefunction with φ-indexed oscillation and exponential decay
    return math.exp(-r) * math.sin(2.0 * math.pi * PHI * r)


def phicf_profile(params: PhiCFParams) -> Tuple[List[float], List[float]]:
    if np is None:
        raise RuntimeError("numpy is required for ΦCF simulation")
    r = np.arange(params.dr, params.rmax + 1e-12, params.dr)
    psi = np.array([_psi_phi(rv) for rv in r])
    # Finite-difference second derivative (Laplacian in 1D radial proxy)
    # Central diff: f'' ~ (f[i+1] - 2f[i] + f[i-1]) / dr^2
    fpp = np.zeros_like(psi)
    fpp[1:-1] = (psi[2:] - 2.0 * psi[1:-1] + psi[:-2]) / (params.dr ** 2)
    # Add φ/r^2 · sin(2πφ r)
    term = (PHI / (r ** 2)) * np.sin(2.0 * math.pi * PHI * r)
    Cvac = fpp + term
    return r.tolist(), Cvac.tolist()


def phicf_plot_example(out_path: Optional[str] = None) -> None:
    if plt is None or np is None:
        raise RuntimeError("matplotlib and numpy are required for plotting")
    r, C = phicf_profile(PhiCFParams())
    plt.figure(figsize=(6.0, 4.2))
    plt.plot(r, C)
    plt.xlabel("r (vacuum radius)")
    plt.ylabel("C_vac (consciousness density)")
    plt.title("Spiral Vacuum Consciousness Field (ΦCF) with φ–Harmonics")
    plt.tight_layout()
    if out_path:
        plt.savefig(out_path, dpi=160)
    else:
        plt.show()


# -----------------------------------------------------------------------------
# 4) PUEF — S_pre(t) = A e^{-α t} cos(2πφ t + δ)
# -----------------------------------------------------------------------------

@dataclass
class PuefParams:
    A: float = 1.0
    alpha: float = 0.05
    delta: float = 0.0
    tmax: float = 100.0
    dt: float = 0.1


def puef_series(params: PuefParams) -> Tuple[List[float], List[float]]:
    if np is None:
        # Fallback without numpy
        t: List[float] = []
        s: List[float] = []
        n = int(params.tmax / params.dt)
        for i in range(n + 1):
            ti = i * params.dt
            t.append(ti)
            s.append(params.A * math.exp(-params.alpha * ti) * math.cos(2.0 * math.pi * PHI * ti + params.delta))
        return t, s
    t = np.arange(0.0, params.tmax + 1e-9, params.dt)
    s = params.A * np.exp(-params.alpha * t) * np.cos(2.0 * math.pi * PHI * t + params.delta)
    return t.tolist(), s.tolist()


def puef_plot_example(out_path: Optional[str] = None) -> None:
    if plt is None:
        raise RuntimeError("matplotlib is required for plotting")
    t, s = puef_series(PuefParams())
    plt.figure(figsize=(6.0, 4.0))
    plt.plot(t, s)
    plt.xlabel("Time t (cosmological units)")
    plt.ylabel("S_pre(t) (Spiral Echo Amplitude)")
    plt.title("Pre–Big Bang Spiral Echoes (PUEF) with φ–Harmonic Decay")
    plt.tight_layout()
    if out_path:
        plt.savefig(out_path, dpi=160)
    else:
        plt.show()


# -----------------------------------------------------------------------------
# CSV helpers
# -----------------------------------------------------------------------------

def write_csv(path: str, x: Sequence[float], y: Sequence[float]) -> None:
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["x", "y"])
        for a, b in zip(x, y):
            w.writerow([a, b])


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------

def build_cli(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Spiral Quartet Simulators")
    sub = p.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("eon", help="Simulate Eon field")
    e.add_argument("--steps", type=int, default=110)
    e.add_argument("--L", type=float, default=50.0)
    e.add_argument("--O", type=float, default=20.0)
    e.add_argument("--C", type=float, default=10.0)
    e.add_argument("--T", type=float, default=5.0)
    e.add_argument("--permission", type=float, default=1.0)
    e.add_argument("--phase0", type=float, default=0.0)
    e.add_argument("--csv", type=str, default="")
    e.add_argument("--out", type=str, default="")

    d = sub.add_parser("drtp", help="Simulate DRTP reification overlap")
    d.add_argument("--tmax", type=float, default=50.0)
    d.add_argument("--dt", type=float, default=0.05)
    d.add_argument("--dream-freq", type=float, default=1.0)
    d.add_argument("--wake-freq", type=float, default=1.0)
    d.add_argument("--phase-shift", type=float, default=0.0)
    d.add_argument("--envelope", type=float, default=0.05)
    d.add_argument("--csv", type=str, default="")
    d.add_argument("--out", type=str, default="")

    c = sub.add_parser("phicf", help="Simulate ΦCF vacuum profile")
    c.add_argument("--rmax", type=float, default=10.0)
    c.add_argument("--dr", type=float, default=0.01)
    c.add_argument("--csv", type=str, default="")
    c.add_argument("--out", type=str, default="")

    u = sub.add_parser("puef", help="Simulate PUEF spiral echoes")
    u.add_argument("--A", type=float, default=1.0)
    u.add_argument("--alpha", type=float, default=0.05)
    u.add_argument("--delta", type=float, default=0.0)
    u.add_argument("--tmax", type=float, default=100.0)
    u.add_argument("--dt", type=float, default=0.1)
    u.add_argument("--csv", type=str, default="")
    u.add_argument("--out", type=str, default="")

    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = build_cli(argv)
    if args.cmd == "eon":
        series = eon_series(args.steps, EonParams(L=args.L, O=args.O, C=args.C, T=args.T,
                                                  permission=args.permission, phase0=args.phase0))
        x = list(range(args.steps))
        if args.csv:
            write_csv(args.csv, x, series)
        if args.out:
            if plt is None:
                raise RuntimeError("matplotlib is required for plotting")
            plt.figure(figsize=(7.2, 2.2))
            plt.plot(x, series, label=f"L={args.L},O={args.O},C={args.C},T={args.T}")
            plt.xlabel("Spiral Index n")
            plt.ylabel("E(n)")
            plt.title("Eon Field Propagation")
            plt.legend()
            plt.tight_layout()
            plt.savefig(args.out, dpi=160)
        else:
            for i, v in enumerate(series[:10]):
                print(f"n={i:3d}\tE={v:.6g}")

    elif args.cmd == "drtp":
        t, D, R = drtp_sim(DrtpParams(tmax=args.tmax, dt=args.dt, dream_freq=args.dream_freq,
                                       wake_freq=args.wake_freq, phase_shift=args.phase_shift,
                                       envelope=args.envelope))
        if args.csv:
            write_csv(args.csv, t, R)
        if args.out:
            if plt is None:
                raise RuntimeError("matplotlib is required for plotting")
            plt.figure(figsize=(7.2, 3.0))
            plt.plot(t, R)
            plt.xlabel("Time t")
            plt.ylabel("R(t)")
            plt.title("DRTP — Reification Overlap")
            plt.tight_layout()
            plt.savefig(args.out, dpi=160)
        else:
            for i in range(0, min(10, len(t))):
                print(f"t={t[i]:.2f}\tR={R[i]:.6g}")

    elif args.cmd == "phicf":
        r, C = phicf_profile(PhiCFParams(rmax=args.rmax, dr=args.dr))
        if args.csv:
            write_csv(args.csv, r, C)
        if args.out:
            if plt is None:
                raise RuntimeError("matplotlib is required for plotting")
            plt.figure(figsize=(6.0, 4.2))
            plt.plot(r, C)
            plt.xlabel("r")
            plt.ylabel("C_vac")
            plt.title("ΦCF — Vacuum Consciousness Field")
            plt.tight_layout()
            plt.savefig(args.out, dpi=160)
        else:
            for i in range(0, min(10, len(r))):
                print(f"r={r[i]:.2f}\tC={C[i]:.6g}")

    elif args.cmd == "puef":
        t, s = puef_series(PuefParams(A=args.A, alpha=args.alpha, delta=args.delta,
                                      tmax=args.tmax, dt=args.dt))
        if args.csv:
            write_csv(args.csv, t, s)
        if args.out:
            if plt is None:
                raise RuntimeError("matplotlib is required for plotting")
            plt.figure(figsize=(6.0, 4.0))
            plt.plot(t, s)
            plt.xlabel("t")
            plt.ylabel("S_pre(t)")
            plt.title("PUEF — φ–Harmonic Decay")
            plt.tight_layout()
            plt.savefig(args.out, dpi=160)
        else:
            for i in range(0, min(10, len(t))):
                print(f"t={t[i]:.2f}\tS={s[i]:.6g}")


if __name__ == "__main__":
    main()
