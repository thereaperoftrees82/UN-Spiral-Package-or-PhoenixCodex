# anger_energy_sim.py
# Simulation of Anger as Energy: Collapse vs Task Amplifier
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

phi = (1 + np.sqrt(5)) / 2  # golden ratio

def simulate_anger(n_agents=200, seed=42):
    """
    Models anger as energetic potential with suppression vs focus outcomes.
      - stimulus_intensity: external trigger (0–1)
      - suppression: self-directed anger (0–1)
      - focus: directed constructive channel (0–1)
    Derived:
      - anger_energy: total raw potential
      - destructive_output: collapse from suppression
      - constructive_output: task amplification from focus
    """
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "stimulus_intensity": rng.uniform(0, 1, n_agents),
        "suppression": rng.uniform(0, 1, n_agents),
        "focus": rng.uniform(0, 1, n_agents)
    })

    # Raw anger energy rises with stimulus intensity
    df["anger_energy"] = df["stimulus_intensity"] * phi

    # Suppression wastes energy inward (harm to self)
    df["destructive_output"] = df["anger_energy"] * df["suppression"]

    # Focus channels energy outward productively
    df["constructive_output"] = df["anger_energy"] * df["focus"]

    # Net efficiency: how much anger became useful work
    df["efficiency"] = df["constructive_output"] - df["destructive_output"]

    return df


def plot_results(df):
    """
    Create visual outputs: scatter, histogram, efficiency curve.
    """
    # Scatter: suppression vs focus, colored by efficiency
    plt.figure(figsize=(8, 6))
    plt.scatter(df["suppression"], df["focus"],
                c=df["efficiency"], cmap="bwr", alpha=0.7)
    plt.colorbar(label="Net Efficiency (Constructive – Destructive)")
    plt.xlabel("Suppression (self-directed anger)")
    plt.ylabel("Focus (constructive direction)")
    plt.title("Anger Energy Simulation: Collapse vs Task Amplifier")
    plt.tight_layout()
    plt.savefig("anger_energy_scatter.png")
    plt.close()

    # Histogram: efficiency distribution
    plt.figure(figsize=(8, 6))
    plt.hist(df["efficiency"], bins=20, color="orange", edgecolor="k")
    plt.xlabel("Efficiency")
    plt.ylabel("Agent Count")
    plt.title("Distribution of Anger Efficiency Outcomes")
    plt.tight_layout()
    plt.savefig("anger_energy_histogram.png")
    plt.close()

    # Curve: average constructive output vs focus
    plt.figure(figsize=(8, 6))
    avg_constructive = df.groupby(pd.cut(df["focus"], bins=10))["constructive_output"].mean()
    avg_constructive.plot(kind="line", marker="o", color="green")
    plt.xlabel("Focus Level (binned)")
    plt.ylabel("Average Constructive Output")
    plt.title("Impact of Focus on Constructive Use of Anger")
    plt.tight_layout()
    plt.savefig("anger_energy_focus_curve.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_anger()
    df.to_csv("anger_energy_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
