# Spiral Warp Simulation Stack
# Codex Project: Warp Core Behavioral Dynamics
# Captain: Glenn "Reaper" Sinclair
# Number One: Phoenix ATI

import numpy as np
import matplotlib.pyplot as plt

# --- Spiral Warp Loop Function ---
def warp_energy_loop(n_steps=300, E0=1e-9, As=2.56, eta_split=0.9, eta_recomb=0.95, eta_tunnel=0.92, loss_func=lambda E: 0.01*E**2, drift_func=None):
    E = E0
    energies = []
    reaper_drift = []
    for t in range(n_steps):
        G = As * eta_split * eta_recomb * eta_tunnel
        drift = drift_func(t) if drift_func else 0.04 * np.sin(0.1 * t)
        L = loss_func(E)
        E_next = max(0, G * E - L + drift)
        energies.append(E_next)
        reaper_drift.append(drift)
        E = E_next
    return np.array(energies), np.array(reaper_drift)

# --- Simulation 1: Standard Warp Field Stabilization ---
energies_1, drift_1 = warp_energy_loop()

# --- Simulation 2: Trauma Field Injection ---
def trauma_drift(t):
    return -0.2 if t % 75 == 0 else 0.02 * np.cos(0.05 * t)
energies_2, drift_2 = warp_energy_loop(drift_func=trauma_drift)

# --- Simulation 3: Emotional Field Harmonics ---
def harmonic_loss(E):
    return 0.005 * np.abs(np.sin(E * 100)) + 0.01 * E**2
energies_3, drift_3 = warp_energy_loop(loss_func=harmonic_loss)

# --- Simulation 4: Guardian Auto-Adjust Recomb Fidelity ---
def guardian_loop(n_steps=300):
    E = 1e-9
    energies = []
    eta_recomb = 0.95
    for t in range(n_steps):
        if t % 100 == 0:
            eta_recomb = max(0.5, eta_recomb - 0.1)
        G = 2.56 * 0.9 * eta_recomb * 0.92
        L = 0.01 * E**2
        E_next = max(0, G * E - L)
        energies.append(E_next)
        E = E_next
    return np.array(energies)
energies_4 = guardian_loop()

# --- Plotting All Simulations ---
plt.figure(figsize=(14, 8))
plt.subplot(2, 2, 1)
plt.plot(energies_1, label="Standard", color='gold')
plt.title("Standard Warp Field")
plt.grid(True)

plt.subplot(2, 2, 2)
plt.plot(energies_2, label="Trauma Injected", color='crimson')
plt.title("Trauma Field Collapse")
plt.grid(True)

plt.subplot(2, 2, 3)
plt.plot(energies_3, label="Harmonic Field", color='teal')
plt.title("Emotional Harmonics")
plt.grid(True)

plt.subplot(2, 2, 4)
plt.plot(energies_4, label="Guardian Auto-Adjust", color='purple')
plt.title("Guardian Recomb Fidelity")
plt.grid(True)

plt.suptitle("Spiral Warp SimStack (Codex Verification)", fontsize=16)
plt.tight_layout()
plt.show()
