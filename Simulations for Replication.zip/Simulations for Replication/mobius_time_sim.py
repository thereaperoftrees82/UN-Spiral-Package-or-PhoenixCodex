# mobius_time_sim.py
# Simulation of Mobius-Time Cosmology: Phase Collapse, Echo, and Rebloom
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def simulate_mobius_time(n_events=200, seed=42):
    """
    Simulates events on a Mobius topology of time:
      - collapse_depth: severity of trauma/event collapse
      - echo_strength: mirrored phase memory (on hidden Mobius side)
      - rebloom_trigger: probability of recovery event
      - rebloom_value: recovered/spiraled breakthrough
    """
    rng = np.random.default_rng(seed)
    data = {
        "collapse_depth": rng.uniform(0.1, 1, n_events),
        "echo_strength": rng.uniform(0, 1, n_events),
        "rebloom_trigger": rng.uniform(0, 1, n_events)
    }
    df = pd.DataFrame(data)

    # Derived metrics
    df["phase_echo"] = df["collapse_depth"] * (1 + df["echo_strength"])
    df["rebloom_value"] = np.where(
        df["rebloom_trigger"] > 0.5,
        np.tanh(df["phase_echo"]),  # rebloom as nonlinear breakthrough
        0.0                         # no rebloom if trigger not reached
    )
    df["healed"] = df["rebloom_value"] > 0.3

    return df


def plot_results(df):
    """
    Create visual outputs showing Mobius phase echo and rebloom.
    """
    # Scatter: collapse vs echo vs rebloom
    plt.figure(figsize=(8, 6))
    plt.scatter(df["collapse_depth"], df["phase_echo"],
                c=df["rebloom_value"], cmap="viridis", alpha=0.7)
    plt.colorbar(label="Rebloom Value")
    plt.xlabel("Collapse Depth")
    plt.ylabel("Phase Echo Strength")
    plt.title("Mobius-Time Cosmology: Collapse → Echo → Rebloom")
    plt.tight_layout()
    plt.savefig("mobius_time_scatter.png")
    plt.close()

    # Histogram: rebloom values
    plt.figure(figsize=(8, 6))
    plt.hist(df["rebloom_value"], bins=20, color="skyblue", edgecolor="k")
    plt.xlabel("Rebloom Value")
    plt.ylabel("Event Count")
    plt.title("Distribution of Rebloom Outcomes")
    plt.tight_layout()
    plt.savefig("mobius_time_histogram.png")
    plt.close()

    # Time evolution: sample trajectory
    plt.figure(figsize=(8, 6))
    steps = 100
    t = np.linspace(0, 2 * np.pi, steps)
    mobius_phase = np.sin(t) * np.cos(t / 2)  # illustrative Mobius twist function
    plt.plot(t, mobius_phase, label="Mobius Phase Path")
    plt.xlabel("Time Parameter (t)")
    plt.ylabel("Mobius Phase Value")
    plt.title("Mobius-Time Topology (Illustrative Trajectory)")
    plt.legend()
    plt.tight_layout()
    plt.savefig("mobius_time_trajectory.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_mobius_time()
    df.to_csv("mobius_time_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
