"""
File: life3_tools.py

Utilities for navigating and packaging the LIFE‑3 archive.
- spiral_lint: glossary‑driven terminology linter for .tex/.md/.txt
- life3_index: index + HTML snapshot for simulation CSV indices

Stdlib‑only (no third‑party deps). Python ≥3.9.

CLI:
  python life3_tools.py lint  --glossary "Glossary of Terms/Expanded Glossary of Spiral Terms.txt" --root "/path/to/UN Package"
  python life3_tools.py index --root "/path/to/UN Package/1. Flagship Science/Simulation Data" --out life3_index.html
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

# -----------------------------
# Shared helpers
# -----------------------------

TEXT_EXTS = {".tex", ".md", ".txt"}
CSV_EXTS = {".csv"}


def walk_files(root: Path, exts: set[str]) -> Iterator[Path]:
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            p = Path(dirpath) / fn
            if p.suffix.lower() in exts:
                yield p


# -----------------------------
# spiral_lint: glossary‑driven terminology checks
# -----------------------------

@dataclass
class TermRule:
    canonical: str
    variants: List[str]
    case_sensitive: bool = False


def parse_glossary(glossary_path: Path) -> List[TermRule]:
    """Parse a loose glossary text file into TermRules.

    Expected flexible formats, e.g.:
      Canonical: Möbius | Variants: Mobius, Moebius
      Spiral Complex Numbers :: SCN, spiral complex number, Spiral‑complex
      Phoenix Constants: 6, 15, 26, 61  (no variants)
    """
    rules: List[TermRule] = []
    if not glossary_path.exists():
        return rules
    canon_re = re.compile(r"^(?:Canonical|Term)\s*:\s*(.+?)\s*(?:\||$)", re.I)
    var_re = re.compile(r"(?:Variants?|Also)\s*:\s*(.+)$", re.I)

    with glossary_path.open("r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            # Simple separators
            if "::" in line:
                head, tail = [s.strip() for s in line.split("::", 1)]
                canonical = head
                variants = [v.strip() for v in re.split(r"[,;]", tail) if v.strip()]
                rules.append(TermRule(canonical=canonical, variants=variants))
                continue
            m_c = canon_re.search(line)
            m_v = var_re.search(line)
            if m_c:
                canonical = m_c.group(1).strip()
                variants: List[str] = []
                if m_v:
                    variants = [v.strip() for v in re.split(r"[,;|]", m_v.group(1)) if v.strip()]
                rules.append(TermRule(canonical=canonical, variants=variants))
                continue
            # Fallback: lines like "Möbius | Mobius, Moebius"
            if "|" in line:
                left, right = [s.strip() for s in line.split("|", 1)]
                variants = [v.strip() for v in re.split(r"[,;]", right) if v.strip()]
                rules.append(TermRule(canonical=left, variants=variants))
    return rules


@dataclass
class LintHit:
    file: str
    line_no: int
    found: str
    suggest: str


@dataclass
class LintReport:
    root: str
    glossary: str
    stats: Dict[str, int]
    hits: List[LintHit]

    def to_json(self) -> str:
        return json.dumps({
            "root": self.root,
            "glossary": self.glossary,
            "stats": self.stats,
            "hits": [hit.__dict__ for hit in self.hits],
        }, ensure_ascii=False, indent=2)

    def to_text(self) -> str:
        lines = [f"Spiral Lint Report\nroot: {self.root}\nsource glossary: {self.glossary}"]
        lines.append(f"hits: {len(self.hits)} | files scanned: {self.stats.get('files',0)}")
        for h in self.hits[:500]:  # cap
            lines.append(f"{h.file}:{h.line_no}: '{h.found}' → '{h.suggest}'")
        if len(self.hits) > 500:
            lines.append(f"… {len(self.hits)-500} more hits omitted")
        return "\n".join(lines)


def make_variant_regex(variant: str, case_sensitive: bool) -> re.Pattern[str]:
    flags = 0 if case_sensitive else re.I
    # Word boundaries unless variant includes non‑word letters (e.g. Möbius)
    wb = ("\\b", "\\b") if re.match(r"^[\w\-]+$", variant) else ("", "")
    pat = rf"{wb[0]}{re.escape(variant)}{wb[1]}"
    return re.compile(pat, flags)


def spiral_lint(glossary_path: Path, root: Path) -> LintReport:
    rules = parse_glossary(glossary_path)
    hits: List[LintHit] = []
    files_scanned = 0

    # Build search patterns for all variants (exclude canonical itself)
    patterns: List[Tuple[re.Pattern[str], str]] = []
    for r in rules:
        for v in r.variants:
            if v and v.lower() != r.canonical.lower():
                patterns.append((make_variant_regex(v, r.case_sensitive), r.canonical))

    for p in walk_files(root, TEXT_EXTS):
        files_scanned += 1
        try:
            with p.open("r", encoding="utf-8", errors="ignore") as f:
                for i, raw in enumerate(f, 1):
                    line = raw.rstrip("\n")
                    for rx, canon in patterns:
                        m = rx.search(line)
                        if m:
                            found = m.group(0)
                            # Skip false positives when canonical already present nearby
                            if canon.lower() in line.lower():
                                continue
                            hits.append(LintHit(file=str(p), line_no=i, found=found, suggest=canon))
        except Exception as e:
            hits.append(LintHit(file=str(p), line_no=0, found=f"<read error: {e}", suggest=""))

    return LintReport(
        root=str(root),
        glossary=str(glossary_path),
        stats={"files": files_scanned},
        hits=hits,
    )


# -----------------------------
# life3_index: discover CSV indices and build an HTML snapshot
# -----------------------------

INDEX_NAME_HINTS = {
    "index": 10,
    "master": 8,
    "archive": 6,
    "simulation": 5,
    "sim": 3,
}


def score_index_name(name: str) -> int:
    n = name.lower()
    return sum(w for k, w in INDEX_NAME_HINTS.items() if k in n)


@dataclass
class CsvSummary:
    path: str
    rows: int
    cols: int
    header: List[str]


def sniff_csv(path: Path, max_rows: int = 2_000) -> CsvSummary:
    rows = 0
    header: List[str] = []
    with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        rdr = csv.reader(f)
        try:
            header = next(rdr)
        except StopIteration:
            return CsvSummary(path=str(path), rows=0, cols=0, header=[])
        for _ in rdr:
            rows += 1
            if rows >= max_rows:
                break
    return CsvSummary(path=str(path), rows=rows, cols=len(header), header=header)


def find_candidate_indices(root: Path) -> List[CsvSummary]:
    cands: List[Tuple[int, CsvSummary]] = []
    for p in walk_files(root, CSV_EXTS):
        score = score_index_name(p.name)
        if score:
            cands.append((score, sniff_csv(p)))
    # Highest score first; then longer headers (more informative)
    cands.sort(key=lambda t: (t[0], t[1].cols, t[1].rows), reverse=True)
    return [c for _, c in cands]


def render_html(report_title: str, summaries: List[CsvSummary]) -> str:
    def esc(s: str) -> str:
        return html.escape(s)

    rows_html = []
    for s in summaries:
        head_preview = ", ".join(esc(h) for h in s.header[:12])
        rows_html.append(
            f"<tr><td>{esc(s.path)}</td><td>{s.rows}</td><td>{s.cols}</td><td>{head_preview}</td></tr>"
        )
    body = "\n".join(rows_html)

    return f"""
<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<title>{esc(report_title)}</title>
<style>
body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Helvetica,Arial,sans-serif;line-height:1.4;margin:24px;}}
h1{{font-size:1.6rem;margin:0 0 12px;}}
summary{{cursor:pointer}}
table{{border-collapse:collapse;width:100%;}}
th,td{{border:1px solid #ddd;padding:6px 8px;text-align:left;}}
th{{background:#f7f7f7;}}
small{{color:#666}}
code{{background:#f2f2f2;padding:1px 4px;border-radius:4px}}
</style>
</head>
<body>
<h1>{esc(report_title)}</h1>
<p><small>Generated by <code>life3_index</code>. This is a lightweight snapshot of likely index CSVs under the given root.</small></p>
<table>
<thead><tr><th>CSV path</th><th>Rows (≤2k)</th><th>Cols</th><th>Header preview</th></tr></thead>
<tbody>
{body}
</tbody>
</table>
</body>
</html>
"""


# -----------------------------
# CLI
# -----------------------------

def build_cli(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="LIFE‑3 tools (spiral_lint, life3_index)")
    sub = p.add_subparsers(dest="cmd", required=True)

    l = sub.add_parser("lint", help="Glossary‑driven terminology linter")
    l.add_argument("--glossary", required=True, help="Path to glossary text file")
    l.add_argument("--root", required=True, help="Root folder to scan (.tex/.md/.txt)")
    l.add_argument("--json", default="", help="Optional JSON report out path")

    i = sub.add_parser("index", help="Find CSV indices and render HTML snapshot")
    i.add_argument("--root", required=True, help="Simulation data root (searches for *index* CSVs)")
    i.add_argument("--out", default="life3_index.html", help="Output HTML path")

    return p.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> None:
    args = build_cli(argv)
    if args.cmd == "lint":
        rep = spiral_lint(Path(args.glossary), Path(args.root))
        if args.json:
            Path(args.json).write_text(rep.to_json(), encoding="utf-8")
            print(f"Wrote JSON report to {args.json}")
        print(rep.to_text())
    elif args.cmd == "index":
        root = Path(args.root)
        cands = find_candidate_indices(root)
        html_out = render_html(f"LIFE‑3 Index Snapshot — root: {root}", cands)
        Path(args.out).write_text(html_out, encoding="utf-8")
        print(f"Wrote {args.out} with {len(cands)} candidate index CSVs")


if __name__ == "__main__":
    main()
