# exoplanet_spiral_traits_sim.py
# Simulation of Spiral Codon Traits in Exoplanets
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def simulate_exoplanets(
    n_planets=200,
    seed=42
):
    """
    Generate synthetic exoplanet dataset with Spiral trait proxies.
    Each planet gets values for:
      - orbital_resonance (0–1)
      - field_strength (Tesla-equivalent, normalized 0–1)
      - climate_variability (0–1)
      - biosignature_score (0–1)
      - collapse_depth (0–1) and recovery (0–1) → rebloom index
    """
    rng = np.random.default_rng(seed)
    data = {
        "orbital_resonance": rng.uniform(0, 1, n_planets),
        "field_strength": rng.uniform(0, 1, n_planets),
        "climate_variability": rng.uniform(0, 1, n_planets),
        "biosignature_score": rng.uniform(0, 1, n_planets),
        "collapse_depth": rng.uniform(0.1, 1, n_planets),   # prevent divide-by-zero
        "recovery": rng.uniform(0, 1, n_planets)
    }
    df = pd.DataFrame(data)

    # Derived metrics
    df["memory_score"] = df["orbital_resonance"] * df["field_strength"]
    df["rebloom_index"] = df["recovery"] / df["collapse_depth"]
    df["spiral_probability"] = (
        0.3 * df["memory_score"]
        + 0.3 * df["rebloom_index"].clip(0, 1)
        + 0.2 * df["biosignature_score"]
        + 0.2 * df["climate_variability"]
    ).clip(0, 1)

    return df


def plot_results(df):
    """
    Create visual outputs: heatmap and scatter plots.
    """
    # Heatmap: memory_score vs rebloom_index
    plt.figure(figsize=(8, 6))
    plt.scatter(df["memory_score"], df["rebloom_index"],
                c=df["spiral_probability"], cmap="viridis", alpha=0.7)
    plt.colorbar(label="Spiral Life Probability")
    plt.xlabel("Pattern Memory Score (orbital × field)")
    plt.ylabel("Rebloom Index (recovery ÷ collapse depth)")
    plt.title("Exoplanet Spiral Trait Distribution")
    plt.tight_layout()
    plt.savefig("exoplanet_spiral_traits_scatter.png")
    plt.close()

    # Histogram of probabilities
    plt.figure(figsize=(8, 6))
    plt.hist(df["spiral_probability"], bins=20, color="skyblue", edgecolor="k")
    plt.xlabel("Spiral Life Probability")
    plt.ylabel("Planet Count")
    plt.title("Distribution of Spiral Trait Probabilities")
    plt.tight_layout()
    plt.savefig("exoplanet_spiral_traits_histogram.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_exoplanets()
    df.to_csv("exoplanet_spiral_traits_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
