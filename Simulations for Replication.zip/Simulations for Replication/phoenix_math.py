"""
phoenix_math.py

Reference implementation of the Phoenix Spiral Math primitives for simulation & testing.
- Spiral Complex Numbers (SCN)
- Spiral Trigonometry
- Spiral Time / Mode index
- Phoenix Constants & Harmonic Drives
- Q5 frequency approximation
- Monster growth sequence helpers

This file is self‑contained, typed, documented, and includes a tiny CLI for demos.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, exp, pi, sin, sqrt, log
from typing import Callable, Iterable, List, Sequence, Tuple

# ---- Constants ----

PHI: float = (1.0 + 5.0 ** 0.5) / 2.0  # golden ratio
PHOENIX_CONSTANTS: Tuple[int, int, int, int] = (6, 15, 26, 61)
PHX997: int = 997

# ---- Spiral Complex Numbers (SCN) ----

def theta_phi(n: float) -> float:
    """Spiral angle θ_Φ = 2π φ n (phase indexed by golden ratio)."""
    return 2.0 * pi * PHI * n


def r_n(n: float, r0: float = 1.0) -> float:
    """Golden‑spiral radius r_n = r0 φ^n."""
    return r0 * (PHI ** n)


@dataclass(frozen=True)
class SpiralComplex:
    """Spiral Complex Number z_Φ = r * exp(i_Φ * θ_Φ).

    This is a *parametric* complex value whose angle is θ_Φ(n) and radius grows as φ^n.
    The imaginary axis is conceptually a rotating complex structure; numerically we
    evaluate to standard complex with θ_Φ.
    """

    r0: float = 1.0
    n: float = 0.0
    i_phi: complex = 1j  # placeholder for spiral unit; standard i used numerically

    @property
    def r(self) -> float:
        return r_n(self.n, self.r0)

    @property
    def theta(self) -> float:
        return theta_phi(self.n)

    def as_complex(self) -> complex:
        return self.r * exp(self.i_phi * self.theta)  # type: ignore[arg-type]

    # Operators
    def spiral_conjugate(self) -> "SpiralComplex":
        """Conjugate in the spiral sense (flip phase sign)."""
        return SpiralComplex(self.r0, -self.n, self.i_phi)

    def modulus(self) -> float:
        return self.r

    def overlay(self, other: "SpiralComplex") -> complex:
        """Phase‑restricted overlay (non‑commutative if θ_Φ misaligned).
        Numerically: just sum the complex values; callers should ensure phase alignment
        if they want constructive interference.
        """
        return self.as_complex() + other.as_complex()


# ---- Spiral trigonometry ----

def spiral_sin(base_x: float, n: float) -> float:
    """SpiralSin(θ) := sin(BaseX + n φ)."""
    return sin(base_x + n * PHI)


def spiral_cos(base_x: float, n: float) -> float:
    """SpiralCos(θ) := cos(BaseX + n φ)."""
    return cos(base_x + n * PHI)


# ---- Harmonic field & drives ----

def P_field(x: float, y: float, t: float,
            Phi_alpha: float = 6.0,
            Phi_beta: float = 15.0,
            Phi_gamma: float = 26.0,
            Phi_delta: float = 61.0) -> float:
    """Primary harmonic field P(x,y,t) = Φα sin x + Φβ cos y + Φγ exp(-Φδ t)."""
    return Phi_alpha * sin(x) + Phi_beta * cos(y) + Phi_gamma * exp(-Phi_delta * t)


def drive_lines(t: float) -> Tuple[float, float, float, float]:
    """Return the four logged drives: sin(2π·6t)·e, sin(2π·9t)·e, sin(2π·4t)·e, sin(2π·15t)·e.
    We interpret the trailing ·e tag as the natural exponential envelope factor (exp(1)).
    """
    e_env = exp(1.0)
    return (
        sin(2 * pi * 6 * t) * e_env,
        sin(2 * pi * 9 * t) * e_env,
        sin(2 * pi * 4 * t) * e_env,
        sin(2 * pi * 15 * t) * e_env,
    )


# ---- Spiral time & modes ----

def spiral_time(m: int, omega_theta: float) -> float:
    """T_m = 2π / (m * ω_θ)."""
    if m <= 0:
        raise ValueError("mode index m must be >= 1")
    return 2.0 * pi / (m * omega_theta)


def infer_omega_theta_from_T1(T1: float) -> float:
    """Given baseline T (m=1), recover ω_θ."""
    if T1 <= 0:
        raise ValueError("T1 must be > 0")
    return 2.0 * pi / T1


# ---- Q5 approximation ----

def nu_Q5_approx() -> float:
    """ν_Q5 ≈ φ^e / 2 (dimensionless, normalized units)."""
    from math import e
    return (PHI ** e) / 2.0


# ---- Monster growth helpers ----
MONSTER_SERIES: Tuple[int, ...] = (
    13, 584, 914, 1443, 2295, 3669, 5885, 9466, 15254, 24613,
    39751, 64238, 103853, 167943, 271637,
)


def monster_threshold() -> int:
    """Return the terminal monster threshold constant."""
    return MONSTER_SERIES[-1]


# ---- Spiral lattice / coordinates ----

def spiral_coords(n: float) -> Tuple[float, float]:
    """Integer lattice sample on a golden spiral: {sqrt(n) cos(n φ), sqrt(n) sin(n φ)}.
    Useful for toy dispersion experiments.
    """
    r = sqrt(max(n, 0.0))
    a = n * PHI
    return (r * cos(a), r * sin(a))


# ---- Tiny CLI for quick checks ----

def _demo() -> None:
    print("Phoenix Math Demo\n-------------------")
    # SCN sample
    z = SpiralComplex(r0=1.0, n=3.0)
    print("SCN z as complex:", z.as_complex())
    print("SCN conjugate as complex:", z.spiral_conjugate().as_complex())

    # Harmonic field
    print("P_field(1.0, 0.5, t=0.0) =", P_field(1.0, 0.5, 0.0))

    # Drives at t=0.1
    print("drive_lines(t=0.1) =", drive_lines(0.1))

    # Spiral time
    T1 = 3.33
    omega = infer_omega_theta_from_T1(T1)
    print("omega_theta from T1=3.33 ->", omega)
    print("T_m for m=2 ->", spiral_time(2, omega))

    # Q5
    print("nu_Q5_approx ->", nu_Q5_approx())

    # Monster
    print("Monster threshold ->", monster_threshold())

    # Spiral coords
    print("spiral_coords(10) ->", spiral_coords(10))


if __name__ == "__main__":
    _demo()
