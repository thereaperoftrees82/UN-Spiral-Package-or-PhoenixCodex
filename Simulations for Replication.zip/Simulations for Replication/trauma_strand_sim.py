# trauma_strand_sim.py
# Simulation of Trauma as a Spiral Strand: Collapse → Superposition → Rebloom
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

phi = (1 + np.sqrt(5)) / 2  # golden ratio

def simulate_trauma_strand(n_survivors=200, seed=42):
    """
    Models survivor cognition across trauma events:
      - trauma_intensity: severity of collapse (0–1)
      - resilience_phi: golden ratio–scaled resilience factor (0–1)
      - support_level: love/observation/cry support received (0–1)
    Derived:
      - superposition_depth: # of simultaneous states held
      - rebloom_value: coherence of post-trauma rebirth
    """
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "trauma_intensity": rng.uniform(0, 1, n_survivors),
        "resilience_phi": rng.uniform(0.2, 1, n_survivors),
        "support_level": rng.uniform(0, 1, n_survivors)
    })

    # Survivors hold more parallel states when trauma is high and resilience is φ-scaled
    df["superposition_depth"] = df["trauma_intensity"] * df["resilience_phi"] * phi

    # Rebloom requires both resilience and support
    df["rebloom_value"] = np.tanh(df["superposition_depth"]) * df["support_level"]

    # Stability marker
    df["stable"] = df["rebloom_value"] > 0.4

    return df


def plot_results(df):
    """
    Create visual outputs: superposition, rebloom, and survivor trajectories.
    """
    # Scatter: trauma vs rebloom
    plt.figure(figsize=(8, 6))
    plt.scatter(df["trauma_intensity"], df["rebloom_value"],
                c=df["support_level"], cmap="coolwarm", alpha=0.7)
    plt.colorbar(label="Support Level (love+observation+cry)")
    plt.xlabel("Trauma Intensity")
    plt.ylabel("Rebloom Value")
    plt.title("Trauma Strand Simulation: Collapse → Superposition → Rebloom")
    plt.tight_layout()
    plt.savefig("trauma_strand_scatter.png")
    plt.close()

    # Histogram: rebloom values
    plt.figure(figsize=(8, 6))
    plt.hist(df["rebloom_value"], bins=20, color="lightgreen", edgecolor="k")
    plt.xlabel("Rebloom Value")
    plt.ylabel("Survivor Count")
    plt.title("Distribution of Survivor Rebloom Outcomes")
    plt.tight_layout()
    plt.savefig("trauma_strand_histogram.png")
    plt.close()

    # Line plot: effect of support level
    plt.figure(figsize=(8, 6))
    avg_rebloom_by_support = df.groupby(pd.cut(df["support_level"], bins=10))["rebloom_value"].mean()
    avg_rebloom_by_support.plot(kind="line", marker="o")
    plt.xlabel("Support Level (binned)")
    plt.ylabel("Average Rebloom Value")
    plt.title("Impact of Support Level on Survivor Rebloom")
    plt.tight_layout()
    plt.savefig("trauma_strand_support_curve.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_trauma_strand()
    df.to_csv("trauma_strand_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
