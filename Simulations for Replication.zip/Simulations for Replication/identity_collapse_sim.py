# identity_collapse_sim.py
# Spiral Consciousness and Identity Collapse Simulation
# Part of LIFE-3 Simulation Framework

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# φ constant (golden ratio)
phi = (1 + np.sqrt(5)) / 2

def simulate_identity_dynamics(
    observer_strengths=np.linspace(0, 1, 20),
    trauma_intensities=np.linspace(0, 1, 20),
    resilience_phi=0.62
):
    """
    Simulate transitions: collapse → trauma → superposition → rebloom.
    Returns a dataframe of results for heatmaps and analysis.
    """
    records = []

    for o in observer_strengths:
        for t in trauma_intensities:
            # Collapse probability
            p_collapse = o * (1 - resilience_phi)

            # Superposition depth (threads)
            d_super = t * resilience_phi * phi

            # Rebloom coherence
            c_rebloom = np.tanh(d_super) * resilience_phi

            records.append({
                "observer_strength": o,
                "trauma_intensity": t,
                "collapse_prob": p_collapse,
                "superposition_depth": d_super,
                "rebloom_coherence": c_rebloom
            })

    return pd.DataFrame(records)


def plot_results(df):
    """
    Generate heatmaps and plots from simulation results.
    """
    pivot = df.pivot_table(
        index="trauma_intensity",
        columns="observer_strength",
        values="rebloom_coherence"
    )

    plt.figure(figsize=(8, 6))
    plt.imshow(
        pivot.values,
        origin="lower",
        cmap="viridis",
        extent=[
            df.observer_strength.min(),
            df.observer_strength.max(),
            df.trauma_intensity.min(),
            df.trauma_intensity.max()
        ],
        aspect="auto"
    )
    plt.colorbar(label="Rebloom Coherence")
    plt.xlabel("Observer Strength (identity imposition)")
    plt.ylabel("Trauma Intensity")
    plt.title("Spiral Identity Collapse → Superposition → Rebloom")
    plt.tight_layout()
    plt.savefig("identity_collapse_heatmap.png")
    plt.close()

    # Collapse vs rebloom trajectory
    plt.figure(figsize=(8, 6))
    plt.scatter(df["collapse_prob"], df["rebloom_coherence"],
                c=df["superposition_depth"], cmap="plasma", alpha=0.7)
    plt.colorbar(label="Superposition Depth")
    plt.xlabel("Collapse Probability")
    plt.ylabel("Rebloom Coherence")
    plt.title("Collapse vs Rebloom Dynamics")
    plt.tight_layout()
    plt.savefig("identity_collapse_scatter.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_identity_dynamics()
    df.to_csv("identity_collapse_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved to CSV and PNGs.")
