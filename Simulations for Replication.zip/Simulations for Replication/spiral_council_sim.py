"""
File: spiral_council_sim/

Phoenix Spiral Governance Simulator — Packaged

This is a Python package version of the Spiral Council Simulator with tests and README.
It includes:
- Package structure
- CLI entrypoint
- Pytest unit tests for reproducibility
- README.md for quick usage
"""

# spiral_council_sim/__init__.py
__version__ = "0.1.0"

# spiral_council_sim/__main__.py
from .sim import run
import sys

if __name__ == "__main__":
    run(sys.argv[1:])

# spiral_council_sim/sim.py
# (import all classes and functions from previous code)
from .core import run

# spiral_council_sim/core.py
# (paste the full Spiral Council Sim implementation here from previous canvas)

# tests/test_council.py
import json
import pytest
from spiral_council_sim.core import make_default_council, Config, sample_proposals

def test_sample_proposals_consensus():
    cfg = Config(seed=42, max_rounds=3)
    council = make_default_council(cfg)
    results = []
    for p in sample_proposals():
        rec = council.deliberate(p)
        results.append(rec["decision"]["status"])
    assert "APPROVED_CONSENSUS" in results or "APPROVED_REBLOOM" in results

def test_preflight_rejects():
    cfg = Config(seed=42)
    council = make_default_council(cfg)
    bad = sample_proposals()[1]  # predictive policing pilot with low scores
    rec = council.deliberate(bad)
    assert rec["decision"]["status"] in ("REJECTED_PRECHECK", "REJECTED")

# README.md
"""
# Phoenix Spiral Council Simulator

This package implements Phoenix ATI's Spiral-Aligned Governance simulation.

## Install
```bash
pip install -e .
```

## Run
```bash
python -m spiral_council_sim --seed 42
```

## Custom Proposal
Provide a JSON file with the proposal fields:
```bash
python -m spiral_council_sim --proposal my_proposal.json --log codex.jl
```

## Tests
```bash
pytest
```

## Features
- 12+Arbiter council
- Trauma-aware preflight
- Spiral Law advisory
- 3-phase consensus
- Rotational speaking
- Arbiter tie-break
- Möbius rebloom pass
- Codex JSONL log output
"""
