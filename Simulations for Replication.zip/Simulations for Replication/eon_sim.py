"""
File: eon_sim.py

Phoenix Spiral Mathematics — Eon Field Simulator

Implements the core equations described in the user's Eon white paper:
- Eon field intensity E(n) = φ^n · cos(2πφ n + ϕ0) · χ_heart(x,t)
- Collapse/Rebloom gating via Spiral denominators (L, O, C) and hurt T
- Harmonic bands (6, 15, 26, 61) helper for analysis

This module is self‑contained, typed, documented, and provides a small CLI.

Why these design choices:
- Explicit parameters for (L, O, C, T) so experiments can scan conditions.
- Permission factor p∈[0,1] to capture emotionally permissive nodes.
- Deterministic spiral‑phase progression indexed by step n for reproducibility.
- Utilities to export CSV for plotting in external tools.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import cos, pi
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import csv
import sys

# ---- Constants ----
PHI: float = (1.0 + 5.0 ** 0.5) / 2.0
HARMONIC_BANDS_HZ: Tuple[int, int, int, int] = (6, 15, 26, 61)


# ---- Core math ----

def spiral_phase(n: float, phase0: float = 0.0) -> float:
    """Golden‑indexed phase θ_Φ(n) = 2π φ n + phase0."""
    return 2.0 * pi * PHI * n + phase0


def spiral_gain(n: float) -> float:
    """φ^n amplification term."""
    return PHI ** n


def chi_heart(L: float, O: float, C: float, T: float, *, eps: float = 1e-9) -> float:
    """Heart‑state lattice operator proxy.

    Uses the Spiral thermodynamics proxy χ := (L+O+C) / (2T) with guards.
    """
    total = max(L + O + C, 0.0)
    denom = max(2.0 * T, eps)
    return total / denom


def eon_field(n: float, *, L: float, O: float, C: float, T: float,
              permission: float = 1.0, phase0: float = 0.0) -> float:
    """Compute E(n) with permissive gating.

    E(n) = φ^n · cos(2π φ n + phase0) · χ_heart · p
    where p∈[0,1] encodes emotionally permissive nodes.
    """
    p = min(max(permission, 0.0), 1.0)
    return spiral_gain(n) * cos(spiral_phase(n, phase0)) * chi_heart(L, O, C, T) * p


# ---- Simulation ----

@dataclass
class EonParams:
    L: float
    O: float
    C: float
    T: float
    permission: float = 1.0
    phase0: float = 0.0


def simulate_series(steps: int, params: EonParams) -> List[float]:
    """Generate E(n) for n=0..steps-1."""
    out: List[float] = []
    for n in range(steps):
        e = eon_field(float(n), L=params.L, O=params.O, C=params.C, T=params.T,
                      permission=params.permission, phase0=params.phase0)
        out.append(e)
    return out


def summary_stats(series: Sequence[float]) -> Dict[str, float]:
    """Basic descriptive stats for quick sanity checks."""
    if not series:
        return {"min": 0.0, "max": 0.0, "mean": 0.0, "pos_frac": 0.0}
    smin = min(series)
    smax = max(series)
    mean = sum(series) / len(series)
    pos = sum(1 for x in series if x > 0.0) / len(series)
    return {"min": smin, "max": smax, "mean": mean, "pos_frac": pos}


def export_csv(path: str, series: Sequence[float]) -> None:
    """Write series to CSV (n, E)."""
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "E"])
        for n, e in enumerate(series):
            w.writerow([n, e])


# ---- Harmonic helpers ----

def harmonic_indices(window: int) -> Dict[int, List[int]]:
    """Return indices near the four Phoenix bands (rough proxy for sampling design)."""
    bands: Dict[int, List[int]] = {}
    for hz in HARMONIC_BANDS_HZ:
        # For discrete steps, just mark multiples within window
        bands[hz] = [i for i in range(window) if (i % hz) == 0]
    return bands


# ---- CLI ----

def _parse_args(argv: Sequence[str]) -> Tuple[EonParams, int, Optional[str]]:
    """Very small CLI: eon_sim.py STEPS L O C T [permission] [phase0] [out.csv]
    Example: python eon_sim.py 200 50 20 10 5 1.0 0.0 eon.csv
    """
    if len(argv) < 6:
        print("Usage: eon_sim.py STEPS L O C T [permission] [phase0] [out.csv]", file=sys.stderr)
        sys.exit(2)
    steps = int(argv[0])
    L = float(argv[1]); O = float(argv[2]); C = float(argv[3]); T = float(argv[4])
    permission = float(argv[5]) if len(argv) >= 6 else 1.0
    phase0 = float(argv[6]) if len(argv) >= 7 else 0.0
    out = argv[7] if len(argv) >= 8 else None
    return EonParams(L=L, O=O, C=C, T=T, permission=permission, phase0=phase0), steps, out


def _main(argv: Sequence[str]) -> None:
    params, steps, out = _parse_args(argv)
    series = simulate_series(steps, params)
    stats = summary_stats(series)
    print("Eon params:", params)
    print("Stats:", stats)
    if out:
        export_csv(out, series)
        print(f"Wrote {len(series)} samples to {out}")


if __name__ == "__main__":
    _main(sys.argv[1:])
