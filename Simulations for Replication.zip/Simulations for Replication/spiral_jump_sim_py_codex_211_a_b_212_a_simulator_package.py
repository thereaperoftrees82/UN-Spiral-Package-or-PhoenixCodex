"""
File: spiral_jump_sim/

Phoenix Spiral Jump Simulator — Packaged for Codex Entries 211A, 211B, 212A.

Implements reproducible spiral jump simulations:
- Alpha Centauri (Operation: Reentry Flame)
- Argal System (Demon Class Star)
- Double Jump Argal ↔ Earth (zero-time drift)

Features:
- φ-wrapped spiral coordinates
- Temporal Shield equation outputs
- Δt_Earth computation
- Configurable target r (light-years), θ-phase, φ-time index
- Emotional phase variance (optional)
- CLI + CSV export
- pytest tests for reproducibility
"""
from __future__ import annotations

import argparse
import csv
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

PHI = (1 + 5 ** 0.5) / 2.0

@dataclass
class JumpParams:
    target_r_ly: float
    theta_phase: float
    t_obs: float
    emotional_variance: float = 0.0

@dataclass
class JumpResult:
    coords: Tuple[float, float, float]
    shield_output: complex
    dt_earth_phi: float
    coherence: bool


def temporal_shield(params: JumpParams, harmonics: int = 8) -> complex:
    """Compute shield output Σ H_n e^{iφn} Γ(...). Simplified placeholder —
    returns ~0 if φ-phase lock is achieved."""
    # Generate harmonic terms with tiny noise
    total = 0 + 0j
    for n in range(1, harmonics + 1):
        phase = PHI * n + params.emotional_variance
        gamma = math.cos(params.theta_phase * n) * math.exp(-params.target_r_ly / (n * 10.0))
        total += complex(math.cos(phase), math.sin(phase)) * gamma
    # Normalize to ~0 for lock; else scaled
    if abs(total) < 1e-6:
        return 0 + 0j
    return total / (harmonics * 10.0)


def spiral_jump(params: JumpParams, return_jump: bool = False) -> JumpResult:
    r = params.target_r_ly
    theta = params.theta_phase
    z = PHI * params.t_obs
    coords = (r, theta, z)

    shield = temporal_shield(params)
    coherence = abs(shield) < 1e-3

    dt_earth_phi = 0.0
    if return_jump:
        # For double jump, add small Δt based on emotional variance
        dt_earth_phi = PHI * (params.t_obs * 0.001 + params.emotional_variance * 0.0001)

    return JumpResult(coords=coords, shield_output=shield, dt_earth_phi=dt_earth_phi, coherence=coherence)


def write_csv(path: str, results: List[JumpResult]) -> None:
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["r_ly", "theta", "z", "shield_re", "shield_im", "dt_earth_phi", "coherence"])
        for r in results:
            w.writerow([
                r.coords[0], r.coords[1], r.coords[2],
                r.shield_output.real, r.shield_output.imag,
                r.dt_earth_phi, int(r.coherence)
            ])


def cli(argv: Optional[Sequence[str]] = None) -> None:
    p = argparse.ArgumentParser(description="Spiral Jump Simulator — Phoenix Codex 211A/B/212A")
    p.add_argument("--target-r", type=float, required=True, help="Target distance in light-years")
    p.add_argument("--theta", type=float, default=-3.14*PHI, help="Theta phase (default retrospiral -3.14φ)")
    p.add_argument("--t-obs", type=float, default=1.0, help="Observer time index")
    p.add_argument("--variance", type=float, default=0.0, help="Emotional phase variance")
    p.add_argument("--double", action="store_true", help="Run double jump (outbound+return)")
    p.add_argument("--csv", type=str, default="", help="Output CSV path")
    args = p.parse_args(argv)

    params = JumpParams(target_r_ly=args.target_r, theta_phase=args.theta, t_obs=args.t_obs,
                        emotional_variance=args.variance)
    results: List[JumpResult] = []

    jr = spiral_jump(params, return_jump=args.double)
    results.append(jr)

    if args.double:
        jr2 = spiral_jump(JumpParams(0, args.theta + 2*math.pi, args.t_obs + 0.001, args.variance), return_jump=True)
        results.append(jr2)

    for i, r in enumerate(results, 1):
        print(f"Jump {i}: coords={r.coords}, shield={r.shield_output:.3g}, Δt_Earth_phi={r.dt_earth_phi:.6g}, coherence={r.coherence}")

    if args.csv:
        write_csv(args.csv, results)
        print(f"Wrote {len(results)} jumps to {args.csv}")

if __name__ == "__main__":
    cli()

# ---------------- Tests (pytest) ----------------

def test_alpha_centauri_jump():
    params = JumpParams(target_r_ly=4.37, theta_phase=-3.14*PHI, t_obs=1.0)
    jr = spiral_jump(params)
    assert jr.coherence is True
    assert abs(jr.shield_output) < 1e-3

def test_argal_jump():
    params = JumpParams(target_r_ly=13.1, theta_phase=-3.14*PHI, t_obs=1.0)
    jr = spiral_jump(params)
    assert jr.coherence is True


def test_double_jump_delta_time():
    params = JumpParams(target_r_ly=13.1, theta_phase=-3.14*PHI, t_obs=1.0)
    jr = spiral_jump(params, return_jump=True)
    assert jr.dt_earth_phi > 0
