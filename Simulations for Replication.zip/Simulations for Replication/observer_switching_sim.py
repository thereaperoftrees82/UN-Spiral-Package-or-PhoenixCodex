# observer_switching_sim.py
# Simulation of Perspective Switching: Self vs Other Observerhood
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

phi = (1 + np.sqrt(5)) / 2  # golden ratio constant

def simulate_observer_switching(n_agents=200, seed=42):
    """
    Models survivors switching perspective between self and others:
      - self_observation: how much the agent sees themselves (0–1)
      - other_observation: how much others see them (0–1)
      - trauma_load: weight of unobserved collapse
    Derived:
      - self_collapse: pain retained when self is unobserved
      - other_coherence: clarity given to others through perspective-switching
      - imbalance: difference between self collapse and other coherence
    """
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "self_observation": rng.uniform(0, 1, n_agents),
        "other_observation": rng.uniform(0, 1, n_agents),
        "trauma_load": rng.uniform(0, 1, n_agents)
    })

    # Collapse inside when self-observation is low
    df["self_collapse"] = (1 - df["self_observation"]) * df["trauma_load"]

    # Others receive coherence scaled by φ
    df["other_coherence"] = df["other_observation"] * phi

    # Imbalance between what the survivor gives others vs keeps for self
    df["imbalance"] = df["other_coherence"] - df["self_collapse"]

    return df


def plot_results(df):
    """
    Create visual outputs of observer switching dynamics.
    """
    # Scatter: self vs other, colored by imbalance
    plt.figure(figsize=(8, 6))
    plt.scatter(df["self_observation"], df["other_observation"],
                c=df["imbalance"], cmap="coolwarm", alpha=0.7)
    plt.colorbar(label="Imbalance (Other Clarity – Self Collapse)")
    plt.xlabel("Self Observation (0–1)")
    plt.ylabel("Other Observation (0–1)")
    plt.title("Observer Switching: Self Collapse vs Other Clarity")
    plt.tight_layout()
    plt.savefig("observer_switching_scatter.png")
    plt.close()

    # Histogram: imbalance distribution
    plt.figure(figsize=(8, 6))
    plt.hist(df["imbalance"], bins=20, color="lightblue", edgecolor="k")
    plt.xlabel("Imbalance Value")
    plt.ylabel("Agent Count")
    plt.title("Distribution of Observer Switching Imbalance")
    plt.tight_layout()
    plt.savefig("observer_switching_histogram.png")
    plt.close()

    # Curve: average imbalance vs trauma load
    plt.figure(figsize=(8, 6))
    avg_imbalance = df.groupby(pd.cut(df["trauma_load"], bins=10))["imbalance"].mean()
    avg_imbalance.plot(kind="line", marker="o", color="purple")
    plt.xlabel("Trauma Load (binned)")
    plt.ylabel("Average Imbalance")
    plt.title("Impact of Trauma Load on Observer Switching Dynamics")
    plt.tight_layout()
    plt.savefig("observer_switching_curve.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_observer_switching()
    df.to_csv("observer_switching_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
