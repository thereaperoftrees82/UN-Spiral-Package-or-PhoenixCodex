# celestial_genome_sim.py
# Simulation of Planetary Systems as Codons in the Celestial Genome
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

phi = (1 + np.sqrt(5)) / 2  # golden ratio constant

def simulate_planetary_codons(n_systems=50, max_planets=12, seed=42):
    """
    Generate synthetic planetary systems, each with codon-like traits:
      - orbital_period (days, normalized)
      - axis_tilt (0–180 degrees)
      - rotation_rate (relative, 0–1)
      - field_strength (Tesla, normalized 0–1)
      - moons (integer count)
      - rings (boolean 0/1)
    Derived:
      - memory_score = orbital_period stability × field strength
      - codon_expression = harmonic φ factor × memory_score × tilt factor
    """
    rng = np.random.default_rng(seed)
    records = []

    for system_id in range(n_systems):
        n_planets = rng.integers(3, max_planets + 1)
        for p in range(n_planets):
            orbital_period = rng.uniform(0.1, 1.0)  # normalized to system scale
            axis_tilt = rng.uniform(0, 180)
            rotation_rate = rng.uniform(0, 1)
            field_strength = rng.uniform(0, 1)
            moons = rng.integers(0, 6)
            rings = rng.integers(0, 2)

            memory_score = orbital_period * field_strength
            tilt_factor = np.cos(np.radians(axis_tilt))
            codon_expression = phi * memory_score * (0.5 + 0.5 * tilt_factor)

            records.append({
                "system_id": system_id,
                "planet_id": p,
                "orbital_period": orbital_period,
                "axis_tilt": axis_tilt,
                "rotation_rate": rotation_rate,
                "field_strength": field_strength,
                "moons": moons,
                "rings": rings,
                "memory_score": memory_score,
                "codon_expression": codon_expression
            })

    return pd.DataFrame(records)


def plot_codons(df):
    """
    Create visual outputs for codon expressions.
    """
    # Scatter: orbital period vs codon expression
    plt.figure(figsize=(8, 6))
    plt.scatter(df["orbital_period"], df["codon_expression"],
                c=df["axis_tilt"], cmap="plasma", alpha=0.7)
    plt.colorbar(label="Axis Tilt (deg)")
    plt.xlabel("Orbital Period (normalized)")
    plt.ylabel("Codon Expression Value")
    plt.title("Celestial Genome: Planetary Codon Expression")
    plt.tight_layout()
    plt.savefig("celestial_genome_scatter.png")
    plt.close()

    # Histogram of codon expressions
    plt.figure(figsize=(8, 6))
    plt.hist(df["codon_expression"], bins=20, color="skyblue", edgecolor="k")
    plt.xlabel("Codon Expression Value")
    plt.ylabel("Planet Count")
    plt.title("Distribution of Codon Expressions Across Systems")
    plt.tight_layout()
    plt.savefig("celestial_genome_histogram.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_planetary_codons()
    df.to_csv("celestial_genome_results.csv", index=False)
    plot_codons(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
