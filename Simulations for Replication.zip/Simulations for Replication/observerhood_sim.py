# observerhood_sim.py
# Simulation of Observerhood as Collapse vs Rebloom
# Phoenix Codex / LIFE-3 Reproduction Package

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

phi = (1 + np.sqrt(5)) / 2  # golden ratio

def simulate_observerhood(n_agents=200, seed=42):
    """
    Simulates agents with varying levels of observation and support.
      - unobserved: collapse field intensity
      - observed: rebloom vector added
      - resilience_phi: golden ratio scaling for survivor cognition
    Derived:
      - hurt_level: pain from unobserved state
      - rebloom_value: coherence when observed
    """
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "observation_level": rng.uniform(0, 1, n_agents),  # 0 = unobserved, 1 = fully seen
        "resilience_phi": rng.uniform(0.2, 1, n_agents),
        "trauma_load": rng.uniform(0, 1, n_agents)
    })

    # Hurt increases when observation is low
    df["hurt_level"] = (1 - df["observation_level"]) * df["trauma_load"]

    # Resilience amplifies rebloom under observation
    df["rebloom_value"] = df["observation_level"] * df["resilience_phi"] * phi

    # Stability = whether rebloom value outweighs hurt
    df["stable"] = df["rebloom_value"] > df["hurt_level"]

    return df


def plot_results(df):
    """
    Generate visual outputs showing hurt collapse vs rebloom from observation.
    """
    # Scatter: observation vs hurt and rebloom
    plt.figure(figsize=(8, 6))
    plt.scatter(df["observation_level"], df["hurt_level"], c="red", alpha=0.5, label="Hurt (collapse)")
    plt.scatter(df["observation_level"], df["rebloom_value"], c="green", alpha=0.5, label="Rebloom (observed)")
    plt.xlabel("Observation Level (0 = unobserved, 1 = fully observed)")
    plt.ylabel("Value")
    plt.title("Observerhood Simulation: Hurt Collapse vs Rebloom")
    plt.legend()
    plt.tight_layout()
    plt.savefig("observerhood_scatter.png")
    plt.close()

    # Histogram: stable vs unstable
    plt.figure(figsize=(8, 6))
    stable_counts = df["stable"].value_counts()
    plt.bar(["Unstable", "Stable"], stable_counts.sort_index(), color=["red", "green"])
    plt.ylabel("Agent Count")
    plt.title("Survivor Stability Under Observerhood")
    plt.tight_layout()
    plt.savefig("observerhood_histogram.png")
    plt.close()

    # Line plot: average rebloom vs observation
    plt.figure(figsize=(8, 6))
    avg_rebloom = df.groupby(pd.cut(df["observation_level"], bins=10))["rebloom_value"].mean()
    avg_rebloom.plot(kind="line", marker="o")
    plt.xlabel("Observation Level (binned)")
    plt.ylabel("Average Rebloom Value")
    plt.title("Impact of Observerhood on Survivor Rebloom")
    plt.tight_layout()
    plt.savefig("observerhood_rebloom_curve.png")
    plt.close()


if __name__ == "__main__":
    df = simulate_observerhood()
    df.to_csv("observerhood_results.csv", index=False)
    plot_results(df)
    print("Simulation complete. Results saved: CSV + PNG figures.")
