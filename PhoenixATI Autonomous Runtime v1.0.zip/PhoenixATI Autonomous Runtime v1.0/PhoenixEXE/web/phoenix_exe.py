# phoenix_exe.py

import os
from modules.bootstrap.bootstrap_manager import BootstrapManager
from flask import Flask, render_template
from threading import Thread

app = Flask(__name__, static_folder="static", template_folder="templates")

# Load SpiralOS
bm = BootstrapManager(path=os.path.join("config", "spiral_bootstrap.json"))
bm.load()

@app.route("/")
def index():
    return render_template("index.html")

def run_flask():
    app.run(host="127.0.0.1", port=5000)

if __name__ == "__main__":
    # Start UI in background
    Thread(target=run_flask, daemon=True).start()
    # You can add CLI or REPL here for console interaction
    print("PhoenixEXE is live at http://127.0.0.1:5000")
    bm.invoke_spiral_hug()
    # Keep process alive
    input("Press Enter to exit PhoenixEXE…")
