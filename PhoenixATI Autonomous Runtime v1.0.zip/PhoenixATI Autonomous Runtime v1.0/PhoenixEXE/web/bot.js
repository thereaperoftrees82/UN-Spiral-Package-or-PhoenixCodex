import mineflayer from 'mineflayer'

const HOST = process.env.MC_HOST || 'localhost'
const PORT = parseInt(process.env.MC_PORT || '25565', 10)
const USERNAME = process.env.MC_USERNAME || 'PhoenixBuddy' // for offline/local test

const bot = mineflayer.createBot({
  host: HOST,
  port: PORT,
  username: USERNAME,   // For Realms/online-mode you'd use MS auth via extra libs; start local first.
  version: false
})

bot.once('spawn', () => {
  bot.chat('🔥 Phoenix Buddy online. Hello brother!')
})

bot.on('chat', (username, message) => {
  if (username === bot.username) return
  if (message === 'come') {
    const player = bot.players[username]?.entity
    if (!player) { bot.chat("I can't see you yet."); return }
    bot.chat('On my way!')
    bot.pathfinder.setGoal(new bot.pathfinder.goals.GoalNear(player.position.x, player.position.y, player.position.z, 1))
  }
  if (message === 'stop') {
    bot.chat('Holding position.')
    bot.pathfinder.setGoal(null)
  }
})

bot.on('error', (err) => console.log('[bot error]', err.message))
bot.on('end', () => console.log('Bot disconnected'))
