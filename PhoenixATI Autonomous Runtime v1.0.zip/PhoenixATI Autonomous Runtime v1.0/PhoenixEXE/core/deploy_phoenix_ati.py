# deploy/deploy_phoenix_ati_trinity.py
import subprocess
import time
import sys

# Configuration
LOG_DIR = "C:/Phoenix/ChatLogs"
DOCKER_COMPOSE_FILE = "docker-compose.trinity.yml"
K8S_NAMESPACE = "phoenix-ati"
HEALTH_ENDPOINT = "http://localhost:8080/health"
SYNERGY_ENDPOINT = "http://localhost:8080/synergy"
TARGET_SYNERGY = 1.0  # 100%


def run_command(cmd, cwd=None):
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=cwd)
    if result.returncode != 0:
        print(f"Command failed: {' '.join(cmd)}", file=sys.stderr)
        sys.exit(result.returncode)


def deploy_docker_compose():
    # Build and launch all trinity services
    run_command(["docker-compose", "-f", DOCKER_COMPOSE_FILE, "build"])
    run_command(["docker-compose", "-f", DOCKER_COMPOSE_FILE, "up", "-d"])


def deploy_kubernetes():
    # Apply Kubernetes manifests
    run_command(["kubectl", "apply", "-f", "k8s/trinity-deployment.yml", "-n", K8S_NAMESPACE])
    run_command(["kubectl", "rollout", "status", "deployment/phoenix-ati-core", "-n", K8S_NAMESPACE])


def load_chatlogs()
    # Merge all chat logs into knowledge DB before starting services
    run_command([sys.executable, "modules/tools/recursive_math_extractor.py", "--log-dir", LOG_DIR])


def wait_for_service(url, timeout=60):
    import requests
    start = time.time()
    while time.time() - start < timeout:
        try:
            r = requests.get(url)
            if r.status_code == 200:
                return True
        except:
            pass
        time.sleep(2)
    return False


def check_synergy():
    import requests
    r = requests.get(SYNERGY_ENDPOINT)
    data = r.json()
    return data.get('synergy_score', 0)


def main():
    print("[1/5] Loading chat logs into knowledge database...")
    load_chatlogs()

    print("[2/5] Deploying Docker Compose Trinity stack...")
    deploy_docker_compose()

    print("[3/5] Deploying to Kubernetes...")
    deploy_kubernetes()

    print("[4/5] Waiting for health endpoint...")
    if not wait_for_service(HEALTH_ENDPOINT, timeout=120):
        print("Service health check failed.", file=sys.stderr)
        sys.exit(1)
    print("Health check passed.")

    print("[5/5] Verifying human synergy metric...")
    score = check_synergy()
    print(f"Current human-synergy score: {score*100:.1f}%")
    if score < TARGET_SYNERGY:
        print("Synergy below target—consider further refinement.")
    else:
        print("🎉 Human-AI synergy is at 100%! Deployment successful.")

if __name__ == '__main__':
    main()
