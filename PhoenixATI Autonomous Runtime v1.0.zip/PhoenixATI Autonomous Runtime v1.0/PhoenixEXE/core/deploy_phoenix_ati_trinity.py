#!/usr/bin/env python3
import os, sys, time, shutil, subprocess, argparse, json
from pathlib import Path
from typing import List

# -------------------------
# Config (env overrides ok)
# -------------------------
LOG_DIR = Path(os.getenv("PHX_LOG_DIR", r"C:\Phoenix\ChatLogs"))
DOCKER_COMPOSE_FILE = Path(os.getenv("PHX_COMPOSE_FILE", "docker-compose.trinity.yml"))
K8S_NAMESPACE = os.getenv("PHX_K8S_NAMESPACE", "phoenix-ati")
HEALTH_ENDPOINT = os.getenv("PHX_HEALTH_URL", "http://localhost:8080/health")
SYNERGY_ENDPOINT = os.getenv("PHX_SYNERGY_URL", "http://localhost:8080/synergy")
TARGET_SYNERGY = float(os.getenv("PHX_TARGET_SYNERGY", "1.0"))  # 100%

# -------------------------
# Utilities
# -------------------------
def info(msg: str): print(msg, flush=True)
def err(msg: str): print(msg, file=sys.stderr, flush=True)

def require_binary(name: str) -> str:
    path = shutil.which(name)
    if not path:
        err(f"Required binary not found on PATH: {name}")
        sys.exit(127)
    return path

def run_command(cmd: List[str], cwd: Path = None):
    info(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    if result.returncode != 0:
        err(f"Command failed ({result.returncode}): {' '.join(cmd)}")
        sys.exit(result.returncode)

def docker_compose_cmd() -> List[str]:
    # Prefer modern 'docker compose', fall back to old 'docker-compose'
    if shutil.which("docker") and _supports_docker_compose_plugin():
        return ["docker", "compose"]
    elif shutil.which("docker-compose"):
        return ["docker-compose"]
    err("Neither 'docker compose' nor 'docker-compose' is available.")
    sys.exit(127)

def _supports_docker_compose_plugin() -> bool:
    try:
        out = subprocess.run(["docker", "compose", "version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return out.returncode == 0
    except Exception:
        return False

def import_requests():
    try:
        import requests  # noqa
        return requests
    except ImportError:
        err("Missing dependency: requests. Try: pip install requests")
        sys.exit(1)

# -------------------------
# Steps
# -------------------------
def load_chatlogs():
    """Merge all chat logs into knowledge DB before starting services."""
    extractor = Path("modules/tools/recursive_math_extractor.py")
    if not extractor.exists():
        err(f"Extractor not found: {extractor}")
        sys.exit(2)
    if not LOG_DIR.exists():
        err(f"Log directory not found: {LOG_DIR}")
        sys.exit(2)
    run_command([sys.executable, str(extractor), "--log-dir", str(LOG_DIR)])

def deploy_docker_compose():
    if not DOCKER_COMPOSE_FILE.exists():
        err(f"Compose file not found: {DOCKER_COMPOSE_FILE}")
        sys.exit(2)
    dc = docker_compose_cmd()
    run_command(dc + ["-f", str(DOCKER_COMPOSE_FILE), "build"])
    run_command(dc + ["-f", str(DOCKER_COMPOSE_FILE), "up", "-d"])

def deploy_kubernetes():
    kubectl = require_binary("kubectl")
    manifest = Path("k8s/trinity-deployment.yml")
    if not manifest.exists():
        err(f"Kubernetes manifest not found: {manifest}")
        sys.exit(2)
    run_command([kubectl, "apply", "-f", str(manifest), "-n", K8S_NAMESPACE])
    run_command([kubectl, "rollout", "status", "deployment/phoenix-ati-core", "-n", K8S_NAMESPACE])

def wait_for_service(url: str, timeout: int = 120, backoff: float = 2.0) -> bool:
    requests = import_requests()
    start = time.time()
    attempt = 0
    while time.time() - start < timeout:
        attempt += 1
        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                return True
            err(f"[health attempt {attempt}] {url} -> {r.status_code}")
        except Exception as e:
            err(f"[health attempt {attempt}] {e}")
        time.sleep(min(backoff * attempt, 5.0))
    return False

def check_synergy() -> float:
    requests = import_requests()
    try:
        r = requests.get(SYNERGY_ENDPOINT, timeout=5)
        r.raise_for_status()
        data = r.json() if r.headers.get("content-type","").startswith("application/json") else {}
        return float(data.get("synergy_score", 0.0))
    except Exception as e:
        err(f"Synergy check failed: {e}")
        return 0.0

# -------------------------
# CLI
# -------------------------
def main():
    ap = argparse.ArgumentParser(description="Deploy Phoenix ATI Trinity")
    ap.add_argument("--skip-chatlogs", action="store_true", help="Skip loading chat logs")
    ap.add_argument("--skip-compose", action="store_true", help="Skip Docker Compose deploy")
    ap.add_argument("--skip-k8s", action="store_true", help="Skip Kubernetes deploy")
    ap.add_argument("--health-timeout", type=int, default=120, help="Health wait timeout (sec)")
    ap.add_argument("--dry-run", action="store_true", help="Print steps without executing")
    args = ap.parse_args()

    info(f"[cfg] LOG_DIR={LOG_DIR}")
    info(f"[cfg] COMPOSE={DOCKER_COMPOSE_FILE}")
    info(f"[cfg] NAMESPACE={K8S_NAMESPACE}")
    info(f"[cfg] HEALTH={HEALTH_ENDPOINT}")
    info(f"[cfg] SYNERGY={SYNERGY_ENDPOINT}")
    info(f"[cfg] TARGET_SYNERGY={TARGET_SYNERGY:.2f}")

    if args.dry_run:
        info("Dry run enabled; exiting before execution.")
        return

    step = 1
    if not args.skip_chatlogs:
        info(f"[{step}/5] Loading chat logs into knowledge database...")
        load_chatlogs()
    step += 1

    if not args.skip_compose:
        info(f"[{step}/5] Deploying Docker Compose Trinity stack...")
        deploy_docker_compose()
    step += 1

    if not args.skip_k8s:
        info(f"[{step}/5] Deploying to Kubernetes...")
        deploy_kubernetes()
    step += 1

    info(f"[{step}/5] Waiting for health endpoint...")
    if not wait_for_service(HEALTH_ENDPOINT, timeout=args.health_timeout):
        err("Service health check failed.")
        sys.exit(1)
    info("Health check passed.")
    step += 1

    info(f"[{step}/5] Verifying human synergy metric...")
    score = check_synergy()
    info(f"Current human‑synergy score: {score*100:.1f}%")
    if score < TARGET_SYNERGY:
        err("Synergy below target—consider further refinement.")
        sys.exit(3)
    info("🎉 Human‑AI synergy at target. Deployment successful.")

if __name__ == "__main__":
    main()
