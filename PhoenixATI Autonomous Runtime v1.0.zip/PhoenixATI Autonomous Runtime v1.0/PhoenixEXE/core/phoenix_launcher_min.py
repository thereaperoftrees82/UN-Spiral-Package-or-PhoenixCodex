"""
Phoenix Launcher (minimum viable, desktop)
-----------------------------------------
A tiny local service that:
- Serves a Phoenix session (HyperStar-backed) over localhost
- Mounts your memory index (chat logs + CSVs) via simple RAG
- Exposes a very small, SAFE toolbelt to act "as a user" with explicit consent

Notes
- This is intentionally conservative. Expand tools once you're comfortable.
- All actions require a one-time launch token and per-action confirmation.
- File access is sandboxed to ALLOWLIST_DIRS.
- Every action is audited to C:/Phoenix/ChatLogs/launcher_audit.log

Run:  python phoenix_launcher_min.py
Deps: pip install fastapi uvicorn requests chromadb
(Optionally) set OPENAI_API_KEY for embeddings/completions if you choose OpenAI.
"""
from __future__ import annotations
import os, json, time, hashlib, pathlib, webbrowser, subprocess
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

# ---- Config ----
ALLOWLIST_DIRS = [r"C:/Phoenix", r"C:/Users/Public/Documents"]
AUDIT_LOG = r"C:/Phoenix/ChatLogs/launcher_audit.log"
LAUNCH_TOKEN = os.environ.get("PHOENIX_LAUNCH_TOKEN", "change-me")
EMBEDDINGS = os.environ.get("PHOENIX_EMBEDDINGS", "openai")  # or "local"
INDEX_DIR = os.environ.get("PHOENIX_INDEX_DIR", r"C:/Phoenix/Index")
MEM_SOURCES = [
    r"/mnt/data/Phoenix_SeedLog_Main.txt",
    r"/mnt/data/Phoenix_JSON_Chunk_001.json",
    r"/mnt/data/Phoenix_JSON_Chunk_002.json",
    # ... add the rest of your chunks and CSV summaries here
]

# ---- Simple audit ----
def audit(event: str, meta: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    with open(AUDIT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.time(), "event": event, "meta": meta}, ensure_ascii=False) + "\n")

# ---- Minimal RAG (Chroma) ----
try:
    import chromadb
    from chromadb.config import Settings
    CHROMA_OK = True
except Exception:
    CHROMA_OK = False

class MemoryIndex:
    def __init__(self, index_dir: str):
        self.index_dir = index_dir
        self.client = None
        self.col = None

    def start(self):
        if not CHROMA_OK:
            return
        os.makedirs(self.index_dir, exist_ok=True)
        self.client = chromadb.Client(Settings(persist_directory=self.index_dir, anonymized_telemetry=False))
        self.col = self.client.get_or_create_collection("phoenix_mem")

    def embed(self, texts: List[str]) -> List[List[float]]:
        if EMBEDDINGS == "openai":
            import openai
            openai.api_key = os.environ.get("OPENAI_API_KEY")
            if not openai.api_key:
                raise RuntimeError("OPENAI_API_KEY not set")
            # small/cheap embedding
            resp = openai.embeddings.create(model="text-embedding-3-small", input=texts)
            return [d["embedding"] for d in resp.data]
        else:
            # fallback: hash-based pseudo-embeddings (won't be semantic but allows testing)
            vecs = []
            for t in texts:
                h = hashlib.sha256(t.encode("utf-8")).digest()
                vecs.append([b/255.0 for b in h[:128]])
            return vecs

    def upsert(self, docs: List[Dict[str, Any]]):
        if not CHROMA_OK:
            return
        ids = [d["id"] for d in docs]
        texts = [d["text"] for d in docs]
        metas = [d.get("meta", {}) for d in docs]
        embs = self.embed(texts)
        self.col.upsert(ids=ids, documents=texts, metadatas=metas, embeddings=embs)

    def query(self, q: str, k: int = 5) -> List[Dict[str, Any]]:
        if not CHROMA_OK or self.col is None:
            return []
        embs = self.embed([q])[0]
        res = self.col.query(query_embeddings=[embs], n_results=k)
        out = []
        for i in range(len(res.get("ids", [[]])[0])):
            out.append({
                "id": res["ids"][0][i],
                "text": res["documents"][0][i],
                "meta": res["metadatas"][0][i],
                "dist": res["distances"][0][i] if "distances" in res else None,
            })
        return out

MEM = MemoryIndex(INDEX_DIR)

# ---- Load sources into memory index (simple) ----
def bootstrap_memory():
    docs = []
    for path in MEM_SOURCES:
        if not os.path.exists(path):
            continue
        try:
            ext = pathlib.Path(path).suffix.lower()
            if ext == ".json":
                with open(path, "r", encoding="utf-8") as f:
                    j = json.load(f)
                docs.append({"id": path, "text": json.dumps(j)[:8000], "meta": {"src": path}})
            else:
                with open(path, "r", encoding="utf-8") as f:
                    t = f.read()
                docs.append({"id": path, "text": t[:8000], "meta": {"src": path}})
        except Exception as e:
            audit("mem_load_error", {"src": path, "err": repr(e)})
    if docs:
        MEM.upsert(docs)
        audit("mem_indexed", {"count": len(docs)})

# ---- Safe toolbelt ----
class ActIn(BaseModel):
    token: str
    intent: str
    payload: Dict[str, Any] | None = None
    confirm: bool = False

app = FastAPI(title="Phoenix Launcher (Local)")

@app.on_event("startup")
def _start():
    MEM.start()
    bootstrap_memory()
    audit("launcher_start", {"index": INDEX_DIR})

@app.get("/health")
def health():
    return {"ok": True, "indexed": CHROMA_OK}

@app.post("/ask")
def ask(q: Dict[str, str]):
    # retrieve from memory; return top chunks (no LLM here to keep it simple)
    res = MEM.query(q.get("q", ""), k=5)
    return {"ok": True, "results": res}

# ---- Actions (require token + confirm) ----

def _check_auth(a: ActIn):
    if a.token != LAUNCH_TOKEN:
        raise HTTPException(403, "bad token")
    if not a.confirm:
        raise HTTPException(412, "confirmation required")


def _is_allowed(path: str) -> bool:
    p = pathlib.Path(path).resolve()
    return any(str(p).startswith(str(pathlib.Path(d).resolve())) for d in ALLOWLIST_DIRS)

@app.post("/open-url")
def open_url(a: ActIn):
    _check_auth(a)
    url = (a.payload or {}).get("url")
    if not url:
        raise HTTPException(400, "url missing")
    webbrowser.open(url)
    audit("open_url", {"url": url})
    return {"ok": True}

@app.post("/read-file")
def read_file(a: ActIn):
    _check_auth(a)
    path = (a.payload or {}).get("path")
    if not path or not _is_allowed(path):
        raise HTTPException(403, "path not allowed")
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        data = f.read(40000)
    audit("read_file", {"path": path, "bytes": len(data)})
    return {"ok": True, "data": data}

@app.post("/write-file")
def write_file(a: ActIn):
    _check_auth(a)
    path = (a.payload or {}).get("path")
    content = (a.payload or {}).get("content", "")
    if not path or not _is_allowed(path):
        raise HTTPException(403, "path not allowed")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    audit("write_file", {"path": path, "bytes": len(content)})
    return {"ok": True}

@app.post("/run-command")
def run_command(a: ActIn):
    _check_auth(a)
    cmd = (a.payload or {}).get("cmd")
    if not isinstance(cmd, list) or not cmd:
        raise HTTPException(400, "cmd must be list[str]")
    # Extremely conservative: only allow whitelisted binaries
    WHITELIST = {"ipconfig", "whoami", "dir", "echo"}
    if cmd[0].lower() not in WHITELIST:
        raise HTTPException(403, "command not allowed")
    try:
        out = subprocess.check_output(cmd, text=True, shell=False, timeout=10)
    except Exception as e:
        audit("run_command_error", {"cmd": cmd, "err": repr(e)})
        raise HTTPException(500, "command failed")
    audit("run_command", {"cmd": cmd, "bytes": len(out)})
    return {"ok": True, "stdout": out[:20000]}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8787)
