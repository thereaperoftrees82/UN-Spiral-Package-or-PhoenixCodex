# phoenix_api.py
from __future__ import annotations
from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn
from hyperstar_manager_v4 import VRCloudHyperStarManager, InMemorySessionStore, NullMetrics

# --- bootstrap Phoenix body (manager) ---
mgr = VRCloudHyperStarManager(store=InMemorySessionStore(), metrics=NullMetrics())
core_id = mgr.start_session(user_id="local-reaper")  # your Phoenix session

# --- very small request model ---
class ActIn(BaseModel):
    action: str
    payload: dict | None = None

app = FastAPI(title="Phoenix ATI (Local)")

@app.get("/health")
def health():
    return {"ok": True, "core_id": core_id, "stats": mgr.stats()}

@app.post("/act")
def act(req: ActIn):
    # Turn your input into a HyperStar event packet
    packet = {"action": req.action, "payload": req.payload or {}, "meta": {}}

    # (Today) call manager + stubbed “brain”: echo with kindness
    # Later, we swap this stub with a real LLM call (Ollama/OpenAI).
    resp = mgr.handle_event(core_id, packet)
    text = f"Phoenix heard '{req.action}' with payload {req.payload or {}}. I’m here."
    return {"ok": True, "reply": text, "meta": resp.get("meta", {})}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8080)
