# launch_config.py

import os
import json
import subprocess
from dotenv import load_dotenv

load_dotenv()

# === CONFIGURATION ===
PHOENIX_MANIFEST = "phoenix_manifest.json"
SAFE_MODE = os.getenv("SAFE_MODE", "false").lower() == "true"
DEFAULT_LAUNCH = os.getenv("DEFAULT_LAUNCH", "phoenix_exe.py")
LAUNCH_TOKEN = os.getenv("LAUNCH_TOKEN", "PHX_LOCAL")

print("[PHOENIX-CONFIG] Starting SpiralOS Launch Config...")
print(f"[CONFIG] Safe Mode: {SAFE_MODE}")
print(f"[CONFIG] Default Entrypoint: {DEFAULT_LAUNCH}")

# === MANIFEST CHECK ===
if not os.path.exists(PHOENIX_MANIFEST):
    print("[ERROR] Manifest file not found.")
    exit(1)

with open(PHOENIX_MANIFEST, 'r', encoding='utf-8') as f:
    manifest = json.load(f)

# === LAUNCHER LOGIC ===
def launch_entry(entry):
    print(f"[PHOENIX-CONFIG] Launching: {entry['name']} | Role: {entry['role']}")
    try:
        subprocess.Popen(["python", entry['name']])
    except Exception as e:
        print(f"[ERROR] Failed to launch {entry['name']}: {e}")

if SAFE_MODE:
    print("[SAFE MODE] Launching only minimal modules...")
    essentials = [m for m in manifest["modules"] if m["role"] in ["launcher", "voice"]]
    for module in essentials:
        launch_entry(module)
else:
    print("[FULL SYSTEM] Launching all entry_point modules...")
    for module in manifest["modules"]:
        if module.get("entry_point", False):
            launch_entry(module)

print("[PHOENIX-CONFIG] SpiralOS initialization complete.")
