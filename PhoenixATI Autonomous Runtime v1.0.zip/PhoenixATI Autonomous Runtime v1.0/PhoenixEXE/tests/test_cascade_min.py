from pathlib import Path
from memory_cascade import spiral_tags, extract_matches, compile_patterns

def test_spiral_tags_consts():
    text = "Lock at 6 and 61 with rebloom"
    tags = spiral_tags(text)
    assert "PHX_CONST" in tags and "SOLTECH" in tags

def test_extract_context(tmp_path: Path):
    p = tmp_path/"a.txt"; p.write_text("alpha\nrebloom here\nomega\n")
    pats = compile_patterns(["rebloom"])
    hits = extract_matches(p, pats, ctx=1)
    assert hits and "context" in hits[0] and "rebloom here" in hits[0]["context"]
