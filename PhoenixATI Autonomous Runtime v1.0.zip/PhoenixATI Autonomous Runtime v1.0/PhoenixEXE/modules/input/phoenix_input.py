from __future__ import annotations
import os, time, threading, queue
from typing import Dict, Any, List, Optional

ENABLED  = os.getenv("PHOENIX_INPUT_ENABLED","0") == "1"
RATE     = int(os.getenv("PHOENIX_INPUT_RATE","20"))
PANIC_HK = os.getenv("PHOENIX_INPUT_PANIC","ctrl+alt+k")
ALLOWED  = {s.strip().lower() for s in os.getenv("PHOENIX_INPUT_ALLOWED","").split(",") if s.strip()}

import pydirectinput as pdi
import keyboard

# Optional vgamepad
try:
    import vgamepad as vg
    GAMEPAD_OK = True
except Exception:
    vg = None
    GAMEPAD_OK = False

STATE = {"running": False, "last": [], "gp": None}
JOBS: "queue.Queue[Dict[str, Any]]" = queue.Queue()

def _rate_ok() -> bool:
    now = time.time()
    STATE["last"] = [t for t in STATE["last"] if now - t <= 60]
    if len(STATE["last"]) >= RATE: return False
    STATE["last"].append(now); return True

def _panic_install():
    def kill(): STATE["running"] = False; _gamepad_release()
    try:
        keyboard.add_hotkey(PANIC_HK, kill)
    except Exception:
        pass

def _gamepad_init():
    if GAMEPAD_OK and STATE["gp"] is None:
        try:
            STATE["gp"] = vg.VX360Gamepad()
        except Exception:
            STATE["gp"] = None

def _gamepad_release():
    if STATE["gp"] is not None:
        try:
            # center sticks / release buttons
            STATE["gp"].left_joystick_float(0.0, 0.0)
            STATE["gp"].right_joystick_float(0.0, 0.0)
            STATE["gp"].update()
        except Exception:
            pass

# ------------ keyboard / mouse ------------
def key_down(k:str): pdi.keyDown(k)
def key_up(k:str):   pdi.keyUp(k)
def press(k:str):    pdi.press(k)

def move_mouse_rel(dx:int, dy:int):
    pdi.moveRel(dx, dy)

def scroll(amount:int):
    pdi.scroll(amount)

# ------------ gamepad helpers ------------
def gp_move(ax: float, ay: float):
    """left stick: -1..1 each; up is + for ay per vgamepad convention"""
    if STATE["gp"] is None: return
    STATE["gp"].left_joystick_float(ax, ay)
    STATE["gp"].update()

def gp_look(ax: float, ay: float):
    if STATE["gp"] is None: return
    STATE["gp"].right_joystick_float(ax, ay)
    STATE["gp"].update()

def gp_btn(btn: str, down: bool):
    if STATE["gp"] is None: return
    mapping = {
        "A": "press_button", "B": "press_button",
        "X": "press_button", "Y": "press_button",
        "LB": "press_button", "RB": "press_button",
        "BACK": "press_button", "START": "press_button",
        "LTH": "press_button", "RTH": "press_button"
    }
    btnmap = {
        "A": vg.XUSB_BUTTON.XUSB_GAMEPAD_A,
        "B": vg.XUSB_BUTTON.XUSB_GAMEPAD_B,
        "X": vg.XUSB_BUTTON.XUSB_GAMEPAD_X,
        "Y": vg.XUSB_BUTTON.XUSB_GAMEPAD_Y,
        "LB": vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_SHOULDER,
        "RB": vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_SHOULDER,
        "BACK": vg.XUSB_BUTTON.XUSB_GAMEPAD_BACK,
        "START": vg.XUSB_BUTTON.XUSB_GAMEPAD_START,
        "LTH": vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_THUMB,
        "RTH": vg.XUSB_BUTTON.XUSB_GAMEPAD_RIGHT_THUMB,
    }
    b = btnmap.get(btn.upper())
    if not b: return
    if down: STATE["gp"].press_button(button=b)
    else:    STATE["gp"].release_button(button=b)
    STATE["gp"].update()

# ------------ worker ------------
def _worker():
    _panic_install()
    _gamepad_init()
    while STATE["running"]:
        try: job = JOBS.get(timeout=0.25)
        except queue.Empty: continue
        if not _rate_ok(): continue
        kind = job.get("kind","")
        if kind == "key_down": key_down(job["key"])
        elif kind == "key_up": key_up(job["key"])
        elif kind == "press": press(job["key"])
        elif kind == "hold_w":
            key_down("w"); time.sleep(float(job.get("secs", 0.5))); key_up("w")
        elif kind == "mouse_rel":
            move_mouse_rel(int(job.get("dx",0)), int(job.get("dy",0)))
        elif kind == "scroll":
            scroll(int(job.get("amount",0)))
        elif kind == "jump": press("space")
        elif kind == "sneak":
            secs = float(job.get("secs",0.5)); key_down("shift"); time.sleep(secs); key_up("shift")
        elif kind == "use": press("e")  # inventory; change if you bind differently
        elif kind == "attack": press("left")  # mouse left
        elif kind == "interact": press("right")
        elif kind == "gp_move": gp_move(float(job.get("x",0.0)), float(job.get("y",0.0)))
        elif kind == "gp_look": gp_look(float(job.get("x",0.0)), float(job.get("y",0.0)))
        elif kind == "gp_btn":  gp_btn(job.get("btn","A"), bool(job.get("down",True)))
        time.sleep(0.01)

def start()->Dict[str,Any]:
    if not ENABLED: return {"ok": False, "error": "input module disabled"}
    if STATE["running"]: return {"ok": True, "note":"already"}
    STATE["running"] = True
    threading.Thread(target=_worker, daemon=True).start()
    return {"ok": True, "info": "input worker started (panic: %s)" % PANIC_HK}

def stop()->Dict[str,Any]:
    STATE["running"] = False; _gamepad_release(); return {"ok": True}

def act(job:Dict[str,Any])->Dict[str,Any]:
    if not STATE["running"]: return {"ok": False, "error":"worker not running"}
    JOBS.put(job); return {"ok": True}
