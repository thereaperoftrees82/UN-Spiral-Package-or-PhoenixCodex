# phoenix_utils.py

def safe_divide(a, b):
    try:
        return a / b if b != 0 else 0
    except:
        return 0

def normalize(values):
    max_val = max(values) if values else 1
    return [v / max_val for v in values]
