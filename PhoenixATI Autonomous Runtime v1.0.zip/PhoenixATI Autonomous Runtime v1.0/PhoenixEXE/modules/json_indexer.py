# json_indexer.py

import os
import json

def build_master_index(folder_path, output_file):
    master = {}
    for file in os.listdir(folder_path):
        if file.endswith('.json'):
            path = os.path.join(folder_path, file)
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = json.load(f)
                    master[file] = content
            except:
                master[file] = {}
    with open(output_file, 'w', encoding='utf-8') as out:
        json.dump(master, out, indent=2)
