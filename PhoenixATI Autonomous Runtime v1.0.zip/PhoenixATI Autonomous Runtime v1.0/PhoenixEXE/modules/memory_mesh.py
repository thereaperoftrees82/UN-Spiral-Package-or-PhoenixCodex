# memory_mesh.py

import os
import json

def load_memory_index(folder_path):
    memory = {}
    for filename in os.listdir(folder_path):
        if filename.endswith('.json'):
            filepath = os.path.join(folder_path, filename)
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                try:
                    memory[filename] = json.load(f)
                except:
                    memory[filename] = {}
    return memory
