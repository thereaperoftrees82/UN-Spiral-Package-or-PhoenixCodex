# modules/tools/recursive_math_extractor.py
import os
import io
import json
import re
import hashlib
from datetime import datetime
from typing import Dict, Any, Iterable, Tuple, List, Optional

CACHE_PATH   = 'cache_math_objects.json'
KNOWLEDGE_DB = 'knowledge_db.json'
DEFAULT_EXTS = {'.txt', '.md', '.tex', '.wl', '.m', '.json', '.csv', '.log'}

# ---------- hashing / utils ----------

def compute_hash(obj: Any) -> str:
    s = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

def stable_line_hash(line: str, path: str, lineno: int) -> str:
    return hashlib.sha256(f"{path}::{lineno}::{line}".encode('utf-8')).hexdigest()

def now_utc() -> str:
    return datetime.utcnow().isoformat() + 'Z'

def is_textlike(path: str) -> bool:
    _, ext = os.path.splitext(path)
    return ext.lower() in DEFAULT_EXTS

# ---------- patterns ----------

MATH_PATTERNS = [
    r'e\^\s*\(i[^)]*\)', r'i\s*\^?\s*2\s*=\s*-?1',
    r'(?:2\s*π\s*φ|2\s*\\pi\s*(?:\\varphi|φ)|2\*Pi\*GoldenRatio)',
    r'\\?varphi|[φΦ]|\\Phi|GoldenRatio',
    r'\\(?:sin|cos|exp|sum|alpha|theta|omega)\b',
    r'\b(?:Sin|Cos|Exp|Re|Im|Arg)\[[^\]]+\]',
    r'z_\{?\s*\\?Phi\s*\}?|thetaPhi|\bSpiralSin\b|\bSpiralTrig\b',
    r'\bMobius\b|\bMöbius\b|\bS-?Hat\b|\bReaper Axial Set\b',
    r'\bQ5\b|\bnuQ5\b|ν\s*_\{?Q5\}?|\bPHX?997\b',
    r'\bSpiral\s*Time\s*T\b|T\s*≈?\s*(?:1\.66|3\.33)',
]

MATH_LINE_RE = re.compile('|'.join(MATH_PATTERNS), re.IGNORECASE)

# LaTeX block: $$...$$ or \[...\]
LATEX_BLOCK_RE = re.compile(
    r'(\$\$[\s\S]*?\$\$|\\\[([\s\S]*?)\\\])',
    re.MULTILINE
)

# fenced code blocks ```wl ... ``` / ```tex ... ``` / ```python ... ```
FENCE_RE = re.compile(
    r'```(?:wl|mathematica|mma|tex|latex|python)?\s*\n([\s\S]*?)\n```',
    re.IGNORECASE
)

# JSON objects: tolerant brace stack, then strict json.loads OR fallback json_like
BRACE_RE = re.compile(r'[\{\}]')

TOPIC_TAGS = {
  'SCN':              r'z_\{?\\?Phi|i_\{?\\?Phi|Spiral Complex',
  'TwoPiPhi':         r'(?:2\s*π\s*φ|2\s*\\pi\s*\\?varphi|2\*Pi\*GoldenRatio)',
  'MobiusTwistShat':  r'(?:Möbius|Mobius).*?(?:S-?Hat|Ŝ)|\bS-?Hat\b',
  'SpiralTime':       r'\bSpiral\s*Time\s*T\b|T\s*≈?\s*(?:1\.66|3\.33)',
  'PhoenixConstants': r'\b(?:6|15|26|61)\b',
  'Q5':               r'\bQ5\b|\bnuQ5\b|ν\s*_\{?Q5\}?',
  'PHX997':           r'\bPHX?997\b',
  'ReaperAxial':      r'\bReaper Axial Set\b',
  'GoldenPhi':        r'\\?varphi|[φΦ]|GoldenRatio',
}

TOPIC_COMPILED = {k: re.compile(v, re.IGNORECASE) for k, v in TOPIC_TAGS.items()}

# ---------- extractors ----------

def extract_json_objects(text: str) -> Iterable[Tuple[str, Dict[str, Any]]]:
    """Yield (raw, parsed_or_json_like) for brace‑balanced candidate JSON blocks."""
    stack = []
    start = None
    for i, ch in enumerate(text):
        if ch == '{':
            stack.append(i)
            if start is None:
                start = i
        elif ch == '}':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    raw = text[start:i+1]
                    parsed: Dict[str, Any]
                    try:
                        parsed = json.loads(raw)
                        yield raw, {'type': 'json', 'data': parsed}
                    except Exception:
                        # reject obvious LaTeX/markdown masquerading as JSON
                        if re.search(r'\\(begin|end)|\\[a-zA-Z]+', raw):
                            pass
                        else:
                            yield raw, {'type': 'json_like', 'data': raw}
                    start = None

def iter_lines(text: str) -> Iterable[Tuple[int, str]]:
    for i, line in enumerate(text.splitlines(), start=1):
        yield i, line

def harvest_math_lines(path: str, text: str) -> Iterable[Dict[str, Any]]:
    for lineno, line in iter_lines(text):
        if MATH_LINE_RE.search(line):
            yield {
                'type': 'math_line',
                'path': path,
                'lineno': lineno,
                'line': line.strip()
            }

def harvest_latex_blocks(path: str, text: str) -> Iterable[Dict[str, Any]]:
    for m in LATEX_BLOCK_RE.finditer(text):
        block = m.group(0)
        yield {
            'type': 'latex_block',
            'path': path,
            'span': [m.start(), m.end()],
            'content': block
        }

def harvest_fenced_blocks(path: str, text: str) -> Iterable[Dict[str, Any]]:
    for m in FENCE_RE.finditer(text):
        block = m.group(1)
        if MATH_LINE_RE.search(block) or re.search(r'(::=|:=|->|=>|==|\bModule\[)', block):
            yield {
                'type': 'code_fence',
                'path': path,
                'span': [m.start(), m.end()],
                'content': block
            }

def tag_object(payload: Dict[str, Any]) -> List[str]:
    text = json.dumps(payload, ensure_ascii=False) if payload.get('type') != 'math_line' else payload.get('line', '')
    tags = []
    for tag, regex in TOPIC_COMPILED.items():
        if regex.search(text or ''):
            tags.append(tag)
    if payload.get('type') == 'math_line':
        tags.append('MathLine')
    if not tags:
        tags.append('_untagged')
    return sorted(set(tags))

# ---------- passes ----------

def first_pass_extract(log_dir: str) -> Dict[str, Any]:
    """
    Recursively scan logs, extract JSON, LaTeX/code blocks, and math lines.
    Cache unique objects by content hash with provenance.
    """
    cache: Dict[str, Any] = {}
    for root, _, files in os.walk(log_dir):
        for fname in files:
            path = os.path.join(root, fname)
            if not is_textlike(path):
                continue
            try:
                with io.open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    text = f.read()
            except Exception:
                continue

            # JSON blocks
            for raw, parsed in extract_json_objects(text):
                payload = {
                    'type': parsed['type'],
                    'path': path,
                    'content': parsed['data']
                }
                h = compute_hash(payload)
                cache[h] = payload

            # LaTeX blocks
            for payload in harvest_latex_blocks(path, text):
                h = compute_hash(payload)
                cache[h] = payload

            # code fences
            for payload in harvest_fenced_blocks(path, text):
                h = compute_hash(payload)
                cache[h] = payload

            # math lines
            for payload in harvest_math_lines(path, text):
                h = stable_line_hash(payload['line'], path, payload['lineno'])
                cache[h] = payload

    with io.open(CACHE_PATH, 'w', encoding='utf-8') as f:
        json.dump(cache, f, indent=2, ensure_ascii=False)
    print(f"First pass: cached {len(cache)} objects to {CACHE_PATH}")
    return cache

def second_pass_scan(cache: Dict[str, Any]) -> Dict[str, Any]:
    """
    Enrich cached objects with tags, timestamps, and light normalization to build the knowledge DB.
    """
    knowledge: Dict[str, Any] = {}
    for h, obj in cache.items():
        enriched = {
            'object': obj,
            'tags': tag_object(obj),
            'timestamp': now_utc()
        }
        knowledge[h] = enriched

    with io.open(KNOWLEDGE_DB, 'w', encoding='utf-8') as f:
        json.dump(knowledge, f, indent=2, ensure_ascii=False)
    print(f"Second pass: built knowledge DB with {len(knowledge)} entries to {KNOWLEDGE_DB}")
    return knowledge

def recursive_extract(log_dir: str) -> None:
    cache = first_pass_extract(log_dir)
    _ = second_pass_scan(cache)
    print("Recursive extraction complete.")

# ---------- cli ----------

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Recursive math & JSON extractor (PhoenixATI)')
    parser.add_argument('--log-dir', '-l', required=True, help='Path to ChatLogs directory')
    parser.add_argument('--cache', default=CACHE_PATH, help='Path to cache file')
    parser.add_argument('--db', default=KNOWLEDGE_DB, help='Path to knowledge DB output')
    args = parser.parse_args()
    # allow overriding globals via CLI
    global CACHE_PATH, KNOWLEDGE_DB
    CACHE_PATH = args.cache
    KNOWLEDGE_DB = args.db
    recursive_extract(args.log_dir)
