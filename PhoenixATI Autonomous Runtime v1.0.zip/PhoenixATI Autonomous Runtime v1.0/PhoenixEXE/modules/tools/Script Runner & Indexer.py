# --- Script Runner & Indexer ---
from fastapi import Body
import importlib.util, traceback

def _load_module_from_path(path: str):
    spec = importlib.util.spec_from_file_location("dynmod", path)
    mod = importlib.util.module_from_spec(spec)  # type: ignore
    assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

@app.get("/list-scripts")
def list_scripts():
    base = r"C:/Phoenix/PY"
    out = []
    for root, _, files in os.walk(base):
        for fn in files:
            if fn.lower().endswith(".py"):
                out.append(os.path.join(root, fn))
    return {"ok": True, "count": len(out), "scripts": sorted(out)}

@app.post("/run-script")
def run_script(a: ActIn):
    _check_auth(a)
    path = (a.payload or {}).get("path")
    if not path or not _is_allowed(path):
        raise HTTPException(403, "path not allowed")
    try:
        mod = _load_module_from_path(path)
        # If the script exposes main(), call it; else just load (import side effects)
        main_fn = getattr(mod, "main", None)
        res = main_fn() if callable(main_fn) else {"loaded": True}
        audit("run_script", {"path": path})
        return {"ok": True, "result": res}
    except Exception as e:
        audit("run_script_error", {"path": path, "err": repr(e)})
        return {"ok": False, "error": repr(e), "trace": traceback.format_exc()}

@app.post("/index-now")
def index_now(a: ActIn):
    _check_auth(a)
    idx_path = r"C:/Phoenix/PY/phoenix_indexer.py"
    if not _is_allowed(idx_path):
        raise HTTPException(403, "indexer path not allowed")
    try:
        mod = _load_module_from_path(idx_path)
        res = mod.run_full_index()  # type: ignore
        audit("index_now", {"summary": res})
        return {"ok": True, "summary": res}
    except Exception as e:
        audit("index_now_error", {"err": repr(e)})
        raise HTTPException(500, f"index failed: {e}")
