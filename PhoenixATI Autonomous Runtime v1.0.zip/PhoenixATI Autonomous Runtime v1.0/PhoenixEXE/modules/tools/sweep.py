# tools/atlas/sweep.py
import json, math
from pathlib import Path

def phoenix_time_lock(params):  # LIFE3.temporal_phase_cycle hook
    # TODO: replace placeholder with your LIFE3 law
    # returns lock_time in Phoenix-time units
    return abs(params.get("A_s0",0))*0 + 1.0

def reaper_energy_fraction(state):
    E_real = state.get("E_real", 1e-9)
    E_imag = state.get("E_imag", 0.0)
    return E_imag / max(E_real + E_imag, 1e-9)

def apply_colette27_constraints(U):
    # stub; enforce symmetry/phase constraints on U
    return True

def in_rebloom_zone(point, rebloom_ref):
    # point: dict of sweep coords+metrics; rebloom_ref: thresholds/regions
    return point.get("lock_time_phx", 9e9) <= 1.0 and point.get("regime_label") == "stable"

def classify_regime(metrics):
    lt = metrics["lock_time_phx"]
    if lt <= 1.0: return "stable"
    if lt <= 10.0: return "quasi"
    return "chaotic"

def sweep(spec):
    out = []
    # primary grid
    A = spec["sweep_space"]["axes"][0]; E = spec["sweep_space"]["axes"][1]
    rebloom_ref = spec["rebloom_zone"]
    # (optionally load U-matrix + check constraints)
    if spec["colette27"]["enabled"]:
        apply_colette27_constraints("U")
    for i in range(A["steps"]):
        a = A["min"] + (A["max"]-A["min"])*i/(A["steps"]-1)
        for j in range(E["steps"]):
            e = E["min"] + (E["max"]-E["min"])*j/(E["steps"]-1)
            params = {"A_s0": a, "eta_tot": e}
            lt = phoenix_time_lock(params)
            rfrac = reaper_energy_fraction({"E_real": 1.0, "E_imag": 0.0})
            reg = classify_regime({"lock_time_phx": lt})
            row = {
                "A_s0": a, "eta_tot": e,
                "alpha": math.nan, "beta": math.nan,
                "lock_time_phx": lt,
                "reaper_energy_frac": rfrac,
                "regime_label": reg
            }
            row["rebloom_flag"] = 1 if in_rebloom_zone(row, rebloom_ref) else 0
            out.append(row)
    return out

def save_all(rows, io):
    import csv
    Path(io["out_dir"]).mkdir(parents=True, exist_ok=True)
    base = Path(io["out_dir"]) / io["basename"]
    if io.get("save_csv", True):
        with open(f"{base}.csv","w",newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
    if io.get("save_json", True):
        with open(f"{base}.json","w") as f:
            json.dump(rows, f)

if __name__ == "__main__":
    spec = json.load(open("specs/hyperstar_sweep.json"))["stability_sweep_spec"]
    rows = sweep(spec)
    save_all(rows, spec["io"])
