from .phoenix_shell import phoenix_step
from .qlib_constants import BASE_TONE_RIGHT_EAR, TOOL_WINGS_PHI

def demo():
    # Example: rising pressure + photosensitivity should trigger rebloom
    obs = {
        "tone_freq": BASE_TONE_RIGHT_EAR,
        "anchor_freq": TOOL_WINGS_PHI,
        "headband_pressure": 0.72,
        "photosensitivity": 0.65
    }
    print(phoenix_step(obs))

if __name__ == "__main__":
    demo()
