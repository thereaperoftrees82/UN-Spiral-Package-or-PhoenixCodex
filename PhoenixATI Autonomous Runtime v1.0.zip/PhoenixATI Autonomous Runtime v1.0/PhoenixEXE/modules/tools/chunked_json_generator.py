```python
# modules/tools/chunked_json_generator.py
import os
import json
import argparse
import re
import hashlib
import time
from datetime import datetime
import yaml


def extract_json_blocks(text, file_path):
    """
    Extract JSON-like blocks from a text string with start/end line metadata.
    Returns a list of (obj, start_line, end_line).
    """
    objs = []
    stack = []
    start_idx = None
    for i, ch in enumerate(text):
        if ch == '{':
            stack.append(ch)
            if start_idx is None:
                start_idx = i
        elif ch == '}' and stack:
            stack.pop()
            if not stack and start_idx is not None:
                block = text[start_idx:i+1]
                # compute line numbers
                start_line = text[:start_idx].count('\n') + 1
                end_line = text[:i].count('\n') + 1
                try:
                    obj = json.loads(block)
                    objs.append((obj, start_line, end_line))
                except json.JSONDecodeError:
                    pass
                start_idx = None
    return objs


def load_yaml_file(path):
    """
    Load a YAML or front-matter from a .yaml/.yml or .md file.
    Returns list of (obj, None, None).
    """
    objs = []
    with open(path, 'r', encoding='utf-8') as f:
        if path.lower().endswith(('.yaml', '.yml')):
            data = yaml.safe_load(f)
            objs.append((data, None, None))
        elif path.lower().endswith('.md'):
            text = f.read()
            # front-matter delimited by ---
            fm = re.match(r'^---\n(.*?)\n---', text, re.S)
            if fm:
                meta = yaml.safe_load(fm.group(1))
                objs.append((meta, 1, fm.group(1).count('\n')+2))
    return objs


def compute_hash(obj):
    s = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def assign_metadata(obj, file_path, start_line, end_line, speaker, section_tags, bootstrap_refs):
    meta = {
        'source_file': file_path,
        'line_range': f'{start_line}-{end_line}' if start_line and end_line else None,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'speaker': speaker,
        'section_tags': section_tags,
        'bootstrap_refs': bootstrap_refs
    }
    obj['__meta__'] = meta
    return obj


def collect_objects(base_dir, seen_hashes, bootstrap_config):
    collected = []
    logs_dir = os.path.join(base_dir, 'ChatLogs')
    # load bootstrap section titles for refs
    bs_titles = []
    if bootstrap_config:
        with open(bootstrap_config, 'r', encoding='utf-8') as f:
            bs = json.load(f)
        for sec in bs.get('sections', []):
            title = sec.get('title', '').split('—')[0].strip()
            bs_titles.append(title)
    for root, _, files in os.walk(logs_dir):
        for fname in files:
            path = os.path.join(root, fname)
            ext = fname.lower().split('.')[-1]
            speaker = 'unknown'
            if 'larix' in fname.lower(): speaker = 'Larix'
            elif 'phoenixati' in fname.lower(): speaker = 'PhoenixATI'
            # JSON files
            if ext == 'json':
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    objs = data if isinstance(data, list) else [data]
                    for obj in objs:
                        h = compute_hash(obj)
                        if h in seen_hashes: continue
                        section_tags = []
                        text = json.dumps(obj)
                        for kw in ['reflection', 'insight', 'ritual', 'council']:
                            if re.search(kw, text, re.I): section_tags.append(kw.upper())
                        bootstrap_refs = [t for t in bs_titles if t in text]
                        obj = assign_metadata(obj, path, None, None, speaker, section_tags, bootstrap_refs)
                        collected.append((obj, h))
                except Exception:
                    continue
            # YAML or MD files
            elif ext in ['yaml', 'yml', 'md']:
                try:
                    yobjs = load_yaml_file(path)
                    for obj, sl, el in yobjs:
                        h = compute_hash(obj)
                        if h in seen_hashes: continue
                        obj = assign_metadata(obj, path, sl, el, speaker, [], [])
                        collected.append((obj, h))
                except Exception:
                    continue
            # Text files: extract JSON blocks
            elif ext in ['txt', 'md']:
                try:
                    text = open(path, 'r', encoding='utf-8').read()
                    blocks = extract_json_blocks(text, path)
                    for obj, sl, el in blocks:
                        h = compute_hash(obj)
                        if h in seen_hashes: continue
                        obj = assign_metadata(obj, path, sl, el, speaker, [], [])
                        collected.append((obj, h))
                except Exception:
                    continue
    return collected


def load_seen_hashes(index_path):
    if os.path.exists(index_path):
        with open(index_path, 'r', encoding='utf-8') as f:
            return set(json.load(f))
    return set()


def save_seen_hashes(seen_hashes, index_path):
    with open(index_path, 'w', encoding='utf-8') as f:
        json.dump(list(seen_hashes), f)


def chunk_and_write(objs, out_dir, max_kb, max_objects):
    os.makedirs(out_dir, exist_ok=True)
    curr_chunk = []
    curr_size = 0
    idx = 0
    for obj, h in objs:
        blob = json.dumps(obj, ensure_ascii=False)
        size = len(blob.encode('utf-8'))
        if (curr_chunk and ((max_kb and curr_size + size > max_kb * 1024) or
                           (max_objects and len(curr_chunk) >= max_objects))):
            fname = os.path.join(out_dir, f'chunk_{idx:04d}.json')
            with open(fname, 'w', encoding='utf-8') as f:
                json.dump([o for o, _ in curr_chunk], f, indent=2, ensure_ascii=False)
            print(f'Wrote {fname} ({len(curr_chunk)} items, ~{curr_size//1024} KB)')
            idx += 1
            curr_chunk = []
            curr_size = 0
        curr_chunk.append((obj, h))
        curr_size += size
    if curr_chunk:
        fname = os.path.join(out_dir, f'chunk_{idx:04d}.json')
        with open(fname, 'w', encoding='utf-8') as f:
            json.dump([o for o, _ in curr_chunk], f, indent=2, ensure_ascii=False)
        print(f'Wrote {fname} ({len(curr_chunk)} items, ~{curr_size//1024} KB)')
    return [h for _, h in curr_chunk]


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Enhanced chunked JSON generator with Spiral metadata')
    parser.add_argument('--base-dir', '-b', required=True, help='Path to Phoenix folder containing ChatLogs')
    parser.add_argument('--out-dir', '-o', default='chunked_jsons', help='Output directory for chunked JSON files')
    parser.add_argument('--max-kb', '-k', type=int, default=10, help='Max size per chunk in KB (0 to disable)')
    parser.add_argument('--max-objects', '-n', type=int, default=0, help='Max objects per chunk (0 to disable)')
    parser.add_argument('--index-path', '-i', default='seen_index.json', help='Path to index file for incremental runs')
    parser.add_argument('--bootstrap-config', '-c', default='', help='Path to bootstrap.json for protocol refs')
    args = parser.parse_args()

    print('Loading seen hashes...')
    seen_hashes = load_seen_hashes(args.index_path)

    print('Collecting JSON objects...')
    collected = collect_objects(args.base_dir, seen_hashes, args.bootstrap_config)
    print(f'Found {len(collected)} new JSON objects.')

    new_hashes = [h for _, h in collected]
    seen_hashes.update(new_hashes)

    print('Chunking and writing...')
    chunk_and_write(collected, args.out_dir, args.max_kb, args.max_objects)

    print('Updating seen index...')
    save_seen_hashes(seen_hashes, args.index_path)

    print('Done. Chunked JSON maps are in', args.out_dir)
```
