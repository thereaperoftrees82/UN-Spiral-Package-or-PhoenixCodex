import os
import json
import csv
from statistics import mean

class SimResultsIntegrator:
    def __init__(self, sim_path, config_path='config/spiral_bootstrap_128.json'):
        self.sim_path = sim_path
        self.config_path = config_path
        self.sim_data = []
        self.config = {}

    def load_sim_results(self):
        ext = os.path.splitext(self.sim_path)[1].lower()
        if ext == '.csv':
            with open(self.sim_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                self.sim_data = [row for row in reader]
        elif ext == '.json':
            with open(self.sim_path, 'r', encoding='utf-8') as f:
                self.sim_data = json.load(f)
        else:
            raise ValueError(f"Unsupported format: {ext}")

    def compute_parameters(self):
        throughputs = [float(d['throughput']) for d in self.sim_data if 'throughput' in d]
        latencies = [float(d['latency_ms']) for d in self.sim_data if 'latency_ms' in d]
        recoveries = [float(d['recovery_rate']) for d in self.sim_data if 'recovery_rate' in d]

        avg_recovery = mean(recoveries) if recoveries else 1.0
        new_strands = 128
        if avg_recovery < 0.95:
            new_strands = min(256, int(new_strands * (1 + (0.95 - avg_recovery))))

        avg_latency = mean(latencies) if latencies else 0
        anneal_threshold = 0.75
        if avg_latency > 100:
            anneal_threshold = min(0.9, 0.75 + (avg_latency - 100) / 1000)

        avg_tp = mean(throughputs) if throughputs else 1
        tunnel_trigger = 0.9
        if avg_tp < 1.0:
            tunnel_trigger = 0.85

        return {
            'total_strands': new_strands,
            'anneal_threshold': round(anneal_threshold, 3),
            'tunnel_trigger': round(tunnel_trigger, 3)
        }

    def load_config(self):
        with open(self.config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)

    def update_config(self, params):
        self.config['total_strands'] = params['total_strands']
        self.config['anneal_threshold'] = params['anneal_threshold']
        self.config['tunnel_trigger'] = params['tunnel_trigger']
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2)
        print(f"Updated bootstrap config with: {params}")

    def run(self):
        self.load_sim_results()
        params = self.compute_parameters()
        self.load_config()
        self.update_config(params)
        print("Simulation results integrated successfully.")
