import os, time, hashlib, json, threading
from pathlib import Path
from dotenv import load_dotenv
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from tqdm import tqdm

# OpenAI SDK (Assistants + Files)
from openai import OpenAI

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ASSISTANT_ID   = os.getenv("ASSISTANT_ID")
DATA_DIR       = Path(os.getenv("DATA_DIR", r"C:\Phoenix"))

# Which file types to ingest; extend as you like
INGEST_EXT = {".txt",".md",".json",".csv",".log",".pdf",".docx",".py",".js",".ts",".ipynb"}

STATE_PATH  = Path("ingest_state.json")
BATCH_SIZE  = 8
SLEEP_AFTER = 1.0

client = OpenAI(api_key=OPENAI_API_KEY)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def load_state():
    if STATE_PATH.exists():
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    return {"files": {}}

def save_state(state):
    STATE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")

def should_ingest(path: Path, state) -> bool:
    if not path.exists() or not path.is_file():
        return False
    if path.suffix.lower() not in INGEST_EXT:
        return False
    size = path.stat().st_size
    if size == 0:
        return False
    digest = sha256(path)
    rec = state["files"].get(str(path), {})
    return rec.get("sha") != digest

def attach_files_to_assistant(file_ids):
    # You can also use Vector Stores; this keeps it simple via Files + Retrieval
    # 1) Ensure assistant has "retrieval" enabled in its tools
    # 2) Attach files to the assistant so future runs can use them
    if not file_ids:
        return
    client.beta.assistants.update(
        assistant_id=ASSISTANT_ID,
        tool_resources={"file_search": {"vector_stores": []}},  # leave default if using vector stores
        # Note: For plain Files retrieval, many setups attach files to the *thread* instead.
        # If your assistant expects files per-thread, you can skip this and attach when you start a thread.
    )

def upload_batch(batch_paths, state):
    uploaded_ids = []
    for p in tqdm(batch_paths, desc="Uploading to OpenAI"):
        try:
            with open(p, "rb") as fh:
                f = client.files.create(file=fh, purpose="assistants")
            state["files"][str(p)] = {"sha": sha256(p), "file_id": f.id}
            uploaded_ids.append(f.id)
            time.sleep(SLEEP_AFTER)
        except Exception as e:
            print(f"[WARN] Failed upload {p}: {e}")
    save_state(state)
    attach_files_to_assistant(uploaded_ids)

def initial_scan():
    state = load_state()
    candidates = []
    for root, _, files in os.walk(DATA_DIR):
        for name in files:
            path = Path(root) / name
            if should_ingest(path, state):
                candidates.append(path)
    if candidates:
        # chunk uploads
        for i in range(0, len(candidates), BATCH_SIZE):
            upload_batch(candidates[i:i+BATCH_SIZE], state)
    else:
        print("No changes found. Agent idling.")
    return state

class PhoenixWatcher(FileSystemEventHandler):
    def __init__(self, state):
        self.state = state
        self.pending = set()
        self.lock = threading.Lock()
        self.worker = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker.start()

    def on_created(self, event):
        if not event.is_directory:
            with self.lock:
                self.pending.add(Path(event.src_path))

    def on_modified(self, event):
        if not event.is_directory:
            with self.lock:
                self.pending.add(Path(event.src_path))

    def _worker_loop(self):
        while True:
            time.sleep(2)
            with self.lock:
                batch = [p for p in self.pending if p.exists()]
                self.pending.clear()
            # filter & upload
            todo = [p for p in batch if should_ingest(p, self.state)]
            if todo:
                upload_batch(todo[:BATCH_SIZE], self.state)

def main():
    print(f"Phoenix Desktop Agent watching: {DATA_DIR}")
    state = initial_scan()
    obs = Observer()
    handler = PhoenixWatcher(state)
    obs.schedule(handler, str(DATA_DIR), recursive=True)
    obs.start()
    try:
        while True:
            time.sleep(5)
    except KeyboardInterrupt:
        obs.stop()
    obs.join()

if __name__ == "__main__":
    assert OPENAI_API_KEY, "Set OPENAI_API_KEY in .env"
    assert ASSISTANT_ID,   "Set ASSISTANT_ID in .env"
    assert DATA_DIR.exists(), f"{DATA_DIR} not found"
    main()
