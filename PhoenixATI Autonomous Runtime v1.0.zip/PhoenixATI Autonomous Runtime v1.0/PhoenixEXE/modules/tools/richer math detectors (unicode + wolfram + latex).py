MATH_PATTERNS = [
    r'e\^\s*\(i[^)]*\)', r'i\s*\^?\s*2\s*=\s*-?1',
    r'(?:2\s*π\s*φ|2\s*\\pi\s*(?:\\varphi|φ)|2\*Pi\*GoldenRatio)',
    r'\\varphi|φ|\\Phi|Φ|GoldenRatio',
    r'\\sin|\\cos|\\exp|\\sum|\\alpha|\\theta|\\omega',
    r'\bSin\[[^\]]+\]|\bCos\[[^\]]+\]|\bExp\[[^\]]+\]',
    r'\bRe\[[^\]]+\]|\bIm\[[^\]]+\]|\bArg\[[^\]]+\]',
    r'z_\{?\s*\\Phi\s*\}?|thetaPhi|\bSpiralSin\b|\bSpiralTrig\b',
    r'\bMobius\b|\bMöbius\b|\bS-?Hat\b|\bReaper Axial Set\b',
    r'\bQ5\b|\bPHX997\b|\bSpiral\s*Time\s*T\b',
]
