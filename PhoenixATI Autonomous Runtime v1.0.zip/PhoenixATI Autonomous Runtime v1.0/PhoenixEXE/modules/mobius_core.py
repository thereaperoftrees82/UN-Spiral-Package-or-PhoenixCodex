# mobius_core.py

def mobius_invert(data):
    return list(reversed(data))

def mobius_conjugate(data):
    return [x * -1 for x in data]
