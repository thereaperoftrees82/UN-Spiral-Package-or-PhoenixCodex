# Pseudocode outline
# - walk files
# - extract text per type (txt/md/json/csv/py). docx/pdf stubs left as TODO.
# - emit JSONL + CSV

SUPPORTED = {".txt",".md",".json",".csv",".py"}

def extract_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in {".txt",".md",".py"}:
        return open(path, "r", errors="ignore").read()
    if ext == ".json":
        return json.dumps(json.load(open(path)), ensure_ascii=False)[:200000]
    if ext == ".csv":
        return open(path, "r", errors="ignore").read()[:200000]
    # TODO: docx/pdf via optional deps
    return ""

def tag_rules(text):
    tags = []
    if re.search(r"\bneutrino(s)?\b", text, re.I): tags.append("SCI")
    if re.search(r"\bdark energy\b", text, re.I): tags.append("SCI")
    if re.search(r"\btrauma|healing|surviv(or|al)\b", text, re.I): tags.append("HEAL")
    if re.search(r"\bemo(tion|tional)\b", text, re.I): tags.append("EMO")
    # …extend with your ContextTagger later
    return list(set(tags)) or ["GEN"]

def build(root, out_jsonl="master_index.jsonl", out_csv="master_index.csv"):
    import csv, time
    J = open(out_jsonl, "w", encoding="utf-8")
    C = open(out_csv, "w", newline="", encoding="utf-8")
    cw = csv.writer(C); cw.writerow(["id","path","chunk_ix","bucket","bucket_mobius","ring","tags","tokens"])
    for dirpath,_,files in os.walk(root):
        for fn in files:
            if os.path.splitext(fn)[1].lower() not in SUPPORTED: continue
            path = os.path.join(dirpath, fn)
            text = extract_text(path)
            if not text: continue
            ttags = tag_rules(text[:4000])
            ix = 0
            for body, fprint in chunks(text):
                fp = fingerprint(fprint)
                rec = {
                  "id": hashlib.sha1((path+str(ix)).encode()).hexdigest(),
                  "path": path,
                  "mime": "text/plain",
                  "mtime": os.path.getmtime(path),
                  "chunk_ix": ix,
                  "text": body,
                  "spiral": {
                      "ring": fp["ring"],
                      "phase_deg": fp["theta"]*180/math.pi,
                      "bucket": fp["bucket"],
                      "bucket_mobius": fp["bucket_mobius"]
                  },
                  "simhash": fp["simhash"],
                  "tags": ttags,
                  "language": "auto",
                  "tokens": len(body.split())
                }
                J.write(json.dumps(rec, ensure_ascii=False)+"\n")
                cw.writerow([rec["id"], path, ix, fp["bucket"], fp["bucket_mobius"], f"{fp['ring']:.3f"], "|".join(ttags), rec["tokens"]])
                ix += 1
    J.close(); C.close()
