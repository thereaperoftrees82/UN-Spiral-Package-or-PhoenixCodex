import os, re, json, hashlib, math
from collections import Counter
from spiral_math import PHI, golden_angle, spiral_phase, spiral_ring, phase_bucket, mobius_conjugate_bucket

K_BUCKETS = 89  # prime-ish; tune later
WINDOW = 1500; OVERLAP = 300

def char_trigrams(text, cap=2000):
    text = re.sub(r"\s+", " ", text.lower())
    grams = [text[i:i+3] for i in range(len(text)-2)]
    return Counter(grams).most_common(cap)

def hashed_tf_vector(tris, dim=128):
    v = [0.0]*dim
    for g, c in tris:
        h = int(hashlib.sha1(g.encode()).hexdigest(), 16)
        v[h % dim] += c
    return v

def l2norm(v): 
    return math.sqrt(sum(x*x for x in v))

def rand_proj_2d(v, seed=777):
    # fixed random projection (deterministic)
    import random
    rnd = random.Random(seed)
    R = [[rnd.uniform(-1,1) for _ in v] for _ in range(2)]
    x = sum(R[0][i]*v[i] for i in range(len(v)))
    y = sum(R[1][i]*v[i] for i in range(len(v)))
    return (x,y)

def simhash_bits(tris, bits=64):
    acc = [0]*bits
    for g, c in tris:
        h = int(hashlib.sha1(g.encode()).hexdigest(), 16)
        for b in range(bits):
            acc[b] += c if (h >> b) & 1 else -c
    x = 0
    for b in range(bits):
        if acc[b] >= 0: x |= (1 << b)
    return x

def chunks(text, win=WINDOW, overlap=OVERLAP):
    i = 0; n = len(text)
    tail = ""
    while i < n:
        j = min(i+win, n)
        body = text[i:j]
        fprint_text = (tail + body) if tail else body
        tail = body[-overlap:]
        yield body, fprint_text
        i += (win - overlap)

def fingerprint(fprint_text):
    tris = char_trigrams(fprint_text)
    v = hashed_tf_vector(tris)
    u = rand_proj_2d(v)
    theta = spiral_phase(u)
    ring = spiral_ring(l2norm(v))
    b = phase_bucket(theta, K_BUCKETS)
    bm = mobius_conjugate_bucket(b, K_BUCKETS)
    sh = simhash_bits(tris)
    return dict(theta=theta, ring=ring, bucket=b, bucket_mobius=bm, simhash=f"0x{sh:016x}")
