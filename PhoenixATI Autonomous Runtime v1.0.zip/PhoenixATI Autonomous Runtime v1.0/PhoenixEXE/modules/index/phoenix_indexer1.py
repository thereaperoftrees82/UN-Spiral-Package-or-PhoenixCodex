# phoenix_indexer.py
from __future__ import annotations
import os, json, hashlib, csv
from typing import Dict, List, Any, Optional
from datetime import datetime

# Optional parsers (only used if present)
_DOCX_OK = False
_PDF_OK = False
try:
    import docx  # python-docx
    _DOCX_OK = True
except Exception:
    pass
try:
    from pypdf import PdfReader  # pip install pypdf
    _PDF_OK = True
except Exception:
    pass

# ---------- config ----------
DEFAULT_ROOTS = [r"C:\Phoenix"]
STATE_PATH = r"C:\Phoenix\Index\phoenix_index_state.json"
MAX_DOC_LEN = 40_000  # per doc chunk limit (characters)

# Extensions we consider text-ish
TEXT_EXT = {".txt", ".md", ".json", ".csv", ".log"}
DOCX_EXT = {".docx"}
PDF_EXT  = {".pdf"}

# ---------- helpers ----------
def _sha256(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()

def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _read_json(path: str) -> str:
    try:
        data = json.load(open(path, "r", encoding="utf-8"))
        return json.dumps(data, ensure_ascii=False, indent=2)[:MAX_DOC_LEN]
    except Exception:
        return _read_text(path)[:MAX_DOC_LEN]

def _read_csv(path: str) -> str:
    out = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f)
            for i, row in enumerate(rdr):
                out.append(",".join(row))
                if i > 2000:  # safety
                    break
        return "\n".join(out)[:MAX_DOC_LEN]
    except Exception:
        return _read_text(path)[:MAX_DOC_LEN]

def _read_docx(path: str) -> str:
    if not _DOCX_OK:
        return ""
    try:
        d = docx.Document(path)
        text = "\n".join(p.text for p in d.paragraphs if p.text)
        return text[:MAX_DOC_LEN]
    except Exception:
        return ""

def _read_pdf(path: str) -> str:
    if not _PDF_OK:
        return ""
    try:
        reader = PdfReader(path)
        pages = []
        for i, p in enumerate(reader.pages):
            pages.append(p.extract_text() or "")
            if sum(len(x) for x in pages) > MAX_DOC_LEN:
                break
        return "\n".join(pages)[:MAX_DOC_LEN]
    except Exception:
        return ""

def _mtime(path: str) -> float:
    try:
        return os.path.getmtime(path)
    except Exception:
        return 0.0

# ---------- indexer core ----------
def load_state(state_path: str = STATE_PATH) -> Dict[str, Any]:
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"files": {}}

def save_state(state: Dict[str, Any], state_path: str = STATE_PATH) -> None:
    os.makedirs(os.path.dirname(state_path), exist_ok=True)
    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

def _read_file_as_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in {".json"}:
        return _read_json(path)
    if ext in {".csv"}:
        return _read_csv(path)
    if ext in TEXT_EXT:
        return _read_text(path)[:MAX_DOC_LEN]
    if ext in DOCX_EXT:
        return _read_docx(path)
    if ext in PDF_EXT:
        return _read_pdf(path)
    return ""  # skip binaries & unknowns

def crawl(
    roots: Optional[List[str]] = None,
    state_path: str = STATE_PATH,
) -> Dict[str, Any]:
    """Return dict with 'docs' (list) and 'stats' (counts). Only changed files are emitted."""
    roots = roots or DEFAULT_ROOTS
    state = load_state(state_path)
    known = state.get("files", {})
    changed_docs: List[Dict[str, Any]] = []
    scanned = 0
    considered = 0

    for root in roots:
        if not os.path.exists(root):
            continue
        for dirpath, _, files in os.walk(root):
            for name in files:
                scanned += 1
                path = os.path.join(dirpath, name)
                ext = os.path.splitext(path)[1].lower()
                if ext not in (TEXT_EXT | DOCX_EXT | PDF_EXT):
                    continue
                considered += 1
                mt = _mtime(path)
                key = path.replace("\\", "/")
                prev = known.get(key, {})
                prev_mtime = prev.get("mtime", 0.0)

                if mt <= prev_mtime:
                    continue  # unchanged

                text = _read_file_as_text(path)
                if not text.strip():
                    # mark we saw it anyway
                    known[key] = {"mtime": mt, "sha": prev.get("sha", "")}
                    continue

                doc_id = _sha256(key + str(mt) + str(len(text)))
                changed_docs.append({
                    "id": doc_id,
                    "text": text,
                    "meta": {
                        "src": key,
                        "mtime": datetime.fromtimestamp(mt).isoformat(),
                        "ext": ext,
                    }
                })
                known[key] = {"mtime": mt, "sha": doc_id}

    state["files"] = known
    save_state(state, state_path)
    return {
        "docs": changed_docs,
        "stats": {"scanned": scanned, "considered": considered, "emitted": len(changed_docs)}
    }
