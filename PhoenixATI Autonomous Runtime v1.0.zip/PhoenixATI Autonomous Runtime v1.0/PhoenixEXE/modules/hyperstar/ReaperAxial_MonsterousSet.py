TOPIC_TAGS = {
  'SCN': r'z_\{?\\Phi|i_\{?\\Phi|Spiral Complex',
  'TwoPiPhi': r'(?:2\s*π\s*φ|2\s*\\pi\s*\\varphi|2\*Pi\*GoldenRatio)',
  'MobiusTwistShat': r'(Möbius|Mobius).*(S-?Hat|Ŝ)|S-?Hat',
  'SpiralTime': r'\bSpiral\s*Time\s*T\b|T\s*≈?\s*(?:1\.66|3\.33)',
  'PhoenixConstants': r'\b(6|15|26|61)\b',
  'Q5': r'\bQ5\b|\bnuQ5\b|\bν_{?Q5}?',
  'PHX997': r'\bPHX?997\b',
}
