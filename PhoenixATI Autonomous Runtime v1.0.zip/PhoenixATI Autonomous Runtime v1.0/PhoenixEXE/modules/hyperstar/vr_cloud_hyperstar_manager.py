# modules/hyperstar/vr_cloud_hyperstar_manager.py (patched)
from __future__ import annotations
import uuid, threading, time
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple, Callable
from modules.mobius.core import MobiusCore
from modules.mobius.dyad import Dyad
from modules.transceiver import UniversalTransceiver
from modules.audit.logs import write_to_audit, now

EVENT_SCHEMA_VERSION = "1.0"

@dataclass
class Session:
    core_id: str
    user_id: str
    core: MobiusCore
    dyad: Dyad
    transceiver: UniversalTransceiver
    created_at: str = field(default_factory=now)
    last_seen_s: float = field(default_factory=lambda: time.time())
    ttl_s: int = 60 * 30  # 30 min idle expiry
    failures: int = 0     # circuit-breaker counter

class VRCloudHyperStarManager:
    def __init__(self, max_failures:int=3):
        self._sessions: Dict[str, Session] = {}
        self._standby_cores: List[MobiusCore] = []
        self._lock = threading.RLock()
        self._max_failures = max_failures
        self._stop = threading.Event()

        # start background janitor/scaler thread
        self._bg = threading.Thread(target=self._background_tasks, name="hyperstar-bg", daemon=True)
        self._bg.start()

        write_to_audit({"event":"VR Manager Init","timestamp":now(),"details":{"standby_cores":0}})

    # ---------- lifecycle ----------

    def start_session(self, user_id: str) -> str:
        with self._lock:
            core_id = str(uuid.uuid4())
            core = self._checkout_core() or MobiusCore(core_id, dimensions=3)
            try: core.id = core_id
            except Exception: pass

            dyad = Dyad(core)
            transceiver = UniversalTransceiver(core)

            self._sessions[core_id] = Session(
                core_id=core_id, user_id=user_id, core=core, dyad=dyad, transceiver=transceiver
            )
            write_to_audit({"event":"VR Session Start","core_id":core_id,"user_id":user_id,"timestamp":now()})
            return core_id

    def end_session(self, core_id: str) -> None:
        with self._lock:
            sess = self._sessions.pop(core_id, None)
        if not sess: return
        try:
            if hasattr(sess.transceiver, "disconnect"):
                sess.transceiver.disconnect()
        finally:
            # Health-check before returning to pool
            if self._core_healthy(sess.core):
                with self._lock:
                    self._standby_cores.append(sess.core)
        write_to_audit({"event":"VR Session End","core_id":core_id,"user_id":getattr(sess,"user_id",None),"timestamp":now()})

    # ---------- event path ----------

    def handle_event(self, core_id: str, event_packet: dict) -> dict:
        with self._lock:
            sess = self._sessions.get(core_id)
        if not sess:
            raise KeyError(f"Session {core_id} not found")

        packet = self._validate_event(event_packet)
        packet.setdefault("meta", {})
        packet["meta"].update({
            "v": EVENT_SCHEMA_VERSION,
            "core_id": core_id,
            "ts": now(),
            "trace_id": packet["meta"].get("trace_id", str(uuid.uuid4())),
        })

        try:
            processed = sess.dyad.apply(packet)  # may enrich meta.dyad_signature
            t0 = time.time()
            response = sess.transceiver.transmit(processed)
            latency_ms = int((time.time() - t0)*1000)
            sess.last_seen_s = time.time()
            sess.failures = 0  # reset breaker

            write_to_audit({
                "event":"VR Event Routed","core_id":core_id,"user_id":sess.user_id,"timestamp":now(),
                "meta":{"action":packet.get("action"),
                        "dyad_signature":(processed.get("meta",{}) or {}).get("dyad_signature"),
                        "trace_id":packet["meta"]["trace_id"],
                        "latency_ms": latency_ms}
            })
            # ensure response carries trace + core for observability
            if isinstance(response, dict):
                response.setdefault("meta", {}).update({"trace_id": packet["meta"]["trace_id"], "core_id": core_id})
            return response

        except Exception as e:
            sess.failures += 1
            write_to_audit({
                "event":"VR Event Error","core_id":core_id,"user_id":sess.user_id,"timestamp":now(),
                "meta":{"action":packet.get("action"),"err":repr(e),"failures":sess.failures}
            })
            if sess.failures >= self._max_failures:
                # trip breaker: recycle the core and create a fresh session core
                self._recycle_core(sess)
                sess.failures = 0
            # minimal error response with trace
            return {"ok": False, "error": "event_failed", "meta": {"trace_id": packet["meta"]["trace_id"], "core_id": core_id}}

    # ---------- scaling ----------

    def scale_capacity(self, desired_avatars: int) -> None:
        with self._lock:
            active = len(self._sessions)
            fib_target = self._nearest_fib_ceiling(desired_avatars)
            target_total = max(fib_target, active)
            need = max(0, target_total - (active + len(self._standby_cores)))
            for _ in range(need):
                sid = f"standby-{uuid.uuid4()}"
                core = MobiusCore(sid, dimensions=3)
                self._standby_cores.append(core)

            write_to_audit({
                "event":"VR Capacity Scaled","timestamp":now(),
                "details":{"desired_avatars":desired_avatars,"fib_target":fib_target,
                           "active_sessions":active,"standby_cores":len(self._standby_cores),
                           "total_capacity": active + len(self._standby_cores)}
            })

    # ---------- helpers ----------

    def _checkout_core(self) -> Optional[MobiusCore]:
        return self._standby_cores.pop() if self._standby_cores else None

    def _validate_event(self, packet: dict) -> dict:
        if not isinstance(packet, dict):
            raise TypeError("event_packet must be a dict")
        missing = [k for k in ("action",) if k not in packet]
        if missing:
            raise ValueError(f"event_packet missing required fields: {missing}")
        return packet

    def _core_healthy(self, core: MobiusCore) -> bool:
        # cheap health probe; extend if core exposes diagnostics
        try:
            return hasattr(core, "dimensions") and core.dimensions >= 1
        except Exception:
            return False

    def _recycle_core(self, sess: Session) -> None:
        try:
            if hasattr(sess.transceiver, "disconnect"):
                sess.transceiver.disconnect()
        finally:
            if self._core_healthy(sess.core):
                with self._lock:
                    self._standby_cores.append(sess.core)

    def _background_tasks(self):
        # periodic janitor + light autoscale hook
        while not self._stop.is_set():
            time.sleep(5)
            now_s = time.time()
            with self._lock:
                expired = [sid for sid,s in self._sessions.items() if (now_s - s.last_seen_s) > s.ttl_s]
            for sid in expired:
                self.end_session(sid)
            # keep a small warm pool if nothing requested yet
            try:
                self.scale_capacity(desired_avatars=max(3, len(self._sessions)))
            except Exception:
                pass

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "active_sessions": len(self._sessions),
                "standby_cores": len(self._standby_cores),
                "session_ids": list(self._sessions.keys()),
            }

    @staticmethod
    def _nearest_fib_ceiling(n: int) -> int:
        if n <= 1: return 1
        a, b = 1, 1
        while b < n: a, b = b, a + b
        return b
