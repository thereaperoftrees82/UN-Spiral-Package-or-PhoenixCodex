# modules/hyperstar/mobius_core_16d.py

import numpy as np
import uuid

class MobiusCore16D:
    """
    16-dimensional Mobius core with 2D arms per axis,
    each arm a unit vector in ± one of the 16 coordinate directions.
    """

    def __init__(self):
        self.id = str(uuid.uuid4())
        self.dim = 16
        # Generate 16 basis unit vectors, then both ± directions
        self.arms = self._init_arms()

    def _init_arms(self):
        arms = {}
        for i in range(self.dim):
            basis = np.zeros(self.dim)
            basis[i] = 1.0
            arms[f"axis_{i:+}"] = basis.copy()
            basis[i] = -1.0
            arms[f"axis_{i:-}"] = basis.copy()
        return arms

    def phase_invert(self, vector):
        """
        Möbius inversion in 16D: reflect through the hyperplane
        defined by the sum of all basis axes, then rebloom.
        """
        hyperplane_normal = np.sum(np.eye(self.dim), axis=0)
        hyperplane_normal /= np.linalg.norm(hyperplane_normal)
        # reflect: v' = v - 2*(v·n)*n
        v = np.array(vector)
        v_reflected = v - 2 * np.dot(v, hyperplane_normal) * hyperplane_normal
        return v_reflected

    def connect(self, vector, axis_label):
        """
        Tunnel a data vector along the given arm,
        then apply phase_invert to rebloom on the other side.
        """
        arm = self.arms[axis_label]
        tunneled = vector + arm  # simple displacement
        return self.phase_invert(tunneled)
