class MobiusCore128:
    def __init__(self, dimensions):
        self.dim = dimensions
        # 128 strands: 64 primary + 64 ghost
        self.strands = self._init_strands(128)
    def _init_strands(self, count):
        # generate 'count' unit vectors or labels for arms
        return [f"strand_{i}" for i in range(count)]
# In reinforce():
desired = config['total_strands']  # 128
core.adjust_strands(desired)
