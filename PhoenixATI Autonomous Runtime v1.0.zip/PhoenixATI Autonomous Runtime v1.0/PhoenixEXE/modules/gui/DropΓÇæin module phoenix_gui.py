# C:/Phoenix/EXE/phoenix_gui.py
from __future__ import annotations
import os, time, threading
from typing import Dict, Any, Optional, List, Tuple
import pyautogui as pag
import pygetwindow as gw
import keyboard

# ---------- Config (overridable via .env) ----------
GUI_ENABLED_DEFAULT = os.getenv("PHOENIX_GUI", "0") == "1"
ALLOWED_APPS = [s.strip() for s in os.getenv("PHOENIX_ALLOWED_APPS", "notepad;word;chrome;edge;firefox;minecraft;pycharm;code").split(";") if s.strip()]
GRID_ROWS = int(os.getenv("PHOENIX_GUI_GRID_ROWS", "3"))
GRID_COLS = int(os.getenv("PHOENIX_GUI_GRID_COLS", "3"))
KILL_HOTKEY = os.getenv("PHOENIX_GUI_KILL_HOTKEY", "ctrl+alt+k")

# ---------- State ----------
_gui_enabled = GUI_ENABLED_DEFAULT
_killed = False
_grid_visible = False
_grid_win = None
_lock = threading.RLock()

def is_enabled() -> bool:
    with _lock: return _gui_enabled and not _killed

def enable():
    global _gui_enabled, _killed
    with _lock:
        _killed = False
        _gui_enabled = True
    return {"ok": True, "enabled": True}

def disable():
    global _gui_enabled
    with _lock:
        _gui_enabled = False
    return {"ok": True, "enabled": False}

def kill():
    """Emergency stop (same as pressing the kill hotkey)."""
    global _killed, _gui_enabled
    with _lock:
        _killed = True
        _gui_enabled = False
    hide_grid()
    return {"ok": True, "killed": True}

# Register global kill hotkey once
def _install_kill_switch():
    def on_kill():
        kill()
    try:
        keyboard.add_hotkey(KILL_HOTKEY, on_kill)
    except Exception:
        # Keyboard may need elevation; we still expose kill() via API
        pass

_install_kill_switch()

# ---------- Helpers ----------
def _assert_ready():
    if not is_enabled():
        raise RuntimeError("GUI not enabled (or killed). Call /gui/enable with confirm=true.")

def _allowed_window_titles() -> List[str]:
    return ALLOWED_APPS

def _match_allowed(title: str) -> bool:
    tl = title.lower()
    for token in _allowed_window_titles():
        if token in tl: return True
    return False

def list_windows() -> List[str]:
    titles = [w.title for w in gw.getAllWindows() if w.title]
    return sorted([t for t in titles if _match_allowed(t)])

def focus_window(query: str) -> Dict[str, Any]:
    _assert_ready()
    wins = [w for w in gw.getAllWindows() if w.title and _match_allowed(w.title) and query.lower() in w.title.lower()]
    if not wins:
        return {"ok": False, "error": f"No allowed window matching: {query}"}
    w = wins[0]
    try:
        w.activate()
        time.sleep(0.15)
        return {"ok": True, "focused": w.title}
    except Exception as e:
        return {"ok": False, "error": repr(e)}

def move(x: int, y: int, duration: float = 0.1) -> Dict[str, Any]:
    _assert_ready()
    pag.moveTo(x, y, duration=max(0.0, duration))
    return {"ok": True}

def click(button: str = "left", clicks: int = 1, interval: float = 0.05) -> Dict[str, Any]:
    _assert_ready()
    pag.click(button=button, clicks=clicks, interval=max(0.0, interval))
    return {"ok": True}

def type_text(text: str, interval: float = 0.02) -> Dict[str, Any]:
    _assert_ready()
    pag.typewrite(text, interval=max(0.0, interval))
    return {"ok": True, "typed_len": len(text)}

def hotkey(*keys: str) -> Dict[str, Any]:
    _assert_ready()
    pag.hotkey(*keys)
    return {"ok": True, "hotkey": "+".join(keys)}

def screen_size() -> Tuple[int,int]:
    size = pag.size()
    return (size.width, size.height)

# ---------- Grid Overlay (learning aid) ----------
def show_grid(rows: int = GRID_ROWS, cols: int = GRID_COLS) -> Dict[str, Any]:
    """Draws a translucent numbered grid; click via /gui/grid/cell."""
    global _grid_visible, _grid_win
    _assert_ready()
    if _grid_visible:
        return {"ok": True, "already": True}
    try:
        import tkinter as tk
    except Exception as e:
        return {"ok": False, "error": f"tkinter not available: {e}"}

    w, h = screen_size()
    cell_w, cell_h = w // cols, h // rows

    root = tk.Tk()
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.25)
    root.overrideredirect(True)
    root.geometry(f"{w}x{h}+0+0")
    canvas = tk.Canvas(root, width=w, height=h, highlightthickness=0)
    canvas.pack()

    # lines
    for c in range(1, cols):
        x = c * cell_w
        canvas.create_line(x, 0, x, h)
    for r in range(1, rows):
        y = r * cell_h
        canvas.create_line(0, y, w, y)

    # numbers
    idx = 1
    for r in range(rows):
        for c in range(cols):
            cx, cy = c * cell_w + cell_w//2, r * cell_h + cell_h//2
            canvas.create_text(cx, cy, text=str(idx), font=("Segoe UI", 24))
            idx += 1

    _grid_visible = True
    _grid_win = root

    def _loop():
        try:
            root.mainloop()
        finally:
            hide_grid()

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
    return {"ok": True, "rows": rows, "cols": cols}

def hide_grid() -> Dict[str, Any]:
    global _grid_visible, _grid_win
    if _grid_visible and _grid_win:
        try:
            _grid_win.destroy()
        except Exception:
            pass
    _grid_visible, _grid_win = False, None
    return {"ok": True, "hidden": True}

def grid_cell_click(cell: int, rows: int = GRID_ROWS, cols: int = GRID_COLS, button: str = "left") -> Dict[str, Any]:
    """Click the center of a numbered cell (1..rows*cols)."""
    _assert_ready()
    w, h = screen_size()
    cell_w, cell_h = w // cols, h // rows
    total = rows * cols
    if cell < 1 or cell > total:
        return {"ok": False, "error": f"cell out of range (1..{total})"}
    idx = cell - 1
    r, c = divmod(idx, cols)
    x = c * cell_w + cell_w // 2
    y = r * cell_h + cell_h // 2
    pag.moveTo(x, y, duration=0.08)
    pag.click(button=button)
    return {"ok": True, "x": x, "y": y, "button": button}
