# C:/Phoenix/PY/phoenix_gui.py
from __future__ import annotations
import os, time, threading, queue, subprocess, shlex
from typing import Dict, Any, Optional, List

GUI_ENABLED = os.getenv("PHOENIX_GUI_ENABLED", "0") == "1"
RATE_LIMIT = int(os.getenv("PHOENIX_GUI_RATE", "15"))  # actions/min
ALLOWED = set([s.strip().lower() for s in os.getenv("PHOENIX_GUI_ALLOWED","").split(",") if s.strip()])

# Lazy imports so server can start even if libs missing
pyautogui = None
keyboard = None
win32gui = None
win32process = None

STATE = {
    "running": False,
    "last_actions": [],  # timestamps (s) for rate limiting
    "grid_on": False,
    "worker": None,
}

TASKS: "queue.Queue[Dict[str, Any]]" = queue.Queue()

def _import_libs():
    global pyautogui, keyboard, win32gui, win32process
    if pyautogui is None:
        import pyautogui as _p; _p.FAILSAFE = True; pyautogui = _p
    if keyboard is None:
        import keyboard as _k; keyboard = _k
    if win32gui is None or win32process is None:
        import win32gui as _wg, win32process as _wp
        win32gui, win32process = _wg, _wp

def _rate_ok():
    now = time.time()
    # keep last 60s
    STATE["last_actions"] = [t for t in STATE["last_actions"] if now - t <= 60]
    if len(STATE["last_actions"]) >= RATE_LIMIT:
        return False
    STATE["last_actions"].append(now)
    return True

def _focus_app_by_title(title_substr: str) -> bool:
    # best-effort: bring the first matching window to front
    _import_libs()
    title_substr = title_substr.lower()
    hwnd_found = None

    def enum_handler(hwnd, extra):
        nonlocal hwnd_found
        if win32gui.IsWindowVisible(hwnd):
            t = win32gui.GetWindowText(hwnd).lower()
            if title_substr in t:
                hwnd_found = hwnd
                return False
        return True

    win32gui.EnumWindows(lambda h, _: enum_handler(h, None), None)
    if hwnd_found:
        win32gui.SetForegroundWindow(hwnd_found)
        return True
    return False

def _launch_app(cmd: str) -> Dict[str, Any]:
    exe = os.path.basename(cmd).lower()
    if exe not in ALLOWED:
        return {"ok": False, "error": f"app not allowed: {exe}"}
    try:
        if os.path.exists(cmd):
            subprocess.Popen([cmd], shell=False)
        else:
            subprocess.Popen(shlex.split(cmd), shell=False)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": repr(e)}

def _worker_loop():
    _import_libs()
    # Dead-man switch: press ESC to stop everything
    def _stopper():
        keyboard.wait("esc")
        STATE["running"] = False
    threading.Thread(target=_stopper, daemon=True).start()

    while STATE["running"]:
        try:
            job = TASKS.get(timeout=0.25)
        except queue.Empty:
            continue
        if not _rate_ok():
            continue  # silently drop if too fast

        kind = job.get("kind")
        if kind == "move":
            x, y = int(job["x"]), int(job["y"])
            d = float(job.get("duration", 0.15))
            pyautogui.moveTo(x, y, duration=d)
        elif kind == "click":
            b = job.get("button","left")
            c = int(job.get("clicks",1))
            pyautogui.click(button=b, clicks=c, interval=0.05)
        elif kind == "type":
            text = job.get("text","")
            pyautogui.typewrite(text, interval=0.02)
        elif kind == "hotkey":
            keys: List[str] = job.get("keys", [])
            if keys:
                pyautogui.hotkey(*keys)
        elif kind == "scroll":
            amt = int(job.get("amount", -500))
            pyautogui.scroll(amt)
        elif kind == "launch":
            _launch_app(job.get("cmd",""))
        elif kind == "focus":
            _focus_app_by_title(job.get("title",""))
        # small delay to be humane
        time.sleep(0.05)

def start() -> Dict[str, Any]:
    if not GUI_ENABLED:
        return {"ok": False, "error": "GUI module disabled (PHOENIX_GUI_ENABLED=0)"}
    if STATE["running"]:
        return {"ok": True, "note": "already running"}
    STATE["running"] = True
    t = threading.Thread(target=_worker_loop, daemon=True)
    STATE["worker"] = t
    t.start()
    return {"ok": True, "info": "GUI worker started (ESC to stop)"}

def stop() -> Dict[str, Any]:
    STATE["running"] = False
    return {"ok": True}

def enqueue(job: Dict[str, Any]) -> Dict[str, Any]:
    if not STATE["running"]:
        return {"ok": False, "error": "GUI not running"}
    TASKS.put(job)
    return {"ok": True}

# -------- Overlay Grid (optional) ----------
# Simple numbered grid for learning; press ESC to close (same stopper)
_grid_thread = None
def show_grid(step: int = 200) -> Dict[str, Any]:
    global _grid_thread
    try:
        import tkinter as tk
    except Exception as e:
        return {"ok": False, "error": f"tkinter not available: {e}"}

    def _grid():
        root = tk.Tk()
        root.attributes("-topmost", True)
        root.attributes("-alpha", 0.25)
        root.overrideredirect(True)
        w = root.winfo_screenwidth()
        h = root.winfo_screenheight()
        canvas = tk.Canvas(root, width=w, height=h, highlightthickness=0)
        canvas.pack()
        idx = 1
        for x in range(0, w, step):
            canvas.create_line(x, 0, x, h)
            for y in range(0, h, step):
                if x == 0: canvas.create_line(0, y, w, y)
                canvas.create_text(x+10, y+10, text=str(idx), anchor="nw", font=("Segoe UI", 9))
                idx += 1
        root.bind("<Escape>", lambda e: root.destroy())
        root.mainloop()

    _grid_thread = threading.Thread(target=_grid, daemon=True)
    _grid_thread.start()
    STATE["grid_on"] = True
    return {"ok": True, "info": "Grid shown (press ESC to close)"}
