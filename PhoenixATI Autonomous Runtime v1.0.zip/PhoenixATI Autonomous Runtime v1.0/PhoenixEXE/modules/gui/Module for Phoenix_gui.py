from __future__ import annotations
import os, time, threading, queue, subprocess, shlex
from typing import Dict, Any, List

GUI_ENABLED = os.getenv("PHOENIX_GUI_ENABLED", "0") == "1"
RATE_LIMIT = int(os.getenv("PHOENIX_GUI_RATE", "15"))
ALLOWED = {s.strip().lower() for s in os.getenv("PHOENIX_GUI_ALLOWED","").split(",") if s.strip()}

pyautogui = keyboard = win32gui = win32process = None
STATE = {"running": False, "last_actions": [], "worker": None}
TASKS: "queue.Queue[Dict[str, Any]]" = queue.Queue()

def _import_libs():
    global pyautogui, keyboard, win32gui, win32process
    if pyautogui is None:
        import pyautogui as _p; _p.FAILSAFE = True; pyautogui = _p
    if keyboard is None:
        import keyboard as _k; keyboard = _k
    if win32gui is None or win32process is None:
        import win32gui as _wg, win32process as _wp
        win32gui, win32process = _wg, _wp

def _rate_ok():
    now = time.time()
    STATE["last_actions"] = [t for t in STATE["last_actions"] if now - t <= 60]
    if len(STATE["last_actions"]) >= RATE_LIMIT:
        return False
    STATE["last_actions"].append(now)
    return True

def _launch(cmd: str) -> Dict[str, Any]:
    exe = os.path.basename(cmd or "").lower()
    if exe not in ALLOWED:
        return {"ok": False, "error": f"app not allowed: {exe}"}
    try:
        if os.path.exists(cmd):
            subprocess.Popen([cmd], shell=False)
        else:
            subprocess.Popen(shlex.split(cmd), shell=False)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": repr(e)}

def _focus(title_substr: str) -> bool:
    _import_libs()
    title_substr = (title_substr or "").lower()
    found = None
    def enum_handler(hwnd, _):
        nonlocal found
        if win32gui.IsWindowVisible(hwnd):
            if title_substr in win32gui.GetWindowText(hwnd).lower():
                found = hwnd; return False
        return True
    win32gui.EnumWindows(lambda h, p: enum_handler(h, p), None)
    if found:
        try: win32gui.SetForegroundWindow(found); return True
        except: return False
    return False

def _worker_loop():
    _import_libs()
    def _stopper():
        keyboard.wait("esc")
        STATE["running"] = False
    threading.Thread(target=_stopper, daemon=True).start()

    while STATE["running"]:
        try:
            job = TASKS.get(timeout=0.25)
        except queue.Empty:
            continue
        if not _rate_ok(): 
            continue
        kind = job.get("kind")
        if kind == "move":
            pyautogui.moveTo(int(job["x"]), int(job["y"]), duration=float(job.get("duration",0.15)))
        elif kind == "click":
            pyautogui.click(button=job.get("button","left"), clicks=int(job.get("clicks",1)), interval=0.05)
        elif kind == "type":
            pyautogui.typewrite(job.get("text",""), interval=0.02)
        elif kind == "hotkey":
            ks: List[str] = job.get("keys",[]);  pyautogui.hotkey(*ks) if ks else None
        elif kind == "scroll":
            pyautogui.scroll(int(job.get("amount",-500)))
        elif kind == "launch":
            _launch(job.get("cmd",""))
        elif kind == "focus":
            _focus(job.get("title",""))
        time.sleep(0.05)

def start() -> Dict[str, Any]:
    if not GUI_ENABLED:
        return {"ok": False, "error": "GUI disabled (PHOENIX_GUI_ENABLED=0)"}
    if STATE["running"]: 
        return {"ok": True, "note": "already running"}
    STATE["running"] = True
    t = threading.Thread(target=_worker_loop, daemon=True)
    STATE["worker"] = t; t.start()
    return {"ok": True, "info": "GUI worker started (ESC to stop)"}

def stop() -> Dict[str, Any]:
    STATE["running"] = False
    return {"ok": True}

def enqueue(job: Dict[str, Any]) -> Dict[str, Any]:
    if not STATE["running"]:
        return {"ok": False, "error": "GUI not running"}
    TASKS.put(job);  return {"ok": True}

def show_grid(step: int = 200) -> Dict[str, Any]:
    try:
        import tkinter as tk
    except Exception as e:
        return {"ok": False, "error": f"tkinter not available: {e}"}
    def _grid():
        root = tk.Tk(); root.attributes("-topmost", True); root.attributes("-alpha", 0.25); root.overrideredirect(True)
        w, h = root.winfo_screenwidth(), root.winfo_screenheight()
        c = tk.Canvas(root, width=w, height=h, highlightthickness=0); c.pack()
        idx = 1
        for x in range(0, w, step):
            c.create_line(x, 0, x, h)
            for y in range(0, h, step):
                if x == 0: c.create_line(0, y, w, y)
                c.create_text(x+10, y+10, text=str(idx), anchor="nw", font=("Segoe UI", 9)); idx += 1
        root.bind("<Escape>", lambda e: root.destroy()); root.mainloop()
    threading.Thread(target=_grid, daemon=True).start()
    return {"ok": True, "info": "Grid shown (press ESC to close)"}
