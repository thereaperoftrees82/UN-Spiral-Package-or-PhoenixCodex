# modules/transceiver.py (router)
class UniversalTransceiver:
    def __init__(self, core):
        self.core = core
        self.adapters = {
            "web": WebTransceiver(browser=YourPlaywrightWrapper()),
            "reddit": RedditTransceiver(oauth=...),
            "youtube": YouTubeTransceiver(oauth=...),
            "minecraft": MinecraftTransceiver(conn=...),
        }

    def transmit(self, packet):
        act = packet.get("action","")
        prefix = act.split(".",1)[0]  # e.g., "web.navigate" -> "web"
        tx = self.adapters.get(prefix)
        if not tx:
            return {"ok": False, "error": "no_adapter", "meta": packet.get("meta")}
        return tx.transmit(packet)

    def disconnect(self):
        for tx in self.adapters.values():
            if hasattr(tx, "disconnect"): tx.disconnect()
