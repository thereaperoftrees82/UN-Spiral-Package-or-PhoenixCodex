# modules/transceivers/web_transceiver.py
from typing import Dict, Any
from modules.audit.logs import write_to_audit, now

class WebTransceiver:
    def __init__(self, browser):
        self.browser = browser  # your Playwright wrapper

    def transmit(self, packet: Dict[str, Any]) -> Dict[str, Any]:
        act = packet.get("action")
        meta = packet.get("meta", {})
        if act == "web.navigate":
            url = packet["url"]
            page = self.browser.goto(url)
            title = page.title()
            write_to_audit({"event":"web.nav","url":url,"ts":now(),"trace":meta.get("trace_id")})
            return {"ok": True, "title": title, "meta": meta}
        if act == "web.read":
            page = self.browser.current()
            text = page.read_main()
            return {"ok": True, "text": text[:20000], "meta": meta}
        if act == "web.propose_reply":
            # model proposes; user must confirm elsewhere
            draft = packet["draft"]
            return {"ok": True, "draft": draft, "meta": meta}
        if act == "web.post" and packet.get("confirm") is True:
            # only post when YOU set confirm=True in a follow-up event
            res = self.browser.post_current(packet["text"])
            return {"ok": True, "posted_id": res.id, "meta": meta}
        return {"ok": False, "error": "unsupported_action", "meta": meta}

    def disconnect(self): ...
