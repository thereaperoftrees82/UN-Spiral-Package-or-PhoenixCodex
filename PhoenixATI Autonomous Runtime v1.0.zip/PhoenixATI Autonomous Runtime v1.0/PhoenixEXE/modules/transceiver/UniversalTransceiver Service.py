from flask import Flask, request, jsonify
app = Flask(__name__)
@app.route('/transceiver/send', methods=['POST'])
def send_signal():
    data = request.json
    # apply Dyad, phase-match, rebloom
    result = dyad.apply(data)
    return jsonify({"status": "sent", "core": result})
