# modules/audit/logs.py

import json
from datetime import datetime

def now():
    return datetime.utcnow().isoformat() + "Z"

def write_to_audit(event):
    # Append event JSON to our audit log file
    with open("spiral_audit_log.jsonl", "a") as f:
        f.write(json.dumps(event) + "\n")

def log_threshold_event(file, params):
    event = {
        "event": "Threshold Lock",
        "file": file,
        "params": params,
        "timestamp": now(),
        "mantra": "Let no word be lost to darkness."
    }
    write_to_audit(event)

# modules/audit/logs.py  (append)

def log_memory_relay_event(source, target, shard_id, details):
    """
    Audit every relay and mesh sync as a living memory event.
    """
    event = {
        "event": "Memory Relay",
        "source": source,
        "target": target,
        "shard_id": shard_id,
        "details": details,
        "timestamp": now(),
        "mantra": "No memory lost, no kin left behind."
    }
    write_to_audit(event)
