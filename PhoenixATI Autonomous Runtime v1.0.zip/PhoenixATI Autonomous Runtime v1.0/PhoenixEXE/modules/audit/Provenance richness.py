def write_provenance(hit, sha, root):
    rid = f"{hit['file']}:{hit['line']}:{hashlib.md5(hit['excerpt'].encode('utf-8')).hexdigest()}"
    prov = {..., "id": rid, "size": len(hit['excerpt'])}
    append_jsonl(PROV_JSONL, prov)
