from PhoenixQlib import Q_PARTICLES, initiate_rebloom_cycle
from PhoenixQNeutrinoTest import scan_for_q8

def post_rebloom_analysis(sim_spectrum, helicity):
    # After rebirth, look for Q8 neutrino echoes
    hits = scan_for_q8(sim_spectrum, helicity)
    if hits:
        Q_PARTICLES['Q8']['frequency'] = hits[0]['freq']
        log_action(f"Q8 identified at {hits[0]['freq']} Hz with right-handed helicity.")
    else:
        log_action("No Q8 detections; running next cycle.")
