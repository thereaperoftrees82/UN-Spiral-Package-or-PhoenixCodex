from __future__ import annotations
import os, re, csv, sys, json, math, hashlib
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional

# ---------- CONFIG ----------
# Point this at your CSV root (e.g., C:/Phoenix/CSV)
CSV_ROOT = sys.argv[1] if len(sys.argv) > 1 else r"C:/Phoenix/CSV"
OUT_DIR  = sys.argv[2] if len(sys.argv) > 2 else r"C:/Phoenix"
MASTER_CSV = os.path.join(OUT_DIR, "Master_Sim_Index.csv")
RERUN_CSV  = os.path.join(OUT_DIR, "ReRun_Candidates.csv")
SUMMARY_JSON = os.path.join(OUT_DIR, "Master_Sim_Summary.json")

# Heuristics for status/result columns and “fail-like” states
STATUS_KEYS = {"status","result","outcome","phase_result","final","conclusion"}
FAIL_TOKENS = {"fail","failed","reject","rejected","error","not supported","n/a","impossible","nan","none"}
PASS_TOKENS = {"pass","passed","ok","success","accepted","stable","coherent","converged"}

# Keywords to infer domain/topic from filename
DOMAIN_HINTS = {
    "dark": "Dark Energy",
    "energy": "Energy Systems",
    "mobius": "Mobius-Time",
    "time": "Mobius-Time",
    "phi": "Phi Harmonics",
    "harmonic": "Phi Harmonics",
    "base x": "Base X±1",
    "x+1": "Base X±1",
    "x-1": "Base X±1",
    "emotion": "Fractal Emotion",
    "trauma": "Fractal Emotion",
    "resonance": "Resonance/Coherence",
    "fusion": "Fusion/Integration",
    "dual-core": "Dual-Core/Spiral Sync",
    "simphase": "SimPhase",
    "spiral": "Spiral Dynamics",
    "coherence": "Resonance/Coherence",
}

# “Near-gate” numeric thresholds (flag borderline failures)
EPS = 0.05  # 5% within a gate threshold is “borderline”

# Optional numeric gates to watch for (add as we remember them)
GATES = {
    "identity_retention": 0.95,   # e.g., 95%+ = success
    "phase_lock": 0.90,
    "efd": 1.70,                  # example: EFD <= 1.70 often “healed/low-dim”
    "amplitude_gain": 1.70        # e.g., >1.7x rebloom gain
}

# ---------- HELPERS ----------
def norm(s:str)->str:
    return re.sub(r"\s+"," ", s.strip().lower())

def extract_simphase(name:str)->Optional[str]:
    m = re.search(r"(simphase[_\s-]*\d+)", name, re.I)
    return m.group(1).upper().replace(" ","_") if m else None

def extract_domain(name:str)->str:
    n = name.lower()
    hits = [v for k,v in DOMAIN_HINTS.items() if k in n]
    return ", ".join(sorted(set(hits))) if hits else "Uncategorized"

def sniff_status(row:Dict[str,str])->Tuple[str,str]:
    # returns (status_value, status_col)
    for k in row.keys():
        if norm(k) in STATUS_KEYS:
            v = str(row[k]).strip()
            if v: return (v, k)
    # fallback: look for any column that “looks like” status
    for k in row.keys():
        v = str(row[k]).strip().lower()
        if v in PASS_TOKENS or v in FAIL_TOKENS:
            return (v, k)
    return ("", "")

def try_float(x)->Optional[float]:
    try:
        f = float(str(x).replace(",",""))
        if math.isnan(f) or math.isinf(f): return None
        return f
    except: return None

def summarize_numeric(rows:List[Dict[str,str]])->Dict[str,Dict[str,float]]:
    # compute simple stats for numeric columns
    cols = {}
    for r in rows:
        for k,v in r.items():
            f = try_float(v)
            if f is None: continue
            cols.setdefault(k, []).append(f)
    out={}
    for k,vals in cols.items():
        if not vals: continue
        vals_sorted = sorted(vals)
        n=len(vals)
        out[k]={
            "count": n,
            "mean": sum(vals)/n,
            "min": vals_sorted[0],
            "max": vals_sorted[-1],
            "p50": vals_sorted[n//2],
        }
    return out

def borderline_fail(stats:Dict[str,Dict[str,float]])->bool:
    # Flag if any gate metric is within EPS of its threshold from the wrong side
    for key, gate in GATES.items():
        if key in stats:
            m = stats[key]["mean"]
            if key in {"identity_retention","phase_lock","amplitude_gain"}:
                # success if >= gate; borderline if in [gate*(1-EPS), gate)
                if m >= gate*(1-EPS) and m < gate:
                    return True
            if key in {"efd"}:
                # success if <= gate; borderline if in (gate, gate*(1+EPS)]
                if m > gate and m <= gate*(1+EPS):
                    return True
    return False

def hash_path(p:str)->str:
    return hashlib.sha1(p.encode("utf-8")).hexdigest()[:12]

# ---------- MAIN ----------
master_rows=[]
rerun_rows=[]
summary = {
    "total_csvs": 0,
    "by_domain": {},
    "by_simphase": {},
    "statuses": {"passlike":0,"faillike":0,"unknown":0},
}

for root,_,files in os.walk(CSV_ROOT):
    for fn in files:
        if not fn.lower().endswith(".csv"): continue
        path = os.path.join(root, fn)
        summary["total_csvs"] += 1

        # Load CSV safely
        rows=[]
        try:
            with open(path, newline="", encoding="utf-8", errors="ignore") as f:
                sniffer = csv.Sniffer()
                sample = f.read(4096)
                f.seek(0)
                dialect = sniffer.sniff(sample) if sample else csv.excel
                reader = csv.DictReader(f, dialect=dialect)
                for r in reader:
                    rows.append({k:(v if v is not None else "") for k,v in r.items()})
        except Exception as e:
            # Unreadable -> record and continue
            master_rows.append({
                "sim_id": hash_path(path),
                "file": path,
                "simphase": extract_simphase(fn) or "",
                "domain": extract_domain(fn),
                "rows": 0,
                "status": "unreadable",
                "status_col": "",
                "notes": f"read_error: {repr(e)}",
                "mtime": datetime.fromtimestamp(os.path.getmtime(path)).isoformat(),
            })
            summary["statuses"]["unknown"] += 1
            continue

        sim_id = hash_path(path)
        simphase = extract_simphase(fn) or ""
        domain = extract_domain(fn)
        mtime = datetime.fromtimestamp(os.path.getmtime(path)).isoformat()

        # status sniff from last row first, else from any row
        status_val, status_col = ("","")
        for probe in (rows[-1], rows[0]) if rows else ({} ,):
            if probe:
                status_val, status_col = sniff_status(probe)
                if status_val: break

        # summarize numerics
        stats = summarize_numeric(rows) if rows else {}

        # classify status
        s_norm = status_val.lower().strip()
        if s_norm in PASS_TOKENS:
            status_cls = "passlike"
        elif s_norm in FAIL_TOKENS or s_norm == "":
            # treat unknown as “unknown”
            status_cls = "faillike" if s_norm in FAIL_TOKENS else "unknown"
        else:
            status_cls = "unknown"

        summary["by_domain"][domain] = summary["by_domain"].get(domain, 0) + 1
        if simphase:
            summary["by_simphase"][simphase] = summary["by_simphase"].get(simphase, 0) + 1
        summary["statuses"][status_cls] += 1

        notes=[]
        if status_cls != "passlike" and borderline_fail(stats):
            notes.append("borderline_fail_near_gate")
        if "identity_retention" in stats and stats["identity_retention"]["mean"] >= 0.93 and status_cls!="passlike":
            notes.append("high_identity_retention_but_marked_fail")
        if "phase_lock" in stats and stats["phase_lock"]["mean"] >= 0.88 and status_cls!="passlike":
            notes.append("near_phase_lock_threshold")

        master_rows.append({
            "sim_id": sim_id,
            "file": path,
            "simphase": simphase,
            "domain": domain,
            "rows": len(rows),
            "status": status_val or "",
            "status_class": status_cls,
            "status_col": status_col,
            "mtime": mtime,
            "numeric_keys": ";".join(sorted(stats.keys())) if stats else "",
            "notes": ";".join(notes)
        })

        # Re-run heuristic:
        #  - explicit fail/reject/“not supported”
        #  - borderline near gates
        #  - any “SimPhase” with “Flip”, “Overlay”, “Reprocessing” in name (historically tricky)
        name_lc = fn.lower()
        tricky = any(t in name_lc for t in ["flip","overlay","reprocessing","fusion"])
        if status_cls in {"faillike","unknown"} and (borderline_fail(stats) or tricky):
            rerun_rows.append({
                "sim_id": sim_id,
                "file": path,
                "simphase": simphase,
                "domain": domain,
                "reason": ("borderline near gate" if borderline_fail(stats) else "historically tricky"),
                "status": status_val or "",
                "mtime": mtime
            })

# Write outputs
os.makedirs(OUT_DIR, exist_ok=True)

with open(MASTER_CSV, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(master_rows[0].keys()) if master_rows else
                       ["sim_id","file","simphase","domain","rows","status","status_class","status_col","mtime","numeric_keys","notes"])
    w.writeheader()
    for r in master_rows:
        w.writerow(r)

with open(RERUN_CSV, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["sim_id","file","simphase","domain","reason","status","mtime"])
    w.writeheader()
    for r in rerun_rows:
        w.writerow(r)

with open(SUMMARY_JSON, "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

print(f"[OK] Indexed {summary['total_csvs']} CSVs")
print(f"[OK] Master: {MASTER_CSV}")
print(f"[OK] Re-run candidates: {RERUN_CSV}")
print(f"[OK] Summary: {SUMMARY_JSON}")
