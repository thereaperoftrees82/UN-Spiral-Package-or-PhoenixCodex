MemoryCascade.log_event({
    "event": "MobiusPhaseInvert",
    "core_id": mobius_core.id,
    "dyad_tags": packet.meta["dyad_signature"],
    "timestamp": now(),
})
