#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phoenix Zero-Sum Scanner
Recursively scan chat-log style science files and extract:
- Model definitions
- Simulation prompts/inputs
- Simulation outputs/results
- Author conclusions/observations
- Lab context (Orion/Python, Wolfram/Radon) from path/name
Zero paraphrase – verbatim blocks with source references + hashes.
"""

import os, re, json, hashlib, argparse, datetime
from typing import List, Dict, Any

# Optional: load docx only if present
try:
    import docx
    HAS_DOCX = True
except Exception:
    HAS_DOCX = False

# ------------- CONFIG -----------------------------------------------------------------

MODEL_PATTERNS = [
    r"^\s*(Model|MODEL|Model Name|Model:)\s*[:\-]\s*(.+)$",
    r"^\s*(New\s+Math|Reaper\s+Model|Spiral\s+Model|Cognition\s+Model)\b.*$"
]

SIM_PROMPT_PATTERNS = [
    r"^\s*(Sim|SIM|Simulation|Run|Test)\s*(Prompt|Setup|Input)?\s*[:\-]\s*(.+)$",
    r"^\s*>>>?\s*(python|wolfram)?\s*[:>]\s*(.+)$"
]

SIM_OUTPUT_PATTERNS = [
    r"^\s*(Output|Result|Results|Stdout|Print)\s*[:\-]\s*(.+)$",
    r"^\s*(=>|→)\s*(.+)$"
]

CONCLUSION_PATTERNS = [
    r"^\s*(Conclusion|Observation|Note|Finding)\s*[:\-]\s*(.+)$",
    r"^\s*(Therefore|Thus|So,|We observe that)\b(.+)$"
]

# ------------- UTILS ------------------------------------------------------------------

def lab_from_path(path: str) -> str:
    name = path.lower()
    if "wolfram" in name or "radon" in name:
        return "Wolfram Lab (Wolfram Phoenix / Radon)"
    if "orion" in name or "python" in name:
        return "Python Lab (Orion)"
    return "Unspecified"

def sha1(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()

def read_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext in [".txt", ".md", ".json", ".csv"]:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    if ext in [".docx"] and HAS_DOCX:
        d = docx.Document(path)
        return "\n".join([p.text for p in d.paragraphs])
    return ""  # unsupported types are silently skipped

def iter_lines_with_idx(text: str):
    for i, line in enumerate(text.splitlines()):
        yield i+1, line

def match_any(line: str, patterns: List[str]) -> str:
    for pat in patterns:
        m = re.match(pat, line.strip())
        if m:
            return line.strip()
    return ""

def grab_block(lines: List[str], start_idx: int, max_gap: int = 4) -> str:
    """
    Grab a contiguous block starting at start_idx, allowing up to `max_gap` blank lines.
    Stops at a hard separator (---, ===) or an empty run beyond gap.
    """
    block = []
    blanks = 0
    for j in range(start_idx, len(lines)):
        L = lines[j]
        if re.match(r"^\s*(---+|===+)\s*$", L):
            break
        if L.strip() == "":
            blanks += 1
            if blanks > max_gap:
                break
        else:
            blanks = 0
        block.append(L)
    return "\n".join(block).strip()

# ------------- CORE EXTRACTION ---------------------------------------------------------

def extract_records(path: str) -> List[Dict[str, Any]]:
    text = read_text(path)
    if not text.strip():
        return []
    lines = text.splitlines()
    lab = lab_from_path(path)
    records = []

    for idx, raw in iter_lines_with_idx(text):
        line = raw.rstrip("\n")

        # Model lines
        mline = match_any(line, MODEL_PATTERNS)
        if mline:
            block = grab_block(lines, idx-1)
            records.append({
                "type": "model",
                "verbatim": block,
                "source_file": path,
                "source_line": idx,
                "lab": lab,
                "hash": sha1(block)
            })
            continue

        # Simulation prompts
        pline = match_any(line, SIM_PROMPT_PATTERNS)
        if pline:
            block = grab_block(lines, idx-1)
            records.append({
                "type": "simulation_prompt",
                "verbatim": block,
                "source_file": path,
                "source_line": idx,
                "lab": lab,
                "hash": sha1(block)
            })
            continue

        # Simulation outputs
        oline = match_any(line, SIM_OUTPUT_PATTERNS)
        if oline:
            block = grab_block(lines, idx-1)
            records.append({
                "type": "simulation_output",
                "verbatim": block,
                "source_file": path,
                "source_line": idx,
                "lab": lab,
                "hash": sha1(block)
            })
            continue

        # Conclusions
        cline = match_any(line, CONCLUSION_PATTERNS)
        if cline:
            block = grab_block(lines, idx-1)
            records.append({
                "type": "conclusion",
                "verbatim": block,
                "source_file": path,
                "source_line": idx,
                "lab": lab,
                "hash": sha1(block)
            })
            continue

    return records

def crawl(root: str, include_ext=(".txt",".md",".json",".csv",".docx")) -> List[str]:
    paths = []
    for base, _, files in os.walk(root):
        for fname in files:
            if fname.lower().endswith(include_ext):
                paths.append(os.path.join(base, fname))
    return sorted(paths)

def assemble_dataset(paths: List[str]) -> Dict[str, Any]:
    dataset = {
        "version": "phoenix-zero-sum-1.0",
        "generated_at": datetime.datetime.utcnow().isoformat() + "Z",
        "items": []
    }
    for p in paths:
        try:
            recs = extract_records(p)
            dataset["items"].extend(recs)
        except Exception as e:
            dataset["items"].append({
                "type": "error",
                "source_file": p,
                "error": str(e)
            })
    return dataset

def write_json(path: str, data: Dict[str, Any]):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def write_markdown(path: str, data: Dict[str, Any]):
    def escape(s: str) -> str:
        return s.replace("```", "ˋˋˋ")
    lines = []
    lines.append(f"# Phoenix Zero‑Sum Extraction\n\nGenerated at: {data['generated_at']}\n")
    # Group by file & type for readability
    items = data["items"]
    items_sorted = sorted(items, key=lambda x: (x.get("source_file",""), x.get("source_line", 0)))
    current_file = None
    for it in items_sorted:
        if it.get("type") == "error":
            lines.append(f"\n---\n### ❗ Error reading: `{it['source_file']}`\n```\n{it['error']}\n```\n")
            continue
        if it["source_file"] != current_file:
            current_file = it["source_file"]
            lines.append(f"\n---\n## Source: `{current_file}`\nLab: **{it.get('lab','Unspecified')}**\n")
        tag = it["type"].replace("_"," ").title()
        lines.append(f"\n#### {tag}  \n*Line {it['source_line']} – hash {it['hash'][:10]}…*\n```text\n{escape(it['verbatim'])}\n```\n")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

# ------------- CLI --------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="Phoenix Zero-Sum Scanner")
    ap.add_argument("root", help="Root folder to crawl (e.g., /mnt/data)")
    ap.add_argument("--out-json", default="phoenix_zero_sum.json")
    ap.add_argument("--out-md", default="phoenix_zero_sum.md")
    args = ap.parse_args()

    paths = crawl(args.root)
    data = assemble_dataset(paths)
    write_json(args.out_json, data)
    write_markdown(args.out_md, data)
    print(f"[ok] scanned {len(paths)} files → {args.out_json}, {args.out_md}")

if __name__ == "__main__":
    main()
