import os
import json
import argparse
from datetime import datetime
import pandas as pd


def load_json_chunks(chunk_dir):
    """
    Walk through chunk_dir and load all JSON chunk files.
    Returns list of JSON objects.
    """
    objects = []
    for root, _, files in os.walk(chunk_dir):
        for fname in sorted(files):
            if fname.lower().endswith('.json'):
                path = os.path.join(root, fname)
                with open(path, 'r', encoding='utf-8') as f:
                    try:
                        data = json.load(f)
                        if isinstance(data, list):
                            objects.extend(data)
                        else:
                            objects.append(data)
                    except json.JSONDecodeError:
                        print(f"Warning: could not decode {path}")
    return objects


def flatten_objects(objs):
    """
    Use pandas.json_normalize to flatten nested JSON.
    Returns a DataFrame.
    """
    # json_normalize will expand nested dicts and lists appropriately
    df = pd.json_normalize(objs, sep='_')
    return df


def write_master_files(objs, out_json, out_csv):
    """
    Write full JSON and flattened CSV to disk.
    """
    # Master JSON
    os.makedirs(os.path.dirname(out_json), exist_ok=True)
    with open(out_json, 'w', encoding='utf-8') as f:
        json.dump(objs, f, indent=2, ensure_ascii=False)
    print(f"Wrote master JSON: {out_json} ({len(objs)} objects)")

    # Flatten and write CSV
    df = flatten_objects(objs)
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    df.to_csv(out_csv, index=False)
    print(f"Wrote master CSV: {out_csv} ({df.shape[0]} rows, {df.shape[1]} columns)")


def main():
    parser = argparse.ArgumentParser(
        description='Combine JSON chunks into a master JSON and CSV with metadata.')
    parser.add_argument('--chunk-dir', '-c', required=True,
                        help='Directory containing chunked JSON files')
    parser.add_argument('--out-json', '-j', default='master_index.json',
                        help='Path to write master JSON file')
    parser.add_argument('--out-csv', '-s', default='master_index.csv',
                        help='Path to write master CSV file')
    parser.add_argument('--filter-tag', '-t', action='append',
                        help='Optional: only include objects with matching section_tags or bootstrap_refs')
    args = parser.parse_args()

    print(f"Loading JSON chunks from: {args.chunk_dir}")
    objs = load_json_chunks(args.chunk_dir)

    # Optional filtering
    if args.filter_tag:
        filtered = []
        for o in objs:
            meta = o.get('__meta__', {})
            tags = meta.get('section_tags', []) + meta.get('bootstrap_refs', [])
            if any(tag in tags for tag in args.filter_tag):
                filtered.append(o)
        print(f"Filtered: {len(filtered)} of {len(objs)} objects match tags {args.filter_tag}")
        objs = filtered

    # Write outputs
    timestamp = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    out_json = args.out_json.replace('.json', f'_{timestamp}.json')
    out_csv = args.out_csv.replace('.csv', f'_{timestamp}.csv')
    write_master_files(objs, out_json, out_csv)

if __name__ == '__main__':
    main()
