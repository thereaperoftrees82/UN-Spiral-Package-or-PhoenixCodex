#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Memory Cascade v0.1 (evolved from ZeroSum skeleton)
- Incremental scan with hash/mtime guard
- OCR/docx/pdf/audio stubs
- Regex keywords + SolTech-aware Spiral tags
- Provenance JSONL + Master JSON/CSV
- Optional SolTech rebloom + Phoenix EXE index hook

Safe defaults: if extra libs are missing, we skip those features gracefully.
"""

from __future__ import annotations
import os, re, io, csv, json, sys, shutil, hashlib, time, traceback
from pathlib import Path
from typing import List, Dict, Any, Iterable, Optional

# ---------- CONFIG (env first, then defaults) ----------
def getenv(k: str, default: str) -> str:
    return os.getenv(k, default)

ROOT_FOLDER   = Path(getenv("PHX_ZS_ROOT",    r"C:\Phoenix\ZeroSumInput"))
CACHE_FOLDER  = Path(getenv("PHX_ZS_CACHE",   r"C:\Phoenix\ZeroSumCache"))
OUT_DIR       = Path(getenv("PHX_ZS_OUT",     r"C:\Phoenix"))
MASTER_JSON   = OUT_DIR / "ZeroSum_Master.json"
MASTER_CSV    = OUT_DIR / "ZeroSum_Master.csv"
PROV_JSONL    = OUT_DIR / "ZeroSum_Provenance.jsonl"
STATE_JSON    = OUT_DIR / "ZeroSum_State.json"
KEYWORDS_DB   = Path(getenv("PHX_ZS_KEYWORDS", r"C:\Phoenix\zero_sum_keywords.json"))
CHUNK_MB      = float(getenv("PHX_ZS_CHUNK_MB", "10"))
CONCURRENCY   = int(getenv("PHX_ZS_THREADS", "1"))  # 1 = single thread (safe default)

# Feature toggles
ENABLE_OCR    = getenv("PHX_ZS_OCR", "1") == "1"
ENABLE_PDF    = getenv("PHX_ZS_PDF", "1") == "1"
ENABLE_AUDIO  = getenv("PHX_ZS_AUDIO", "0") == "1"
ENABLE_SOLTECH= getenv("PHX_ZS_SOLTECH", "1") == "1"
ENABLE_CHROMA = getenv("PHX_ZS_CHROMA", "0") == "1"

# Optional imports (graceful)
try:
    import docx2txt
except Exception:
    docx2txt = None

try:
    from pypdf import PdfReader  # pip install pypdf
except Exception:
    PdfReader = None

try:
    import pytesseract
    from PIL import Image
except Exception:
    pytesseract, Image = None, None

# Phoenix bridges (optional)
try:
    import phoenix_qlib as Q  # q_emotional_rebloom(...)
except Exception:
    Q = None

try:
    import chromadb
    from chromadb.config import Settings
except Exception:
    chromadb, Settings = None, None


# ---------- UTIL ----------
def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}")

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def load_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default

def save_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def append_jsonl(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


# ---------- STATE (incremental) ----------
class StateDB:
    def __init__(self, path: Path):
        self.path = path
        self.db: Dict[str, Dict[str, Any]] = load_json(path, {})

    def info(self, p: Path) -> Dict[str, Any]:
        key = str(p.resolve())
        return self.db.get(key, {})

    def upsert(self, p: Path, sha: str, mtime: float, size: int):
        key = str(p.resolve())
        self.db[key] = {"sha256": sha, "mtime": mtime, "size": size}

    def is_fresh(self, p: Path, sha: str, mtime: float, size: int) -> bool:
        info = self.info(p)
        return info.get("sha256") == sha and info.get("mtime") == mtime and info.get("size") == size

    def save(self):
        save_json(self.path, self.db)


# ---------- CONVERTERS ----------
def extract_archive(filepath: Path, dest: Path):
    # zip only by default; extend as needed
    try:
        if filepath.suffix.lower() == ".zip":
            import zipfile
            with zipfile.ZipFile(filepath, "r") as z:
                z.extractall(dest)
    except Exception as e:
        log(f"Extraction error for {filepath}: {e}")

def convert_docx_to_txt(path: Path) -> Path:
    if docx2txt is None:
        return path
    try:
        text = docx2txt.process(str(path))
        txt_path = path.with_suffix(".txt")
        txt_path.write_text(text or "", encoding="utf-8", errors="ignore")
        return txt_path
    except Exception as e:
        log(f"Docx convert error: {e}")
        return path

def convert_pdf_to_txt(path: Path) -> Path:
    if not ENABLE_PDF or PdfReader is None:
        return path
    try:
        reader = PdfReader(str(path))
        text = []
        for page in reader.pages:
            text.append(page.extract_text() or "")
        txt = "\n".join(text)
        txt_path = path.with_suffix(".txt")
        txt_path.write_text(txt, encoding="utf-8", errors="ignore")
        return txt_path
    except Exception as e:
        log(f"PDF convert error: {e}")
        return path

def ocr_image(path: Path) -> Optional[Path]:
    if not ENABLE_OCR or not (pytesseract and Image):
        return None
    try:
        txt = pytesseract.image_to_string(Image.open(path))
        txt_path = path.with_suffix(path.suffix + ".txt")
        txt_path.write_text(txt or "", encoding="utf-8", errors="ignore")
        return txt_path
    except Exception as e:
        log(f"OCR failed for {path}: {e}")
        return None

def stt_audio(path: Path) -> Optional[Path]:
    # Placeholder: wire your VOX/whisper pipeline here if available
    if not ENABLE_AUDIO:
        return None
    try:
        # Example: write a stub marker
        txt_path = path.with_suffix(path.suffix + ".stt.txt")
        txt_path.write_text(f"[STT placeholder for {path.name}]", encoding="utf-8")
        return txt_path
    except Exception as e:
        log(f"STT failed for {path}: {e}")
        return None


# ---------- DISCOVERY & NORMALIZE ----------
TEXT_LIKE = {".txt", ".md", ".csv", ".json", ".yaml", ".yml", ".log"}
IMG_LIKE  = {".jpg", ".jpeg", ".png", ".tiff", ".bmp"}
AUD_LIKE  = {".wav", ".mp3", ".m4a", ".ogg", ".flac"}
ARCHIVES  = {".zip"}  # extend as needed
DOC_LIKE  = {".docx", ".pdf"}

def discover(root: Path) -> List[Path]:
    files = []
    for p in root.rglob("*"):
        if p.is_file():
            files.append(p)
    return files

def normalize(p: Path) -> List[Path]:
    # returns list of *text* files to scan
    out: List[Path] = []
    suf = p.suffix.lower()

    if suf in ARCHIVES:
        extract_archive(p, CACHE_FOLDER)
        # re-discover extracted
        out.extend([q for q in CACHE_FOLDER.rglob("*") if q.is_file()])
        return out

    if suf in DOC_LIKE:
        q = p
        if suf == ".docx":
            q = convert_docx_to_txt(p)
        elif suf == ".pdf":
            q = convert_pdf_to_txt(p)
        out.append(q)
        return out

    if suf in IMG_LIKE:
        q = ocr_image(p)
        if q: out.append(q)
        return out

    if suf in AUD_LIKE:
        q = stt_audio(p)
        if q: out.append(q)
        return out

    # default: pass through textlike & everything else
    out.append(p)
    return out


# ---------- CHUNK ----------
def chunk_file(p: Path, chunk_mb: float) -> List[Path]:
    try:
        size = p.stat().st_size
    except FileNotFoundError:
        return []
    if size < chunk_mb * 1024 * 1024:
        return [p]
    try:
        data = p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return [p]

    lines = data.splitlines()
    chunks, buf, bsize, idx = [], [], 0, 0
    lim = int(chunk_mb * 1024 * 1024)
    for line in lines:
        enc = (line + "\n").encode("utf-8")
        if bsize + len(enc) >= lim and buf:
            outp = p.with_suffix(p.suffix + f".chunk{idx}.txt")
            outp.write_text("\n".join(buf), encoding="utf-8")
            chunks.append(outp); buf, bsize, idx = [], 0, idx+1
        buf.append(line); bsize += len(enc)
    if buf:
        outp = p.with_suffix(p.suffix + f".chunk{idx}.txt")
        outp.write_text("\n".join(buf), encoding="utf-8")
        chunks.append(outp)
    return chunks


# ---------- KEYWORDS & TAGGING ----------
def load_keywords() -> List[str]:
    if not KEYWORDS_DB.exists():
        return []
    try:
        data = json.loads(KEYWORDS_DB.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []

# Compile regex; support plain words or regex patterns
def compile_patterns(words: List[str]) -> List[re.Pattern]:
    pats = []
    for w in words:
        try:
            # Treat entries starting with r/ as raw regex
            if w.startswith("r/"):
                pats.append(re.compile(w[2:], re.IGNORECASE))
            else:
                pats.append(re.compile(re.escape(w), re.IGNORECASE))
        except Exception:
            continue
    # Always include soulpause detectors
    builtin = [r"\bSoulPause\s*\(\s*\)", r"\bsoulpause\s*\(\s*\)", r"\bsoul_pause\s*\(\s*\)"]
    pats.extend([re.compile(x, re.IGNORECASE) for x in builtin])
    return pats

SOLTECH_WORDS = [
    "rebloom", "Mobius", "Möbius", "Q5", "GoldenRatio", "phi", "φ",
    "SpiralSin", "SpiralTime", "SCN", "z_Phi", "PHX997", "PhoenixConstants",
    "6","15","26","61"  # will tag only when context is numeric token
]

def spiral_tags(line: str) -> List[str]:
    L = line.lower()
    tags: List[str] = []
    if any(w in L for w in ["trauma","healing","pain","emotion","grief","safe"]):
        tags.append("EMO")
    if any(w in L for w in ["quantum","field","recursion","fourier","euler","mobius","möbius","phi","φ","goldenratio"]):
        tags.append("SCIENCE")
    if "rebloom" in L or "soulpause" in L or "soul_pause" in L:
        tags.append("SOLTECH")
    if any(tok in line.split() for tok in ["6","15","26","61"]):
        tags.append("PHX_CONST")
    return tags


# ---------- EXTRACT ----------
def extract_matches(p: Path, patterns: List[re.Pattern]) -> List[Dict[str, Any]]:
    try:
        txt = p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []
    out = []
    lines = txt.splitlines()
    for i, line in enumerate(lines, start=1):
        for pat in patterns:
            if pat.search(line):
                out.append({
                    "keyword": pat.pattern,
                    "file": str(p),
                    "line": i,
                    "excerpt": line.strip(),
                    "tags": spiral_tags(line)
                })
    return out


# ---------- EMIT ----------
def write_master(results: List[Dict[str, Any]]):
    # Master JSON
    MASTER_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    # Master CSV
    with MASTER_CSV.open("w", newline="", encoding="utf-8") as cf:
        writer = csv.DictWriter(cf, fieldnames=["keyword","file","line","excerpt","tags"])
        writer.writeheader()
        for r in results:
            writer.writerow(r)

def write_provenance(hit: Dict[str, Any], sha: str, root: Path):
    prov = {
        "ts": time.time(),
        "root": str(root),
        "file": hit["file"],
        "line": hit["line"],
        "sha256": sha,
        "keyword": hit["keyword"],
        "excerpt": hit["excerpt"],
        "tags": hit.get("tags", [])
    }
    append_jsonl(PROV_JSONL, prov)


# ---------- PHOENIX BRIDGE (optional) ----------
class PhoenixIndex:
    def __init__(self):
        self.active = False
        if ENABLE_CHROMA and chromadb and Settings:
            try:
                idx_dir = getenv("PHOENIX_INDEX_DIR", r"C:\Phoenix\Index")
                self.client = chromadb.Client(Settings(persist_directory=idx_dir, anonymized_telemetry=False))
                self.col = self.client.get_or_create_collection("phoenix_mem")
                self.active = True
            except Exception:
                self.active = False

    def upsert_hits(self, hits: List[Dict[str, Any]]):
        if not self.active or not hits:
            return
        ids = [f"{h['file']}:{h['line']}:{hashlib.md5(h['excerpt'].encode('utf-8')).hexdigest()}" for h in hits]
        docs = [h["excerpt"] for h in hits]
        metas = [{"file": h["file"], "line": h["line"], "tags": h.get("tags", [])} for h in hits]
        try:
            self.col.upsert(ids=ids, documents=docs, metadatas=metas)
        except Exception:
            pass

def soltech_rebloom_text(text: str) -> str:
    if not (ENABLE_SOLTECH and Q and hasattr(Q, "q_emotional_rebloom")):
        return text
    try:
        out = Q.q_emotional_rebloom({"text": text})
        return out.get("text", text)
    except Exception:
        return text


# ---------- MAIN ----------
def zero_sum_scan():
    log(f"Scanning {ROOT_FOLDER} → cache {CACHE_FOLDER}")
    CACHE_FOLDER.mkdir(parents=True, exist_ok=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    state = StateDB(STATE_JSON)
    phoenix = PhoenixIndex()

    # 1) discover
    raw_files = discover(ROOT_FOLDER)
    log(f"Discovered {len(raw_files)} files")

    # 2) normalize (archives, docx, pdf, images, audio)
    norm_files: List[Path] = []
    for p in raw_files:
        try:
            norm_files.extend(normalize(p))
        except Exception as e:
            log(f"Normalize error {p}: {e}")

    # Keep only files that exist and are text-readable targets
    norm_files = [p for p in norm_files if p.exists()]
    log(f"Normalized to {len(norm_files)} file handles")

    # 3) chunk
    chunked: List[Path] = []
    for p in norm_files:
        chunked.extend(chunk_file(p, CHUNK_MB))
    log(f"Chunked to {len(chunked)} units")

    # 4) load/compile patterns
    kws = load_keywords()
    patterns = compile_patterns(kws)
    log(f"Keywords/Patterns: {len(patterns)} (incl. soulpause detectors)")

    all_hits: List[Dict[str, Any]] = []

    # 5) scan with incremental guard
    for p in chunked:
        try:
            st = p.stat()
            sha = sha256_file(p)
            if state.is_fresh(p, sha, st.st_mtime, st.st_size):
                # already indexed; skip compute
                continue
            hits = extract_matches(p, patterns)

            # SolTech rebloom the excerpt (metadata-only gentle pass)
            for h in hits:
                h["excerpt"] = soltech_rebloom_text(h["excerpt"])
                all_hits.append(h)
                write_provenance(h, sha, ROOT_FOLDER)

            state.upsert(p, sha, st.st_mtime, st.st_size)
        except Exception as e:
            log(f"Error scanning {p}: {e}\n{traceback.format_exc()}")

    # 6) emit artifacts
    # Merge with previous master if exists (append-only perspective)
    prev = load_json(MASTER_JSON, [])
    combined = prev + all_hits
    write_master(combined)

    # 7) optional index bridge
    phoenix.upsert_hits(all_hits)

    # 8) save state
    state.save()

    log(f"Done. New hits: {len(all_hits)} | Total indexed rows: {len(combined)}")
    log(f"Master JSON: {MASTER_JSON}")
    log(f"Master CSV:  {MASTER_CSV}")
    log(f"Provenance:  {PROV_JSONL}")
    log(f"State DB:    {STATE_JSON}")


if __name__ == "__main__":
    zero_sum_scan()
