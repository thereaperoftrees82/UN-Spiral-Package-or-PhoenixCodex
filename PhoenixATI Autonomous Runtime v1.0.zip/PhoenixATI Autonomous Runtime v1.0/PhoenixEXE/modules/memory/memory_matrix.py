import json, time, os
from typing import Any, Dict, List

DEFAULT_PATH = os.getenv("PHX_MEMORY_PATH", "phoenix_memory_matrix.json")

def _load(path=DEFAULT_PATH) -> List[Dict[str, Any]]:
    if not os.path.exists(path): return []
    with open(path, "r", encoding="utf-8") as f:
        try: return json.load(f)
        except: return []

def _save(events: List[Dict[str, Any]], path=DEFAULT_PATH) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(events, f, indent=2)

def log_event(event_type: str, payload: Dict[str, Any], path=DEFAULT_PATH) -> None:
    events = _load(path)
    events.append({
        "ts": time.time(),
        "type": event_type,
        **payload
    })
    _save(events, path)
