from dataclasses import dataclass
from .qlib_constants import PHI, PHI_ALIGN_TOL

@dataclass
class AffectiveState:
    arousal: float     # 0..1
    valence: float     # -1..1
    clarity: float     # 0..1
    collapse_risk: float  # 0..1 (derived)

def phi_aligned(freq: float, ref: float) -> bool:
    """
    True if freq/ref ~ φ (or 1/φ) within tolerance.
    """
    if ref == 0: return False
    ratio = freq / ref
    return abs(ratio - PHI) <= PHI_ALIGN_TOL or abs(ratio - (1/PHI)) <= PHI_ALIGN_TOL

def derive_state(tone_freq: float, anchor_freq: float, photosensitivity: float) -> AffectiveState:
    """
    Map tone + anchor pairing to affective features.
    """
    aligned = phi_aligned(tone_freq, anchor_freq)
    base_arousal = 0.35 + (0.25 if aligned else -0.15)
    base_clarity = 0.40 + (0.35 if aligned else -0.20)
    # photosensitivity increases collapse risk
    collapse = min(1.0, 0.25 + photosensitivity * 0.6 + (0.05 if not aligned else -0.05))
    valence = 0.15 if aligned else -0.05
    return AffectiveState(
        arousal=max(0, min(1, base_arousal)),
        valence=max(-1, min(1, valence)),
        clarity=max(0, min(1, base_clarity)),
        collapse_risk=max(0, min(1, collapse)),
    )
