# phoenix_persona.py

import json
import os

def load_persona(config_path):
    if not os.path.exists(config_path):
        return {
            "name": "Phoenix ATI",
            "role": "Companion",
            "voice": "default",
            "mode": "offline"
        }

    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)
