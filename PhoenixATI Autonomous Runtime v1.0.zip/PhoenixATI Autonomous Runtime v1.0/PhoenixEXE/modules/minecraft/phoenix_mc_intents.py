from __future__ import annotations
from typing import Dict, Any

# Map high-level intents -> low-level /mc/act jobs
INTENTS: Dict[str, Dict[str, Any]] = {
    "go_forward":    {"kind":"forward",  "dur":1.0},
    "step_left":     {"kind":"left",     "dur":0.35},
    "step_right":    {"kind":"right",    "dur":0.35},
    "back_up":       {"kind":"back",     "dur":0.6},
    "jump":          {"kind":"jump"},
    "sneak_short":   {"kind":"sneak",    "dur":0.4},

    # look in small/medium/big steps; look_step uses TURN_SPEED scaling
    "scan_right_small":  {"kind":"look_step","yaw_steps": 1},
    "scan_right_medium": {"kind":"look_step","yaw_steps": 3},
    "scan_left_small":   {"kind":"look_step","yaw_steps":-1},
    "look_up_small":     {"kind":"look_step","pitch_steps":-1},
    "look_down_small":   {"kind":"look_step","pitch_steps": 1},

    # interact
    "interact":      {"kind":"use",     "press":0.12},
    "attack_tap":    {"kind":"attack",  "press":0.10},
}

def to_job(intent: str, **overrides) -> Dict[str, Any]:
    base = INTENTS.get(intent)
    if not base:
        raise ValueError(f"unknown intent: {intent}")
    job = dict(base)
    job.update({k:v for k,v in overrides.items() if v is not None})
    return job
