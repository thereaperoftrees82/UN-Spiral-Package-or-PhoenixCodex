from __future__ import annotations
import os, time, threading, queue
from typing import Dict, Any

# choose driver
MC_DRIVER = os.getenv("PHOENIX_MC_DRIVER", "keyboard").lower()
RATE_LIMIT = int(os.getenv("PHOENIX_MC_RATE", "20"))
TURN_SPEED = int(os.getenv("PHOENIX_MC_TURN_SPEED", "14"))

# lazy imports
pyautogui = pydirectinput = keyboard = None

STATE = {"running": False, "last": [], "worker": None}
TASKS: "queue.Queue[Dict[str, Any]]" = queue.Queue()

def _imports():
    global pyautogui, pydirectinput, keyboard
    if pyautogui is None:
        import pyautogui as _p; _p.FAILSAFE = True; pyautogui = _p
    if pydirectinput is None:
        import pydirectinput as _d; _d.PAUSE = 0; pydirectinput = _d
    if keyboard is None:
        import keyboard as _k; keyboard = _k

def _rate_ok():
    now = time.time()
    STATE["last"] = [t for t in STATE["last"] if now - t <= 60]
    if len(STATE["last"]) >= RATE_LIMIT: return False
    STATE["last"].append(now); return True

# --- Keyboard driver: W/A/S/D + Space + mouse look ---
def kb_key_down(k): pydirectinput.keyDown(k)
def kb_key_up(k):   pydirectinput.keyUp(k)
def kb_tap(k, dur=0.1):
    kb_key_down(k); time.sleep(max(0,dur)); kb_key_up(k)

def kb_move_forward(dur=0.25): kb_tap("w", dur)
def kb_move_back(dur=0.25):    kb_tap("s", dur)
def kb_strafe_left(dur=0.25):  kb_tap("a", dur)
def kb_strafe_right(dur=0.25): kb_tap("d", dur)
def kb_jump():                 kb_tap("space", 0.08)
def kb_sneak(dur=0.25):        kb_tap("shift", dur)
def kb_attack(dur=0.1):        pydirectinput.mouseDown(button="left"); time.sleep(dur); pydirectinput.mouseUp("left")
def kb_use(dur=0.1):           pydirectinput.mouseDown(button="right"); time.sleep(dur); pydirectinput.mouseUp("right")

def kb_look(dx=0, dy=0):
    # relative small turns; positive dx=turn right, dy=look down
    _imports()
    x, y = pyautogui.position()
    pyautogui.moveRel(int(dx), int(dy), duration=0.0)

def _worker():
    _imports()
    # ESC kills motion immediately
    def stopper(): keyboard.wait("esc"); STATE["running"] = False
    threading.Thread(target=stopper, daemon=True).start()

    while STATE["running"]:
        try: job = TASKS.get(timeout=0.25)
        except queue.Empty: continue
        if not _rate_ok(): continue
        kind = job.get("kind")

        # keyboard driver only for now
        if MC_DRIVER == "keyboard":
            dur = float(job.get("dur", 0.25))
            if kind == "forward":        kb_move_forward(dur)
            elif kind == "back":         kb_move_back(dur)
            elif kind == "left":         kb_strafe_left(dur)
            elif kind == "right":        kb_strafe_right(dur)
            elif kind == "jump":         kb_jump()
            elif kind == "sneak":        kb_sneak(dur)
            elif kind == "attack":       kb_attack(float(job.get("press",0.12)))
            elif kind == "use":          kb_use(float(job.get("press",0.12)))
            elif kind == "look":
                # small step look
                yaw = int(job.get("yaw", 0))   # + right, - left
                pitch = int(job.get("pitch", 0)) # + down, - up
                kb_look(yaw, pitch)
            elif kind == "look_step":
                # convenience: step units scaled by TURN_SPEED
                yaw_steps = int(job.get("yaw_steps", 0))
                pitch_steps = int(job.get("pitch_steps", 0))
                kb_look(yaw_steps*TURN_SPEED, pitch_steps*TURN_SPEED)
        else:
            # future: java_bot / bedrock_bot handlers
            pass
        time.sleep(0.02)

def start()->Dict[str,Any]:
    if STATE["running"]: return {"ok": True, "note":"already running", "driver": MC_DRIVER}
    STATE["running"]=True
    t=threading.Thread(target=_worker, daemon=True); STATE["worker"]=t; t.start()
    return {"ok": True, "driver": MC_DRIVER, "info":"MC Bridge started (ESC to stop)"}

def stop()->Dict[str,Any]:
    STATE["running"]=False
    return {"ok": True}

def act(job: Dict[str,Any])->Dict[str,Any]:
    if not STATE["running"]: return {"ok": False, "error":"bridge not running"}
    TASKS.put(job); return {"ok": True}
