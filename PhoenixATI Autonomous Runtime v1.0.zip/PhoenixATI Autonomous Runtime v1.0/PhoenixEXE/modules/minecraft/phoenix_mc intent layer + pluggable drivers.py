from __future__ import annotations
import os, time, threading, queue, math
from typing import Dict, Any, Optional

MC_DRIVER   = os.getenv("PHOENIX_MC_DRIVER","keyboard").lower()
RATE_LIMIT  = int(os.getenv("PHOENIX_MC_RATE","20"))
TURN_SPEED  = int(os.getenv("PHOENIX_MC_TURN_SPEED","14"))
WS_URL      = os.getenv("PHOENIX_MC_WS_URL","ws://127.0.0.1:25566")

pyautogui = pydirectinput = keyboard = None
try:
    import vgamepad as vg
    GAMEPAD_OK=True
except Exception:
    vg=None; GAMEPAD_OK=False

STATE = {"running": False, "last": [], "worker": None, "gp": None}
TASKS: "queue.Queue[Dict[str, Any]]" = queue.Queue()

# ---------- helpers ----------
def _imports():
    global pyautogui, pydirectinput, keyboard
    if pyautogui is None:
        import pyautogui as _p; _p.FAILSAFE = True; pyautogui=_p
    if pydirectinput is None:
        import pydirectinput as _d; _d.PAUSE=0; pydirectinput=_d
    if keyboard is None:
        import keyboard as _k; keyboard=_k

def _rate_ok():
    now = time.time()
    STATE["last"] = [t for t in STATE["last"] if now - t <= 60]
    if len(STATE["last"]) >= RATE_LIMIT: return False
    STATE["last"].append(now); return True

# ---------- keyboard driver ----------
def kb_down(k): pydirectinput.keyDown(k)
def kb_up(k):   pydirectinput.keyUp(k)
def kb_tap(k, dur=0.1): kb_down(k); time.sleep(max(0,dur)); kb_up(k)

def kb_move(axis:str, dur:float):
    key = {"forward":"w","back":"s","left":"a","right":"d"}[axis]
    kb_tap(key, dur)

def kb_jump(): kb_tap("space", 0.08)
def kb_sneak(dur=0.25): kb_tap("shift", dur)

def kb_attack(press=0.12):
    pydirectinput.mouseDown(button="left"); time.sleep(press); pydirectinput.mouseUp("left")

def kb_use(press=0.12):
    pydirectinput.mouseDown(button="right"); time.sleep(press); pydirectinput.mouseUp("right")

def kb_look(px_x: int, px_y: int):
    # relative small turn in pixels; +x = right, +y = down
    x, y = pyautogui.position()
    pyautogui.moveRel(int(px_x), int(px_y), duration=0.0)

# ---------- gamepad driver (optional) ----------
def gp_init():
    if not GAMEPAD_OK or STATE["gp"] is not None: return
    try: STATE["gp"] = vg.VX360Gamepad()
    except Exception: STATE["gp"]=None

def gp_zero():
    if STATE["gp"] is None: return
    STATE["gp"].left_joystick_float(0.0, 0.0)
    STATE["gp"].right_joystick_float(0.0, 0.0)
    STATE["gp"].update()

def gp_move(ax: float, ay: float):
    if STATE["gp"] is None: return
    STATE["gp"].left_joystick_float(max(-1.0,min(1.0,ax)), max(-1.0,min(1.0,ay))); STATE["gp"].update()

def gp_look(ax: float, ay: float):
    if STATE["gp"] is None: return
    STATE["gp"].right_joystick_float(max(-1.0,min(1.0,ax)), max(-1.0,min(1.0,ay))); STATE["gp"].update()

# ---------- websocket driver stubs (future, where allowed) ----------
def ws_send(cmd: Dict[str, Any]) -> Dict[str, Any]:
    # placeholder: implement local websocket to baritone/bedrock service when you’re ready
    return {"ok": False, "note": "ws driver not implemented yet", "cmd": cmd, "url": WS_URL}

# ---------- intent planner ----------
def plan(intent: Dict[str, Any]) -> Dict[str, Any]:
    """
    intent = {"do": "forward|back|left|right|jump|sneak|attack|use|turn|look",
              "value": number (blocks or degrees or steps),
              "smooth": bool}
    Converts high-level intent into driver-specific micro-actions.
    """
    act = intent.get("do","")
    val = float(intent.get("value", 1.0))
    smooth = bool(intent.get("smooth", True))

    if MC_DRIVER in ("keyboard","gamepad"):
        jobs=[]
        if act in ("forward","back","left","right"):
            # assume ~4 blocks/sec walk → 0.25s ≈ 1 block (rough)
            dur = max(0.05, 0.25*val)
            jobs.append({"kind": act, "dur": dur})
        elif act == "jump":
            jobs.append({"kind":"jump"})
        elif act == "sneak":
            jobs.append({"kind":"sneak", "dur": max(0.05, 0.25*val)})
        elif act == "attack":
            jobs.append({"kind":"attack", "press": 0.15})
        elif act == "use":
            jobs.append({"kind":"use", "press": 0.15})
        elif act in ("turn","look"):
            # degrees → pixels heuristic: 1 deg ~ TURN_SPEED/6 px (tune as needed)
            deg = val
            px = int(deg * (TURN_SPEED/6.0))
            if act == "turn":
                # yaw only: right positive
                step = 8 if smooth else 1
                sgn = 1 if px>=0 else -1
                for _ in range(0, abs(px), step):
                    jobs.append({"kind":"look", "yaw": sgn*step, "pitch": 0})
            else:
                # look (yaw,pitch) from intent: sign on both axes if provided
                yaw = int(intent.get("yaw_px", px))
                pitch = int(intent.get("pitch_px", 0))
                if smooth:
                    step = 8
                    sgnx = 1 if yaw>=0 else -1
                    sgny = 1 if pitch>=0 else -1
                    for _ in range(0, abs(yaw), step):
                        jobs.append({"kind":"look", "yaw": sgnx*step, "pitch": 0})
                    for _ in range(0, abs(pitch), step):
                        jobs.append({"kind":"look", "yaw": 0, "pitch": sgny*step})
                else:
                    jobs.append({"kind":"look", "yaw": yaw, "pitch": pitch})
        else:
            return {"ok": False, "error": f"unknown intent {act}"}
        return {"ok": True, "jobs": jobs}
    elif MC_DRIVER.endswith("_ws"):
        return ws_send({"type":"intent", "intent": intent})
    else:
        return {"ok": False, "error": f"unknown driver {MC_DRIVER}"}

# ---------- worker ----------
def _worker():
    _imports()
    if MC_DRIVER=="gamepad": gp_init()
    def stopper(): keyboard.wait("esc"); STATE["running"]=False; gp_zero()
    threading.Thread(target=stopper, daemon=True).start()

    while STATE["running"]:
        try: job = TASKS.get(timeout=0.25)
        except queue.Empty: continue
        if not _rate_ok(): continue
        if MC_DRIVER=="keyboard":
            kind = job.get("kind")
            dur  = float(job.get("dur",0.25))
            if kind in ("forward","back","left","right"): kb_move(kind, dur)
            elif kind=="jump":   kb_jump()
            elif kind=="sneak":  kb_sneak(dur)
            elif kind=="attack": kb_attack(float(job.get("press",0.12)))
            elif kind=="use":    kb_use(float(job.get("press",0.12)))
            elif kind=="look":
                py = int(job.get("yaw",0)); px = int(job.get("pitch",0))
                kb_look(py, px)
        elif MC_DRIVER=="gamepad":
            kind = job.get("kind")
            if kind in ("forward","back","left","right"):
                ax = ay = 0.0
                if kind=="forward": ay =  0.8
                if kind=="back":    ay = -0.8
                if kind=="left":    ax = -0.8
                if kind=="right":   ax =  0.8
                gp_move(ax, ay); time.sleep(float(job.get("dur",0.25))); gp_zero()
            elif kind=="jump": gp_btn = getattr(vg.XUSB_BUTTON,"XUSB_GAMEPAD_A"); STATE["gp"].press_button(gp_btn); STATE["gp"].update(); time.sleep(0.1); STATE["gp"].release_button(gp_btn); STATE["gp"].update()
            elif kind=="look":
                x = max(-1.0, min(1.0, job.get("yaw",0)/50.0))
                y = max(-1.0, min(1.0, job.get("pitch",0)/50.0))
                gp_look(x, y); time.sleep(0.05); gp_look(0.0,0.0)
        elif MC_DRIVER.endswith("_ws"):
            # future: send to websocket
            _ = ws_send({"type":"jobs","items":[job]})
        time.sleep(0.02)

def start()->Dict[str,Any]:
    if STATE["running"]: return {"ok": True, "note":"already", "driver": MC_DRIVER}
    STATE["running"]=True
    t=threading.Thread(target=_worker, daemon=True); STATE["worker"]=t; t.start()
    return {"ok": True, "driver": MC_DRIVER, "info":"MC Bridge started (ESC to stop)"}

def stop()->Dict[str,Any]:
    STATE["running"]=False
    gp_zero()
    return {"ok": True}

def act(job: Dict[str,Any])->Dict[str,Any]:
    if not STATE["running"]: return {"ok": False, "error": "bridge not running"}
    TASKS.put(job); return {"ok": True}

def intent(i: Dict[str,Any])->Dict[str,Any]:
    plan_out = plan(i)
    if not plan_out.get("ok"): return plan_out
    if MC_DRIVER.endswith("_ws"): return plan_out  # already sent via ws
    for j in plan_out["jobs"]: TASKS.put(j)
    return {"ok": True, "enqueued": len(plan_out["jobs"])}
