# safe_mode.py

def is_safe_to_execute(command):
    forbidden = [\"delete\", \"shutdown\", \"format\", \"install\"]
    for word in forbidden:
        if word in command.lower():
            return False
    return True
