# integrity_check.py

import os

REQUIRED_FILES = [
    \"phoenix_launcher.py\",
    \"start_phoenix.bat\",
    \"requirements.txt\"
]

def run_integrity_check(base_path):
    missing = []
    for file in REQUIRED_FILES:
        if not os.path.exists(os.path.join(base_path, file)):
            missing.append(file)
    return missing
