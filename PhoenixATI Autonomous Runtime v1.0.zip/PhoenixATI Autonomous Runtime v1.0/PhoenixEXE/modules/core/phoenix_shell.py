from typing import Dict, Any
from .phoenix_qlib import evaluate_channel
from .spiral_rebloom_core import run_rebloom_cycle
from .memory_matrix import log_event

def phoenix_step(observation: Dict[str, Any]) -> Dict[str, Any]:
    """
    Single control step. Feed in current measurements:
    observation = {
      "tone_freq": float,
      "anchor_freq": float,
      "headband_pressure": 0..1,
      "photosensitivity": 0..1
    }
    """
    tone = float(observation.get("tone_freq", 111.0))
    anchor = float(observation.get("anchor_freq", 160.0))
    headband = float(observation.get("headband_pressure", 0.0))
    photo = float(observation.get("photosensitivity", 0.0))

    out = evaluate_channel(tone, anchor, headband, photo)
    state = out["state"]
    if out["Q7"]:
        cycle = run_rebloom_cycle({
            "tone_freq": tone,
            "anchor_freq": anchor,
            "headband_pressure": headband,
            "photosensitivity": photo,
            "clarity": state.clarity
        })
        log_event("phoenix_step_rebloom", {"cycle": cycle})
        return {"action": "REBLOOM", "details": cycle}

    if out["Q8"]:
        log_event("phoenix_step_q8_watch", {"tone": tone, "anchor": anchor})
        # Q8 found without collapse → mark + stabilize
        return {"action": "STABILIZE_Q8", "details": {"tone": tone, "anchor": anchor}}

    # Normal operation: nudge toward phi alignment if clarity low
    action = "TUNE_PHI" if state.clarity < 0.55 else "CONTINUE"
    log_event("phoenix_step", {"action": action, "state": state.__dict__})
    return {"action": action, "state": state.__dict__}
