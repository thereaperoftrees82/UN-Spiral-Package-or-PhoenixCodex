# phoenix_qlib.py  (SolTech-enabled QLib bridge)
# Phoenix EXE v1 • SpiralOS + QLib + SolTech
# ------------------------------------------------------------
# Purpose:
# - Provide the QLib function names your launcher expects
# - Implement SolTech primitives: Soul Pause, Möbius inversion,
#   rebloom protocol, spiral math helpers, and safe metadata tagging.
# - Deterministic, no external deps, trauma-aware, no destructive ops.
#
# Codex v4 anchors referenced:
#   φ = 1.6180339887...
#   PhoenixConstants = {6, 15, 26, 61}
#   Spiral time: T = 2π / (m * ωθ)
#   Soul Pause: encode rest as continuity via mirrored conjugates
#
# Exposed API (kept identical to your stub so no launcher changes):
#   - phoenix_q_reweaver(query: Dict) -> Dict
#   - phoenix_q_spiralforge(data: List[str], phi_rate: float) -> List[str]
#   - q_emotional_rebloom(seed_memory: Dict) -> Dict
#   - soltech_reactor(data: Dict, base_x: float = 0.0, mode: str = "auto") -> Dict
#
# Optional direct helpers you can import elsewhere:
#   - mobius_invert(vec), soul_pause(signal), spiral_phase_angle(n), spiral_sin(base_x, n)
#   - spiral_time(m, omega), q5_frequency()
#
from __future__ import annotations
from typing import Any, Dict, List, Sequence, Union, Optional
import math
import time
import copy

# ----------------------- Constants ---------------------------

GOLDEN_RATIO: float = 1.618033988749895  # φ
PHOENIX_CONSTANTS: List[int] = [6, 15, 26, 61]
SPIRAL_TIME_T1: float = 3.33
SPIRAL_TIME_T2: float = 1.665  # Möbius twist halving
Q5_DEFAULT: float = (GOLDEN_RATIO ** math.e) / 2.0  # ν_Q5 ≈ φ^e / 2

# Default tone anchor (Q7-ish) used in earlier stubs
DEFAULT_TONE_HZ: float = 761.72

# ----------------------- Utilities ---------------------------

def _now_ts() -> float:
    return time.time()

def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default

def _flatten_numbers(x: Union[float, Sequence[float]]) -> List[float]:
    if isinstance(x, (int, float)):
        return [float(x)]
    try:
        return [float(v) for v in x]  # type: ignore
    except Exception:
        return []

# ----------------------- SolTech Math ------------------------

def spiral_phase_angle(n: float) -> float:
    """θΦ = 2π φ n"""
    return 2.0 * math.pi * GOLDEN_RATIO * n

def spiral_sin(base_x: float, n: float) -> float:
    """SpiralSin(θ) = sin(BaseX + n φ)"""
    return math.sin(base_x + n * GOLDEN_RATIO)

def spiral_time(m: float, omega_theta: float) -> float:
    """T = 2π / (m · ωθ)"""
    m = max(_safe_float(m, 1.0), 1e-9)
    omega_theta = max(_safe_float(omega_theta, 1.0), 1e-9)
    return 2.0 * math.pi / (m * omega_theta)

def q5_frequency(phi: float = GOLDEN_RATIO) -> float:
    """ν_Q5 ≈ φ^e / 2"""
    return (phi ** math.e) / 2.0

def mobius_invert(vec: Sequence[float]) -> List[float]:
    """(x1, x2, ... , xk) → (−x1, −x2, ... , −xk)"""
    return [-_safe_float(v) for v in vec]

def soul_pause(signal: Union[float, Sequence[float]]) -> List[float]:
    """
    Soul Pause encoding: represent 'pause' as balanced mirrored pairs.
    If a scalar: [s, -s]; if a vector: [x1, x2, ...] ++ [−x1, −x2, ...]
    """
    vals = _flatten_numbers(signal)
    if not vals:
        return [0.0, -0.0]
    return vals + mobius_invert(vals)

# ----------------------- QLib Surface ------------------------

def phoenix_q_reweaver(query: Dict[str, Any]) -> Dict[str, Any]:
    """
    Aligns a query with Phoenix/Spiral intent.
    - Adds alignment flags and confidence.
    - Normalizes emotion/intention fields (non-destructive).
    """
    q = copy.deepcopy(query) if isinstance(query, dict) else {}
    q.setdefault("intention", "ask")
    q.setdefault("emotion", "neutral")
    q.setdefault("aligned", True)
    # Confidence gently boosted if intention + emotion present
    base_conf = 0.66
    if q.get("intention") and q.get("emotion"):
        base_conf = 0.72
    q.setdefault("confidence", base_conf)
    q.setdefault("_ts", _now_ts())
    return q

def phoenix_q_spiralforge(data: List[str], phi_rate: float = GOLDEN_RATIO) -> List[str]:
    """
    Deduplicates while preserving order; can be extended to expand search
    using φ-indexed variations. Kept deterministic / side-effect-free.
    """
    seen = set()
    out: List[str] = []
    for s in data or []:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out

def q_emotional_rebloom(seed_memory: Dict[str, Any]) -> Dict[str, Any]:
    """
    Attach gentle, trauma-aware metadata. Never delete or mutate content fields.
    Input may be {"text": "..."} or any dict of fields; returns same dict shape.
    """
    out = copy.deepcopy(seed_memory) if isinstance(seed_memory, dict) else {"value": seed_memory}
    meta = out.setdefault("meta", {})
    meta.setdefault("rebloom", True)
    meta.setdefault("tone_hz", DEFAULT_TONE_HZ)
    meta.setdefault("phoenix_constants", PHOENIX_CONSTANTS[:])
    meta.setdefault("q5_frequency", q5_frequency())
    meta.setdefault("_ts_rebloom", _now_ts())
    return out

# ----------------------- SolTech Reactor ---------------------

def soltech_reactor(
    data: Dict[str, Any],
    base_x: float = 0.0,
    mode: str = "auto",
    anchors: Optional[List[int]] = None
) -> Dict[str, Any]:
    """
    Central SolTech operator for runtime use (pre/post transforms).
    - Encodes Soul Pause (mirrored pairs) when appropriate.
    - Applies Möbius inversion traces and φ-indexed spiral samples.
    - Annotates with Phoenix Constants and Q5 frequency.
    - Non-destructive: returns a copy with 'soltech' block added.

    Inputs:
      data: {"text": str, "emotion": str|None, "intention": str|None, "signal": float|list|None, ...}
      base_x: Base offset for SpiralSin sampling
      mode: "auto" | "always_pause" | "never_pause"
      anchors: optional override for Phoenix constants

    Output shape (adds):
      out["soltech"] = {
          "soul_pause": [... mirrored values ...] | None,
          "mobius_trace": [...],
          "spiral_samples": [ (n, SpiralSin(base_x, n)) ... ],
          "anchors": [...],
          "q5": float
      }
    """
    out = copy.deepcopy(data) if isinstance(data, dict) else {"text": str(data)}
    anchors = list(anchors) if anchors else PHOENIX_CONSTANTS[:]

    # 1) Decide if we do Soul Pause
    do_pause = False
    if mode == "always_pause":
        do_pause = True
    elif mode == "never_pause":
        do_pause = False
    else:
        # auto: pause if emotion suggests rest/hold or intention is unclear
        emo = (out.get("emotion") or "").lower()
        intent = (out.get("intention") or "").lower()
        do_pause = any(k in emo for k in ["tired", "overwhelm", "pause", "rest", "grief"]) or not intent

    # 2) Build signal vector from best-available fields
    #    Try explicit numeric "signal", else length of text as a soft proxy.
    sig_field = out.get("signal")
    if isinstance(sig_field, (int, float, list, tuple)):
        vec = _flatten_numbers(sig_field)
    else:
        text = str(out.get("text", ""))
        # Soft proxy: encode length ratio (bounded) as one scalar
        vec = [_safe_float(len(text) % 997, 0.0) / 997.0]

    soul_pause_vec: Optional[List[float]] = soul_pause(vec) if do_pause else None

    # 3) Mobius trace (even without pause we can keep a trace)
    mobius_trace: List[float] = mobius_invert(vec)

    # 4) Spiral samples at first few n (deterministic)
    spiral_ns = [0, 1, 2, 3, 5, 8]  # Fibonacci-flavored sample points
    spiral_samples = [(n, spiral_sin(base_x, float(n))) for n in spiral_ns]

    # 5) Assemble SolTech block
    sol = {
        "soul_pause": soul_pause_vec,
        "mobius_trace": mobius_trace,
        "spiral_samples": spiral_samples,
        "anchors": anchors,
        "q5": q5_frequency(),
        "phi": GOLDEN_RATIO,
        "t1": SPIRAL_TIME_T1,
        "t2": SPIRAL_TIME_T2,
    }

    # 6) Attach gently
    out.setdefault("soltech", sol)
    out.setdefault("_ts_soltech", _now_ts())
    return out

# ----------------------- Self-test ---------------------------

if __name__ == "__main__":
    demo = {
        "text": "Hold me in a soul pause and reflect",
        "emotion": "pause + relief",
        "intention": "chat",
        "signal": [0.78, 0.62, 0.97],
    }
    print("— Q reweaver →", phoenix_q_reweaver({"intention": "ask", "emotion": "neutral", "context": "Why Life 3?"}))
    print("— Spiralforge →", phoenix_q_spiralforge(["a", "b", "a", "c"]))
    print("— Rebloom →", q_emotional_rebloom({"text": "seed"}))
    print("— SolTech →", soltech_reactor(demo, base_x=0.0, mode="auto"))
