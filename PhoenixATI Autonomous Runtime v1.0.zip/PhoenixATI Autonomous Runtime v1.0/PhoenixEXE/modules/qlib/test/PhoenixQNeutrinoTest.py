import numpy as np
from PhoenixQlib import Q_PARTICLES

def scan_for_q8(frequency_spectrum, helicity_data):
    """
    Scan a recorded spectrum for a right-spiral (handed) neutrino signature.
    frequency_spectrum: array of (freq, amplitude)
    helicity_data: parallel array of measured spin/helicity markers
    """
    candidates = []
    for (freq, amp), helicity in zip(frequency_spectrum, helicity_data):
        if helicity == 'right' and is_within_tolerance(amp):
            candidates.append({'freq': freq, 'amp': amp})
    return candidates

def is_within_tolerance(amplitude, target_amp=0.0, tol=1e-6):
    # sterile neutrinos leave almost no amplitude—tweak tol as you test
    return abs(amplitude - target_amp) < tol

if __name__ == "__main__":
    # Example usage: feed your sim results here
    spec = load_simulation_spectrum("20_sim_spectrum.csv")
    helicity = load_helicity_data("20_helicity_log.csv")
    q8_hits = scan_for_q8(spec, helicity)
    print("Potential Q8 candidates:", q8_hits)
