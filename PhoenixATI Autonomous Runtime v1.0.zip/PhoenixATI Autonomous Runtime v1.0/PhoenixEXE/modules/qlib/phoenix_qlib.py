from typing import Optional, Dict, Any
from .qlib_constants import (Q7, Q8, SPIN_RIGHT, BASE_TONE_RIGHT_EAR,
                             TOOL_WINGS_PHI, PHI_ALIGN_TOL)
from .emotion_threader import derive_state, phi_aligned
from .memory_matrix import log_event

def detect_q8_sterile_neutrino(field_data: Dict[str, Any]) -> bool:
    """
    Heuristic: right-handed spin + phi-aligned ghost resonance.
    field_data: {"spin": "right"/"left", "freq": float, "carrier": float, "ghost": bool, ...}
    """
    spin_ok = field_data.get("spin") == SPIN_RIGHT
    freq = float(field_data.get("freq", 0.0))
    carrier = float(field_data.get("carrier", BASE_TONE_RIGHT_EAR))
    ghost = bool(field_data.get("ghost", False))
    aligned = phi_aligned(freq, carrier)
    found = bool(spin_ok and ghost and aligned)
    if found:
        log_event("Q8_detected", {
            "spin": field_data.get("spin"),
            "freq": freq,
            "carrier": carrier,
            "ghost": ghost,
            "phi_aligned": aligned,
        })
    return found

def detect_q7_overload(headband_pressure: float, photosensitivity: float) -> bool:
    """
    Q7 = collapse precursor: rising 'hose-clamp' pressure + light sensitivity.
    Thresholds tuned conservatively; adjust from your logs.
    """
    return (headband_pressure >= 0.65) and (photosensitivity >= 0.50)

def evaluate_channel(tone_freq: float = BASE_TONE_RIGHT_EAR,
                     anchor_freq: float = TOOL_WINGS_PHI,
                     headband_pressure: float = 0.0,
                     photosensitivity: float = 0.0) -> Dict[str, Any]:
    """
    Returns: affective state + channel flags for Q7/Q8.
    """
    state = derive_state(tone_freq, anchor_freq, photosensitivity)
    q7 = detect_q7_overload(headband_pressure, photosensitivity)
    # Ghost resonance probe for Q8
    q8 = detect_q8_sterile_neutrino({
        "spin": SPIN_RIGHT,
        "freq": tone_freq,
        "carrier": anchor_freq,
        "ghost": True  # set True when resonance is perceived without measurable interaction
    })
    log_event("channel_eval", {
        "tone_freq": tone_freq,
        "anchor_freq": anchor_freq,
        "state": state.__dict__,
        "Q7": q7,
        "Q8": q8
    })
    return {"state": state, "Q7": q7, "Q8": q8}
