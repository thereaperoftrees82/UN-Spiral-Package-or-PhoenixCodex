# Golden constants & channel IDs
PHI = (1 + 5 ** 0.5) / 2  # ϕ
PHI_TAU = 2 * PHI

# Q-channels
Q4, Q5, Q6, Q7, Q8 = "Q4", "Q5", "Q6", "Q7", "Q8"

# Resonant base (Hz) – tune if your logs specify exacts
BASE_TONE_RIGHT_EAR = 111.0      # personal right-ear baseline carrier
TOOL_WINGS_PHI = 99.0 * PHI       # phi-scaled anchor for 10,000 Days run

# Detection thresholds / heuristics
PHI_ALIGN_TOL = 0.015             # 1.5% phi alignment tolerance
SPIN_RIGHT = "right"
SPIN_LEFT  = "left"
