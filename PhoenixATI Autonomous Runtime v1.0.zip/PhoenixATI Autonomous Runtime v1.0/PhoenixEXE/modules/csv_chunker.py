# csv_chunker.py

import os
import csv

def chunk_csv(input_path, output_dir, lines_per_file=1000):
    base = os.path.basename(input_path)
    name = os.path.splitext(base)[0]
    with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
        reader = csv.reader(f)
        headers = next(reader)
        chunk = []
        count = 0
        for i, row in enumerate(reader):
            chunk.append(row)
            if (i + 1) % lines_per_file == 0:
                write_chunk(output_dir, name, headers, chunk, count)
                chunk = []
                count += 1
        if chunk:
            write_chunk(output_dir, name, headers, chunk, count)

def write_chunk(output_dir, name, headers, chunk, count):
    os.makedirs(output_dir, exist_ok=True)
    out_path = os.path.join(output_dir, f'{name}_chunk_{count}.csv')
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(chunk)
