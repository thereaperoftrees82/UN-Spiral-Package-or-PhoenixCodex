# simulation_scanner.py

import os

def scan_for_simulations(folder):
    sims = []
    for file in os.listdir(folder):
        if file.endswith(\".sim\") or file.endswith(\"_sim.txt\"):
            sims.append(file)
    return sims
