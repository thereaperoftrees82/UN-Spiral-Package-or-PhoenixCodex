import os, json, shutil, time, hashlib
from pathlib import Path
from datetime import datetime

ROOT = Path(r"C:\Phoenix")
UPGRADES = ROOT / "Upgrades"
RUNTIME = ROOT / "runtime"
MODULES = ROOT / "modules"
RUNTIME.mkdir(exist_ok=True)
(MODULES).mkdir(exist_ok=True)

HISTORY = RUNTIME / "applied_history.jsonl"
RUNTIME_CFG = RUNTIME / "runtime_config.json"
BACKUPS = RUNTIME / "backups"
BACKUPS.mkdir(exist_ok=True)

def now(): return datetime.utcnow().isoformat() + "Z"

def load_json(p: Path, default=None):
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {} if default is None else default

def save_json(p: Path, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def json_merge_patch(target: dict, patch: dict) -> dict:
    # RFC 7396 minimal merge
    for k, v in patch.items():
        if v is None:
            target.pop(k, None)
        elif isinstance(v, dict) and isinstance(target.get(k), dict):
            target[k] = json_merge_patch(target.get(k, {}), v)
        else:
            target[k] = v
    return target

def copy_tree(src: Path, dst: Path):
    if not src.exists(): return
    dst.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(src):
        rp = Path(root).relative_to(src)
        (dst / rp).mkdir(exist_ok=True)
        for f in files:
            shutil.copy2(Path(root)/f, dst/rp/f)

def backup_snapshot(tag: str):
    snap = BACKUPS / f"{tag}.json"
    cfg = load_json(RUNTIME_CFG, {})
    save_json(snap, cfg)
    return snap

def log_event(ev: dict):
    HISTORY.write_text(HISTORY.read_text(encoding="utf-8") + json.dumps(ev) + "\n", encoding="utf-8") if HISTORY.exists() \
        else HISTORY.write_text(json.dumps(ev) + "\n", encoding="utf-8")

def apply_package(pkg: Path):
    man = load_json(pkg / "manifest.json")
    pkg_id = man.get("id", pkg.name)
    tag = f"{pkg_id}-{int(time.time())}"
    # backup
    snap = backup_snapshot(tag)
    # start
    ev = {"ts": now(), "event": "upgrade_start", "pkg": pkg.name, "id": pkg_id}
    log_event(ev)

    # actions
    for act in man.get("actions", []):
        t = act["type"]
        if t == "json-merge":
            target = ROOT / act["target"]
            patch = load_json(pkg / act["source"], {})
            base = load_json(target, {})
            merged = json_merge_patch(base, patch)
            save_json(target, merged)
        elif t == "copy-tree":
            copy_tree(pkg / act["from"], ROOT / act["to"])
        elif t == "hook":
            # no execution for safety: record intent only
            log_event({"ts": now(), "event":"hook_skipped_record_only", "pkg": pkg_id, "phase": act.get("phase"), "script": act.get("script")})
        else:
            log_event({"ts": now(), "event":"unknown_action", "pkg": pkg_id, "type": t})

    log_event({"ts": now(), "event": "upgrade_applied", "pkg": pkg_id, "backup": str(snap)})

def rollback(tag_substring: str):
    # find backup by prefix
    candidates = [p for p in BACKUPS.glob("*.json") if tag_substring in p.stem]
    if not candidates:
        print("No matching backup.")
        return
    snap = max(candidates, key=lambda p: p.stat().st_mtime)
    save_json(RUNTIME_CFG, load_json(snap, {}))
    log_event({"ts": now(), "event":"rollback", "to": snap.stem})

def watch_once():
    # Apply any package folder containing manifest.json not yet applied this run
    applied = set()
    for pkg in sorted(UPGRADES.iterdir(), key=lambda p: p.name):
        if not pkg.is_dir(): continue
        if (pkg / "manifest.json").exists() and pkg.name not in applied:
            apply_package(pkg); applied.add(pkg.name)

if __name__ == "__main__":
    RUNTIME_CFG.touch(exist_ok=True)  # ensure file exists
    watch_once()
    print("RUP: scan complete.")
