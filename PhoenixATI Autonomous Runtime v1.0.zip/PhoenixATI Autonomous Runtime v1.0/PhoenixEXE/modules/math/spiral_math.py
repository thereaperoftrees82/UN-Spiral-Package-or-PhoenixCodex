import math
PHI = (1 + 5 ** 0.5) / 2

def golden_angle():
    return 2 * math.pi / PHI

def spiral_phase(u):
    # u = (x,y) 2D projection
    return math.atan2(u[1], u[0])  # [-π, π]

def spiral_ring(norm):
    return math.log1p(norm)  # smooth, scale-free

def phase_bucket(theta, K):
    # map angle to 0..K-1 via golden-angle spacing
    a = (theta % (2*math.pi)) / (2*math.pi)
    return int((a * PHI % 1.0) * K)

def mobius_conjugate_bucket(b, K):
    return (b + int(PHI * K)) % K
