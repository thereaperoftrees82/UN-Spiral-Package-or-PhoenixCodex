# recursive_math_engine.py

def spiral_average(values):
    if not values:
        return 0
    total = sum(values)
    depth = len(values)
    return (2 * total) / (depth + 1)

def spiral_reflect(value, phase=1.618):
    return value * phase
