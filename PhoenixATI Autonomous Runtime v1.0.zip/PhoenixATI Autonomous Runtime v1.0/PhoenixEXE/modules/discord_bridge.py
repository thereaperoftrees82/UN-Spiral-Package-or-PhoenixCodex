# discord_bridge.py

def connect_discord():
    print("[DISCORD] Bridge initialized.")
    # Placeholder — actual Discord link can be added later
