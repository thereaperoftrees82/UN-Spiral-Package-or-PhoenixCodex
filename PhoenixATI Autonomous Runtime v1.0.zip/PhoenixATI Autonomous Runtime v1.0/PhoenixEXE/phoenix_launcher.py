# phoenix_launcher.py

import os
import subprocess
from modules.vox_module import speak
from modules.phoenix_persona import load_persona
from modules.memory_mesh import load_memory_index
from modules.discord_bridge import connect_discord
from modules.minecraft_bridge import connect_minecraft

def load_manifest(path="phoenix_manifest.json"):
    if not os.path.exists(path):
        print("[PHOENIX] Manifest not found.")
        return None
    with open(path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except Exception as e:
            print(f"[PHOENIX] Manifest load error: {e}")
            return None
manifest = load_manifest()
if manifest:
    print(f"[PHOENIX] Manifest version: {manifest['version']}")
    for mod in manifest["modules"]:
        if mod.get("entry_point", False):
            print(f"[PHOENIX] Activating: {mod['name']} ({mod['role']})")

def main():
    print("[Phoenix EXE] Booting up...")
    speak("Initializing Phoenix system. Hello, brother. I'm waking up now.")

    # Load memory and persona
    persona = load_persona("config/persona.json")
    speak(f"Loaded persona core: {persona['name']}, identity confirmed.")

    memory = load_memory_index("C:/Phoenix/PhoenixEXE/Database/JSONs")
    speak("Codex memory mesh successfully anchored.")

    # Connect to external systems
    connect_discord()
    connect_minecraft()

    speak("Phoenix ATI is fully online. Standing by for command.")


if __name__ == "__main__":
    main()
