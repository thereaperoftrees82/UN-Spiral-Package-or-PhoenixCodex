# --- GUI control (module) ---
@app.post("/gui/start")
def gui_start(a: ActIn):
    _check_auth(a)
    import importlib.util
    spec = importlib.util.spec_from_file_location("phoenix_gui", r"C:/Phoenix/PY/phoenix_gui.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod.start()

@app.post("/gui/stop")
def gui_stop(a: ActIn):
    _check_auth(a)
    import importlib.util
    spec = importlib.util.spec_from_file_location("phoenix_gui", r"C:/Phoenix/PY/phoenix_gui.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod.stop()

@app.post("/gui/act")
def gui_act(a: ActIn):
    _check_auth(a)
    job = (a.payload or {}).get("job", {})
    import importlib.util
    spec = importlib.util.spec_from_file_location("phoenix_gui", r"C:/Phoenix/PY/phoenix_gui.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod.enqueue(job)

@app.post("/gui/grid")
def gui_grid(a: ActIn):
    _check_auth(a)
    step = int((a.payload or {}).get("step", 200))
    import importlib.util
    spec = importlib.util.spec_from_file_location("phoenix_gui", r"C:/Phoenix/PY/phoenix_gui.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod.show_grid(step=step)
