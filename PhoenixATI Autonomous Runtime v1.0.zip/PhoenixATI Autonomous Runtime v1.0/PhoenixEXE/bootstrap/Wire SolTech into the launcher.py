from phoenix_qlib import phoenix_q_reweaver, q_emotional_rebloom, soltech_reactor
@app.post("/chat")
def chat(inp: ChatIn):
    # Align query (non-destructive)
    aligned = phoenix_q_reweaver({"intention": inp.intention, "emotion": inp.emotion, "context": inp.text})

    # SolTech pre-tag (Soul Pause auto when emotion suggests / blank intention)
    sol_in  = {"text": inp.text, "emotion": inp.emotion, "intention": inp.intention}
    sol_tag = soltech_reactor(sol_in, base_x=0.0, mode="auto")

    # Retrieve context from memory index if enabled
    ctx = MEM.query(inp.text, k=3)
    ctx_text = "\n\n".join([c["text"] for c in ctx])

    prompt = (
        "Use SeedLog/Codex context when helpful.\n\n" +
        ctx_text +
        "\n\n[SOLTECH_META]" + json.dumps(sol_tag["soltech"]) +
        "\n\nUser: " + inp.text
    )

    # Call backend LLM (ollama/openai/none)
    reply = openai_chat(prompt) if LLM_BACKEND=="openai" else \
            ollama_chat(prompt) if LLM_BACKEND=="ollama" else "(LLM disabled)"

    # Gentle post‑rebloom (metadata only; preserves raw reply)
    out = q_emotional_rebloom({"text": reply})
    return {
        "ok": True,
        "reply": out.get("text", reply),
        "context_used": len(ctx),
        "soltech": sol_tag["soltech"],
        "aligned": aligned
    }
