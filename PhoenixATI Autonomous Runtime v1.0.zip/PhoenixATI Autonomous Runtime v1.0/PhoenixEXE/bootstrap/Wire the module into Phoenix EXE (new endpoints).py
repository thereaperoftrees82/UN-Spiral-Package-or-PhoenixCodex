# --- GUI control (pyautogui) ---
import phoenix_gui as PG

@app.post("/gui/enable")
def gui_enable(a: ActIn):
    _check_auth(a)
    res = PG.enable()
    audit("gui_enable", {"ok": True})
    return res

@app.post("/gui/disable")
def gui_disable(a: ActIn):
    _check_auth(a)
    res = PG.disable()
    audit("gui_disable", {"ok": True})
    return res

@app.post("/gui/kill")
def gui_kill(a: ActIn):
    _check_auth(a)
    res = PG.kill()
    audit("gui_kill", {"ok": True})
    return res

@app.get("/gui/windows")
def gui_windows():
    return {"ok": True, "windows": PG.list_windows(), "allowed_tokens": PG.ALLOWED_APPS}

@app.post("/gui/focus")
def gui_focus(a: ActIn):
    _check_auth(a)
    q = (a.payload or {}).get("title", "")
    return PG.focus_window(q)

@app.post("/gui/move")
def gui_move(a: ActIn):
    _check_auth(a)
    p = a.payload or {}
    return PG.move(int(p.get("x", 0)), int(p.get("y", 0)), float(p.get("duration", 0.1)))

@app.post("/gui/click")
def gui_click(a: ActIn):
    _check_auth(a)
    p = a.payload or {}
    return PG.click(button=p.get("button", "left"), clicks=int(p.get("clicks",1)), interval=float(p.get("interval",0.05)))

@app.post("/gui/type")
def gui_type(a: ActIn):
    _check_auth(a)
    p = a.payload or {}
    return PG.type_text(str(p.get("text","")), float(p.get("interval",0.02)))

@app.post("/gui/hotkey")
def gui_hotkey(a: ActIn):
    _check_auth(a)
    keys = (a.payload or {}).get("keys", [])
    if not isinstance(keys, list) or not keys:
        raise HTTPException(400, "payload.keys must be list[str]")
    return PG.hotkey(*keys)

@app.post("/gui/grid/show")
def gui_grid_show(a: ActIn):
    _check_auth(a)
    p = a.payload or {}
    return PG.show_grid(int(p.get("rows", PG.GRID_ROWS)), int(p.get("cols", PG.GRID_COLS)))

@app.post("/gui/grid/hide")
def gui_grid_hide(a: ActIn):
    _check_auth(a)
    return PG.hide_grid()

@app.post("/gui/grid/cell")
def gui_grid_cell(a: ActIn):
    _check_auth(a)
    p = a.payload or {}
    return PG.grid_cell_click(int(p.get("cell",1)), int(p.get("rows",PG.GRID_ROWS)), int(p.get("cols",PG.GRID_COLS)), p.get("button","left"))
import importlib.util

def _load_gui():
    spec = importlib.util.spec_from_file_location("phoenix_gui", r"C:/Phoenix/PY/phoenix_gui.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

@app.post("/gui/start")
def gui_start(a: ActIn):
    _check_auth(a)
    return _load_gui().start()

@app.post("/gui/stop")
def gui_stop(a: ActIn):
    _check_auth(a)
    return _load_gui().stop()

@app.post("/gui/act")
def gui_act(a: ActIn):
    _check_auth(a)
    return _load_gui().enqueue((a.payload or {}).get("job", {}))

@app.post("/gui/grid")
def gui_grid(a: ActIn):
    _check_auth(a)
    return _load_gui().show_grid(step=int((a.payload or {}).get("step", 200)))
import importlib.util

def _load_input():
    spec = importlib.util.spec_from_file_location("phoenix_input", r"C:/Phoenix/PY/phoenix_input.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

@app.post("/input/start")
def input_start(a: ActIn):
    _check_auth(a)
    return _load_input().start()

@app.post("/input/stop")
def input_stop(a: ActIn):
    _check_auth(a)
    return _load_input().stop()

@app.post("/input/act")
def input_act(a: ActIn):
    _check_auth(a)
    job = (a.payload or {}).get("job", {})
    return _load_input().act(job)
# --- Minecraft bridge ---
import importlib.util

def _load_mc():
    spec = importlib.util.spec_from_file_location("phoenix_mc", r"C:/Phoenix/PY/phoenix_mc.py")
    mod = importlib.util.module_from_spec(spec); assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

@app.post("/mc/start")
def mc_start(a: ActIn):
    _check_auth(a)
    return _load_mc().start()

@app.post("/mc/stop")
def mc_stop(a: ActIn):
    _check_auth(a)
    return _load_mc().stop()

@app.post("/mc/act")
def mc_act(a: ActIn):
    _check_auth(a)
    job = (a.payload or {}).get("job", {})
    return _load_mc().act(job)
