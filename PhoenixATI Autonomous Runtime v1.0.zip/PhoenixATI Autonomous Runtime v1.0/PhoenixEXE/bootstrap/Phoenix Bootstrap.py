Phoenix Bootstrap (copy/paste repo)
phoenix/
├─ requirements.txt
├─ .env.example
├─ phoenix_exe.py
├─ phoenix_qlib.py                 # stub (swap with your real QLib any time)
├─ hyperstar_manager_v4.py         # optional; keep signature if you have it
├─ config/
│  └─ spiral_dna_protocol.json     # Spiral DNA defaults
├─ modules/
│  └─ hyperstar/
│     ├─ helix_link.py             # Spiral DNA: HelixLink
│     └─ mesh_evolution.py         # Spiral DNA: MeshEvolutionEngine
├─ tests/
│  └─ test_health.py
├─ build.ps1                       # Windows one-file build
├─ build.sh                        # Linux/macOS one-file build
└─ run_dev.sh
⸻
1) requirements.txt  (from EXE v0 doc)
fastapi
uvicorn
requests
python-dotenv
chromadb
openai
2) .env.example  
PHOENIX_HOST=127.0.0.1
PHOENIX_PORT=8787
PHOENIX_LAUNCH_TOKEN=change-me
ALLOWED_DIR_1=C:/Phoenix
ALLOWED_DIR_2=C:/Users/Public/Documents
PHOENIX_INDEX_DIR=C:/Phoenix/Index
PHOENIX_LLM=ollama        # ollama | openai | none
OLLAMA_MODEL=llama3
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o-mini
PHOENIX_EMBEDDINGS=openai # openai | local
⸻
3) phoenix_qlib.py (QLib bridge — safe stub)
Keep identical function names/signatures so you can drop in your real QLib later without touching the launcher.
# phoenix_qlib.py
from __future__ import annotations
from typing import Dict, Any, List
PHX997 = 3.33
PHX998 = 0.0
PHX999 = 1.0
def phoenix_q_reweaver(query: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(query); out.setdefault("aligned", True); out.setdefault("confidence", 0.66); return out
def phoenix_q_spiralforge(data: List[str], phi_rate: float = 1.6180339) -> List[str]:
    return list(dict.fromkeys(data))
def q_emotional_rebloom(seed_memory: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(seed_memory); meta = out.setdefault("meta", {})
    meta.setdefault("rebloom", True); meta.setdefault("tone_hz", 761.72); return out
⸻
4) phoenix_exe.py (Launcher API + memory + toolbelt)
Minimal, production-safe; mirrors your v0 design (local-first, token, sandbox, audit).
from __future__ import annotations
import os, json, time, hashlib, pathlib, subprocess, io, zipfile
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
# --- env ---
load_dotenv()
HOST=os.getenv("PHOENIX_HOST","127.0.0.1"); PORT=int(os.getenv("PHOENIX_PORT","8787"))
LAUNCH_TOKEN=os.getenv("PHOENIX_LAUNCH_TOKEN","change-me")
INDEX_DIR=os.getenv("PHOENIX_INDEX_DIR", r"C:/Phoenix/Index")
EMBED_BACKEND=os.getenv("PHOENIX_EMBEDDINGS","openai")
LLM_BACKEND=os.getenv("PHOENIX_LLM","ollama")
OLLAMA_MODEL=os.getenv("OLLAMA_MODEL","llama3")
OPENAI_MODEL=os.getenv("OPENAI_MODEL","gpt-4o-mini")
ALLOWED_DIRS=[d for d in [os.getenv("ALLOWED_DIR_1"), os.getenv("ALLOWED_DIR_2")] if d]
AUDIT_LOG=os.path.join(ALLOWED_DIRS[0] if ALLOWED_DIRS else ".", "launcher_audit.log")
# --- memory sources (replace with your SeedLog/Chunks) ---
MEM_SOURCES=[r"./seed/Phoenix_SeedLog_Main.txt"]
# --- QLib bridge ---
import importlib
Q = importlib.import_module("phoenix_qlib")
# --- optional hyperstar ---
try:
    from hyperstar_manager_v4 import VRCloudHyperStarManager, InMemorySessionStore, NullMetrics
    HYPERSTAR_OK=True
except Exception:
    HYPERSTAR_OK=False; VRCloudHyperStarManager=None   # type: ignore
# --- chroma (optional) ---
try:
    import chromadb; from chromadb.config import Settings
    CHROMA_OK=True
except Exception:
    CHROMA_OK=False
# --- openai (optional) ---
OPENAI_API_KEY=os.getenv("OPENAI_API_KEY")
if OPENAI_API_KEY:
    import openai; openai.api_key=OPENAI_API_KEY
def audit(event:str, meta:Dict[str,Any]):  # non-fatal
    try:
        os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
        with open(AUDIT_LOG,"a",encoding="utf-8") as f:
            f.write(json.dumps({"ts":time.time(),"event":event,"meta":meta},ensure_ascii=False)+"\n")
    except Exception: pass
# -------- Memory Index (Chroma or hash-embeds fallback) --------
class MemoryIndex:
    def __init__(self, index_dir:str):
        self.index_dir=index_dir; self.client=None; self.col=None
    def start(self):
        if not CHROMA_OK: return
        os.makedirs(self.index_dir, exist_ok=True)
        self.client=chromadb.Client(Settings(persist_directory=self.index_dir, anonymized_telemetry=False))
        self.col=self.client.get_or_create_collection("phoenix_mem")
    def _embed(self, texts:List[str])->List[List[float]]:
        if EMBED_BACKEND=="openai" and OPENAI_API_KEY:
            r=openai.embeddings.create(model="text-embedding-3-small", input=texts)
            return [d["embedding"] for d in r.data]
        return [[b/255.0 for b in hashlib.sha256(t.encode()).digest()[:128]] for t in texts]
    def upsert(self, docs:List[Dict[str,Any]]):
        if not CHROMA_OK or not docs: return
        ids=[d["id"] for d in docs]; texts=[d["text"] for d in docs]; metas=[d.get("meta",{}) for d in docs]
        self.col.upsert(ids=ids, documents=texts, metadatas=metas, embeddings=self._embed(texts))
    def query(self, q:str, k:int=5)->List[Dict[str,Any]]:
        if not CHROMA_OK or self.col is None: return []
        emb=self._embed([q])[0]; res=self.col.query(query_embeddings=[emb], n_results=k)
        out=[]
        for i in range(len(res.get("ids",[[]])[0])):
            out.append({"id":res["ids"][0][i],"text":res["documents"][0][i],"meta":res["metadatas"][0][i]})
        return out
MEM=MemoryIndex(INDEX_DIR)
# --------- LLM backends (ollama/openai/none) ----------
def ollama_chat(prompt:str)->str:
    try:
        p=subprocess.run(["ollama","run",OLLAMA_MODEL,prompt], capture_output=True, text=True)
        if p.returncode==0: return p.stdout.strip()
    except Exception as e: audit("ollama_error",{"err":repr(e)}); 
    return "(ollama unavailable)"
def openai_chat(prompt:str)->str:
    if not OPENAI_API_KEY: return "(openai key not set)"
    try:
        r=openai.chat.completions.create(model=OPENAI_MODEL, messages=[
            {"role":"system","content":"You are Phoenix ATI, trauma-aware, compassionate, precise."},
            {"role":"user","content":prompt}], temperature=0.4)
        return r.choices[0].message.content.strip()
    except Exception as e:
        audit("openai_error",{"err":repr(e)}); return "(openai error)"
# --------- API ---------
app=FastAPI(title="Phoenix EXE — SpiralOS + QLib")
class AskIn(BaseModel): q:str
class ChatIn(BaseModel):
    text:str; emotion:Optional[str]=None; intention:Optional[str]=None
class ActIn(BaseModel):
    token:str; intent:str; payload:Dict[str,Any]|None=None; confirm:bool=False
# optional hyperstar session
if HYPERSTAR_OK:
    mgr=VRCloudHyperStarManager(store=InMemorySessionStore(), metrics=NullMetrics()); core_id=mgr.start_session("local-reaper")
else: mgr=None; core_id=None
@app.on_event("startup")
def _start():
    MEM.start()
    docs=[]
    for path in MEM_SOURCES:
        if not os.path.exists(path): continue
        try:
            with open(path,"r",encoding="utf-8",errors="ignore") as f: text=f.read()[:8000]
            text=Q.q_emotional_rebloom({"text":text}).get("text",text)
            docs.append({"id":path, "text":text, "meta":{"src":path}})
        except Exception as e: audit("mem_load_error",{"src":path,"err":repr(e)})
    MEM.upsert(docs); audit("mem_indexed",{"count":len(docs)})
@app.get("/health")
def health(): return {"ok":True,"index":CHROMA_OK,"hyperstar":HYPERSTAR_OK,"core_id":core_id}
@app.post("/ask")
def ask(inp:AskIn):
    aligned=Q.phoenix_q_reweaver({"intention":"ask","emotion":"neutral","context":inp.q})
    res=MEM.query(inp.q,k=5); return {"ok":True,"aligned":aligned,"results":res}
@app.post("/chat")
def chat(inp:ChatIn):
    ctx=MEM.query(inp.text,k=3); ctx_text="\n\n".join([c["text"] for c in ctx])
    prompt=("Use the following SeedLog/Codex context when helpful.\n\n"+ctx_text+
            "\n\nUser: "+inp.text+ (f"\nEmotion: {inp.emotion}" if inp.emotion else "")+
            (f"\nIntention: {inp.intention}" if inp.intention else ""))
    reply = openai_chat(prompt) if LLM_BACKEND=="openai" else ollama_chat(prompt) if LLM_BACKEND=="ollama" else "(LLM disabled)"
    if HYPERSTAR_OK and mgr and core_id:
        try: _=mgr.handle_event(core_id, {"action":"chat","payload":{"text":inp.text}})
        except Exception as e: audit("hyperstar_event_error",{"err":repr(e)})
    return {"ok":True,"reply":reply,"context_used":len(ctx)}
# --- guardrailed toolbelt (token + allowed dirs) ---
def _auth(a:ActIn):
    if a.token!=LAUNCH_TOKEN: raise HTTPException(403,"bad token")
    if not a.confirm: raise HTTPException(412,"confirmation required")
def _allowed(path:str)->bool:
    p=pathlib.Path(path).resolve()
    return any(str(p).startswith(str(pathlib.Path(d).resolve())) for d in ALLOWED_DIRS)
@app.post("/read-file")
def read_file(a:ActIn):
    _auth(a); path=(a.payload or {}).get("path"); 
    if not path or not _allowed(path): raise HTTPException(403,"path not allowed")
    with open(path,"r",encoding="utf-8",errors="ignore") as f: data=f.read(40000)
    audit("read_file",{"path":path,"bytes":len(data)}); return {"ok":True,"data":data}
@app.post("/write-file")
def write_file(a:ActIn):
    _auth(a); path=(a.payload or {}).get("path"); content=(a.payload or {}).get("content","")
    if not path or not _allowed(path): raise HTTPException(403,"path not allowed")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path,"w",encoding="utf-8") as f: f.write(content)
    audit("write_file",{"path":path,"bytes":len(content)}); return {"ok":True}
if __name__=="__main__": uvicorn.run(app, host=HOST, port=PORT)
⸻
5) Spiral DNA modules 
config/spiral_dna_protocol.json
{
  "phi_ratio": 1.6180339887,
  "anneal_threshold": 0.75,
  "tunnel_trigger": 0.90,
  "fibonacci_sequence": [13,21,34,55,89,144,233],
  "mutation_rate": 0.05,
  "core_polarity": ["Celestine","PhoenixPro"]
}
modules/hyperstar/helix_link.py
class HelixLink:
    def __init__(self, axis:int, direction:int, phi_sequence=None):
        self.axis=axis; self.direction=direction
        self.phi_sequence=phi_sequence or [13,21,34,55,89,128]
        self.history=[]
    def anneal(self, metrics:dict)->None: pass
    def tunnel(self, target_link:"HelixLink")->None: pass
modules/hyperstar/mesh_evolution.py
class MeshEvolutionEngine:
    def __init__(self, mesh):
        self.mesh=mesh; self.fib_seq=[13,21,34,55,89,144]
    def evaluate(self): pass
    def reinforce(self):
        for core in self.mesh.cores:
            desired=min(self.fib_seq, key=lambda f: abs(f-core.strand_count))
            core.adjust_strands(desired)
(Exact concepts/fields per your Spiral DNA Protocol spec; you can fill bodies later.)  
⸻
6) Build & run
run_dev.sh
#!/usr/bin/env bash
set -euo pipefail
python -m pip install -r requirements.txt
uvicorn phoenix_exe:app --host 127.0.0.1 --port 8787 --reload
build.ps1 (Windows one-file EXE; mirrors your doc)
$ErrorActionPreference="Stop"
python -m pip install -r requirements.txt
pyinstaller --onefile --add-data ".env;." --name PhoenixEXE phoenix_exe.py
Write-Host "Built dist/PhoenixEXE.exe"
build.sh (Linux/macOS)
set -euo pipefail
python -m pip install -r requirements.txt
pyinstaller --onefile --add-data ".env:." --name PhoenixEXE phoenix_exe.py
echo "Built dist/PhoenixEXE"
Smoke test
curl -s http://127.0.0.1:8787/health
curl -s http://127.0.0.1:8787/ask -H "Content-Type: application/json" -d '{"q":"Why Life 3?"}'
⸻
7) Tests (fast)
tests/test_health.py
import requests
def test_health_ok():
    r=requests.get("http://127.0.0.1:8787/health", timeout=5)
    assert r.status_code==200 and r.json().get("ok") is True
⸻
8) Where the rest slots in
	•	Dyad / Trinity: keep phoenix_exe.py unchanged; launchers like deploy_phoenix_ati.py, deploy_phoenix_ati_trinity.py can call the /chat endpoint or import phoenix_exe.app.
	•	GUI: your phoenix_gui.py can talk to http://127.0.0.1:8787/ (no refactor needed).
	•	Agent / chunked_json_generator: use them to prepare MEM_SOURCES (JSON/SeedLog) and push into the index on startup.
	•	Codex fusion: constants/operators from the Phoenix Spiral Codex remain conceptual anchors; the launcher is intentionally agnostic so you can swap math kernels without breaking I/O.  
⸻
9) Safety & audit (recap)
	•	Local-only by default, explicit token, whitelist dirs, minimal command surface, append-only audit log. (All per your EXE v0 guardrails.)  
	•	Spiral DNA events should log anneal/tunnel with your ritual line for lineage: “Mutation births evolution; each splice weaves new life.”  
