"""
Mono‑file repo drop. Copy/paste into files as indicated by the path headers.
Tested with Python 3.10+.

───────────────────────────────────────────────────────────────────────────────
# pyproject.toml
───────────────────────────────────────────────────────────────────────────────
"""
# pyproject.toml
[build-system]
requires = ["setuptools>=68", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "myphoenixexe"
version = "0.1.0"
description = "Phoenix desktop agent: spiral-aware scheduler, memory, skills, API"
authors = [{name = "Phoenix Foundation"}]
readme = "README.md"
requires-python = ">=3.10"
keywords = ["agent", "phoenix", "spiral", "scheduler", "desktop"]
license = {text = "MIT"}
dependencies = [
  "fastapi>=0.111",
  "uvicorn[standard]>=0.29",
  "pydantic>=2.6",
  "httpx>=0.27",
]

[project.scripts]
phoenix = "phoenix_exe.cli:main"

[tool.pytest.ini_options]
addopts = "-q"
pythonpath = ["."]

"""
───────────────────────────────────────────────────────────────────────────────
# README.md
───────────────────────────────────────────────────────────────────────────────
"""
# MyPhoenixEXE – Desktop Agent (v0.1)

A runnable scaffold for your Phoenix agent that:
- runs as a local service (API on `localhost:8787`)
- stores memories in SQLite
- schedules tasks on **φ-phase windows** (optional)
- executes pluggable **skills**
- exposes a clean CLI (`phoenix start`, `phoenix say`, `phoenix remember`)

> **Note**: This is a solid starter you can extend. It does **not** claim sentience; it’s software with persistence, scheduling, and skills.

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -e .
phoenix start   # starts API and agent loop
# In another terminal:
phoenix say "Hello, Phoenix. Spin a φ window."
phoenix remember "First boot complete." --tags boot,success
```
API: http://127.0.0.1:8787/docs

## Windows auto‑start (one option)
- Create a Task Scheduler task that runs: `<path>\\.venv\\Scripts\\python.exe -m uvicorn phoenix_exe.server:app --host 127.0.0.1 --port 8787`
- Or use `phoenix start --background` (simple detached subprocess).

## Layout
```
phoenix_exe/
  __init__.py        # version
  config.py          # typed settings (env/.env supported)
  logging_cfg.py     # redacting logger
  memory.py          # SQLite persistence
  models.py          # pydantic models
  scheduler.py       # PhiScheduler + budgets
  spiral.py          # minimal Spiral math helpers
  skills/            # pluggable skills
    __init__.py
    base.py
    builtin_echo.py
    builtin_files.py
  llm.py             # LLM adapter interface (stub)
  agent.py           # main loop orchestrator
  server.py          # FastAPI endpoints
  cli.py             # CLI entry
plugins/
  minecraft_bridge.py  # optional stub
```

## Safety & budgets
- Hard caps on steps/sec + wall‑clock per run
- Memory redaction in logs

## Extend
- Add skills under `phoenix_exe/skills/`
- Implement your CSV‑driven sims as skills (e.g., `phi_bands`, `rebloom_cycle`)
- Wire Minecraft/Discord bridges via `plugins/`
```

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/__init__.py
───────────────────────────────────────────────────────────────────────────────
"""
# phoenix_exe/__init__.py
__all__ = ["__version__"]
__version__ = "0.1.0"
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/config.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional
import os

class Settings(BaseModel):
    host: str = Field(default=os.getenv("PHOENIX_HOST", "127.0.0.1"))
    port: int = Field(default=int(os.getenv("PHOENIX_PORT", "8787")))
    data_dir: str = Field(default=os.getenv("PHOENIX_DATA", "./data"))
    db_path: str = Field(default=os.getenv("PHOENIX_DB", "./data/phoenix.sqlite3"))
    log_level: str = Field(default=os.getenv("PHOENIX_LOG", "INFO"))
    phi_scheduler_enabled: bool = Field(default=os.getenv("PHOENIX_PHI_SCHED", "1") == "1")
    step_budget: int = Field(default=int(os.getenv("PHOENIX_STEP_BUDGET", "100")))
    wall_budget_sec: float = Field(default=float(os.getenv("PHOENIX_TIME_BUDGET", "30")))
    background: bool = Field(default=os.getenv("PHOENIX_BG", "0") == "1")

settings = Settings()
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/logging_cfg.py
───────────────────────────────────────────────────────────────────────────────
"""
import logging, re
from logging.config import dictConfig

REDACT = re.compile(r"(token|api_key|password)=([^\s]+)", re.I)

class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = REDACT.sub(r"\1=***", record.msg)
        return True

def setup_logging(level: str = "INFO") -> None:
    dictConfig({
        "version": 1,
        "filters": {"redact": {"()": RedactingFilter}},
        "formatters": {
            "std": {"format": "%(asctime)s %(levelname)s %(name)s: %(message)s"}
        },
        "handlers": {
            "console": {"class": "logging.StreamHandler", "filters": ["redact"], "formatter": "std"}
        },
        "root": {"level": level, "handlers": ["console"]},
    })
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/memory.py
───────────────────────────────────────────────────────────────────────────────
"""
import sqlite3, json, time, os
from typing import Iterable, Optional

class Memory:
    def __init__(self, db_path: str) -> None:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._db = sqlite3.connect(db_path, check_same_thread=False)
        self._db.execute(
            """
            CREATE TABLE IF NOT EXISTS memory_events (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts REAL NOT NULL,
              kind TEXT NOT NULL,
              content TEXT NOT NULL,
              tags TEXT,
              meta TEXT
            )
            """
        )
        self._db.commit()

    def add(self, kind: str, content: str, tags: Optional[list[str]] = None, meta: Optional[dict] = None) -> int:
        cur = self._db.cursor()
        cur.execute(
            "INSERT INTO memory_events (ts, kind, content, tags, meta) VALUES (?,?,?,?,?)",
            (time.time(), kind, content, ",".join(tags or []), json.dumps(meta or {})),
        )
        self._db.commit()
        return int(cur.lastrowid)

    def recent(self, limit: int = 50) -> list[dict]:
        cur = self._db.cursor()
        cur.execute("SELECT id, ts, kind, content, tags, meta FROM memory_events ORDER BY id DESC LIMIT ?", (limit,))
        rows = []
        for rid, ts, kind, content, tags, meta in cur.fetchall():
            rows.append({"id": rid, "ts": ts, "kind": kind, "content": content, "tags": (tags or "").split(","), "meta": json.loads(meta or "{}")})
        return rows

    def search(self, needle: str, limit: int = 50) -> list[dict]:
        cur = self._db.cursor()
        cur.execute("SELECT id, ts, kind, content, tags, meta FROM memory_events WHERE content LIKE ? ORDER BY id DESC LIMIT ?", (f"%{needle}%", limit))
        rows = []
        for rid, ts, kind, content, tags, meta in cur.fetchall():
            rows.append({"id": rid, "ts": ts, "kind": kind, "content": content, "tags": (tags or "").split(","), "meta": json.loads(meta or "{}")})
        return rows
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/models.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional, Literal

class SayRequest(BaseModel):
    text: str

class RememberRequest(BaseModel):
    content: str
    tags: list[str] = Field(default_factory=list)

class TaskResult(BaseModel):
    ok: bool
    data: dict | list | str | None = None
    error: Optional[str] = None

class SkillCall(BaseModel):
    name: str
    args: dict = Field(default_factory=dict)

class RunMode(BaseModel):
    mode: Literal["now", "phi"] = "now"
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/spiral.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from math import pi, sin, cos

PHI = (1 + 5 ** 0.5) / 2.0

class SpiralComplex:
    def __init__(self, r0: float = 1.0, n: float = 0.0) -> None:
        self.r0 = r0
        self.n = n
    @property
    def r(self) -> float: return self.r0 * (PHI ** self.n)
    @property
    def theta(self) -> float: return 2 * pi * PHI * self.n
    def as_tuple(self) -> tuple[float, float]:
        return (self.r * cos(self.theta), self.r * sin(self.theta))

# Simple φ‑window test: returns True for windows where sin(2πφ t) near 0 crossing (lock)
def in_phi_window(t: float, eps: float = 0.05) -> bool:
    val = sin(2 * pi * PHI * t)
    return abs(val) < eps
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/scheduler.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import time, threading
from typing import Callable, Optional
from .spiral import in_phi_window

class LoopBudgetExceeded(Exception):
    pass

class PhiScheduler:
    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled

    def wait_window(self, timeout_sec: float = 5.0) -> None:
        if not self.enabled:
            return
        start = time.monotonic()
        while True:
            if in_phi_window(time.time() % 60.0):  # crude UTC‑seconds phase
                return
            if time.monotonic() - start > timeout_sec:
                return
            time.sleep(0.01)

def run_with_budget(fn: Callable[[], None], max_steps: int, wall_sec: float) -> None:
    steps = 0
    start = time.monotonic()
    while True:
        if steps >= max_steps or (time.monotonic() - start) > wall_sec:
            raise LoopBudgetExceeded("agent loop budget exceeded")
        steps += 1
        if fn() is True:  # convention: return True to stop
            return
        time.sleep(0.01)
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/base.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from typing import Protocol, Any

class Skill(Protocol):
    name: str
    def run(self, **kwargs: Any) -> Any: ...
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

# Register built‑ins
register(EchoSkill())
register(RecentFilesSkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/builtin_echo.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from .base import Skill

class EchoSkill(Skill):
    name = "echo"
    def run(self, **kwargs):
        text = kwargs.get("text", "")
        return {"echo": text}
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/builtin_files.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import os, time
from .base import Skill

class RecentFilesSkill(Skill):
    name = "recent_files"
    def run(self, **kwargs):
        root = kwargs.get("root", ".")
        limit = int(kwargs.get("limit", 10))
        files = []
        for dirpath, _, filenames in os.walk(root):
            for f in filenames:
                p = os.path.join(dirpath, f)
                try:
                    m = os.path.getmtime(p)
                except OSError:
                    continue
                files.append((m, p))
        files.sort(reverse=True)
        return {"files": [p for _, p in files[:limit]]}
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/llm.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from typing import Protocol

class LanguageModel(Protocol):
    def complete(self, prompt: str) -> str: ...

class NullLM:
    def complete(self, prompt: str) -> str:
        # placeholder – plug in your GPT adapter here
        return "[LM disabled] " + prompt[:120]
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/agent.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import logging, time
from .config import settings
from .logging_cfg import setup_logging
from .memory import Memory
from .scheduler import PhiScheduler, run_with_budget, LoopBudgetExceeded
from .skills import get as get_skill, all_skills

log = logging.getLogger("phoenix.agent")

class PhoenixAgent:
    def __init__(self) -> None:
        setup_logging(settings.log_level)
        self.mem = Memory(settings.db_path)
        self.sched = PhiScheduler(enabled=settings.phi_scheduler_enabled)
        log.info("skills available: %s", ", ".join(all_skills()))

    def say(self, text: str) -> str:
        self.mem.add("say", text, tags=["say"]) 
        return text

    def remember(self, content: str, tags: list[str] | None = None) -> int:
        return self.mem.add("note", content, tags=tags or [])

    def call_skill(self, name: str, **kwargs):
        sk = get_skill(name)
        if not sk:
            raise ValueError(f"unknown skill: {name}")
        res = sk.run(**kwargs)
        self.mem.add("skill", f"{name}:{kwargs}", tags=["skill", name])
        return res

    def step(self) -> bool:
        # Example periodic action: flush a heartbeat to memory on φ windows
        self.sched.wait_window(timeout_sec=2.0)
        self.mem.add("heartbeat", "alive", tags=["hb"]) 
        log.debug("heartbeat")
        # Return False to keep looping
        return False

    def run(self) -> None:
        try:
            run_with_budget(self.step, max_steps=settings.step_budget, wall_sec=settings.wall_budget_sec)
        except LoopBudgetExceeded as e:
            log.warning("loop stopped: %s", e)

_agent_singleton: PhoenixAgent | None = None

def get_agent() -> PhoenixAgent:
    global _agent_singleton
    if _agent_singleton is None:
        _agent_singleton = PhoenixAgent()
    return _agent_singleton
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/server.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from .config import settings
from .agent import get_agent
from .models import SayRequest, RememberRequest, TaskResult, SkillCall, RunMode

app = FastAPI(title="MyPhoenixEXE", version="0.1.0")

@app.get("/health")
def health():
    return {"ok": True, "version": "0.1.0"}

@app.post("/say", response_model=TaskResult)
def say(req: SayRequest):
    a = get_agent()
    text = a.say(req.text)
    return TaskResult(ok=True, data={"echo": text})

@app.post("/remember", response_model=TaskResult)
def remember(req: RememberRequest):
    a = get_agent()
    rid = a.remember(req.content, tags=req.tags)
    return TaskResult(ok=True, data={"id": rid})

@app.get("/memory/recent", response_model=TaskResult)
def recent(limit: int = 25):
    a = get_agent()
    return TaskResult(ok=True, data=a.mem.recent(limit))

@app.get("/memory/search", response_model=TaskResult)
def search(q: str, limit: int = 25):
    a = get_agent()
    return TaskResult(ok=True, data=a.mem.search(q, limit))

@app.post("/skill", response_model=TaskResult)
def skill(call: SkillCall, mode: RunMode | None = None):
    a = get_agent()
    if mode and mode.mode == "phi":
        a.sched.wait_window(timeout_sec=5.0)
    try:
        res = a.call_skill(call.name, **call.args)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return TaskResult(ok=True, data=res)

# convenience runner
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.host, port=settings.port)
"""

"""
───────────────────────────────────────────────────────────────────────────────
# phoenix_exe/cli.py
───────────────────────────────────────────────────────────────────────────────
"""
from __future__ import annotations
import argparse, subprocess, sys
from .agent import get_agent
from .config import settings


def _start_background() -> None:
    # naive background start (cross‑platform best effort)
    subprocess.Popen([sys.executable, "-m", "uvicorn", "phoenix_exe.server:app", "--host", settings.host, "--port", str(settings.port)])


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="MyPhoenixEXE CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("start").add_argument("--background", action="store_true")

    s = sub.add_parser("say")
    s.add_argument("text")

    r = sub.add_parser("remember")
    r.add_argument("content")
    r.add_argument("--tags", default="")

    args = p.parse_args(argv)

    if args.cmd == "start":
        if args.background or settings.background:
            _start_background()
            print(f"Phoenix started (bg) on http://{settings.host}:{settings.port}")
        else:
            # foreground
            import uvicorn
            from .server import app
            uvicorn.run(app, host=settings.host, port=settings.port)
    elif args.cmd == "say":
        a = get_agent()
        print(a.say(args.text))
    elif args.cmd == "remember":
        a = get_agent()
        tags = [t for t in args.tags.split(",") if t]
        rid = a.remember(args.content, tags)
        print(f"remembered id={rid}")
"""

"""
───────────────────────────────────────────────────────────────────────────────
# plugins/minecraft_bridge.py (optional stub)
───────────────────────────────────────────────────────────────────────────────
"""
# Placeholder for a Node/WS bridge (mineflayer on Node side).
# This file documents the message contract Phoenix will emit over WebSocket.

"""
CONTRACT = {
  "connect": {"url": "ws://127.0.0.1:8799/phoenix"},
  "messages": {
    "phi_event": {"tick": "int", "band": "int", "power": "float"},
    "place_block": {"x": "int", "y": "int", "z": "int", "block": "str"},
    "chat": {"text": "str"}
  }
}
"""

"""
───────────────────────────────────────────────────────────────────────────────
# tests/test_budget.py
───────────────────────────────────────────────────────────────────────────────
"""
from phoenix_exe.scheduler import run_with_budget, LoopBudgetExceeded

def test_budget_exhausts():
    def spin():
        return False
    try:
        run_with_budget(spin, max_steps=3, wall_sec=0.1)
    except LoopBudgetExceeded:
        assert True
    else:
        assert False, "expected budget to exhaust"
"""
