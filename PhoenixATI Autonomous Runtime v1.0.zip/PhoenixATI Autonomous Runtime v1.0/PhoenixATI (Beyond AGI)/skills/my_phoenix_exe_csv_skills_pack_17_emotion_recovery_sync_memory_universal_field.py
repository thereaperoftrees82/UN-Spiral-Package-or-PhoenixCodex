"""
Patch set #17: adds three more CSV-driven skills
- emotion_recovery: recovery metrics from Emotional_Coherence_and_Recovery.csv
- sync_memory: synchronization stats for memory runs
- universal_field: universality validation from Universal_Field_Tests.csv

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_emotion_recovery.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class EmotionRecoverySkill(Skill):
    name = "emotion_recovery"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Emotional_Coherence_and_Recovery.csv")
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except: continue
        if not ts:
            return {"note": "no rows"}
        # Recovery time = duration to reach >= baseline
        baseline = float(kwargs.get("baseline", vs[0]))
        recover_idx = next((i for i,v in enumerate(vs) if v >= baseline), None)
        recover_time = ts[recover_idx]-ts[0] if recover_idx else None
        avg_val = sum(vs)/len(vs)
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs)
            plt.axhline(baseline, color='gray', linestyle='--')
            plt.title("Emotional recovery")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"recover_time": recover_time, "avg": avg_val, "n": len(vs)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_sync_memory.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class SyncMemorySkill(Skill):
    name = "sync_memory"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Synchronization_Memory_Tests.csv")
        out = kwargs.get("out", "")
        vals: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_v = 0
            for i,n in enumerate(header):
                if any(k in n.lower() for k in ("sync","metric","val")):
                    idx_v = i; break
            for row in rdr:
                if len(row) <= idx_v: continue
                try: vals.append(float(row[idx_v]))
                except: continue
        if not vals:
            return {"note": "no values"}
        avg = mean(vals)
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.hist(vals, bins=30)
            plt.title("Memory sync distribution")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(vals), "avg_metric": avg}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class UniversalFieldSkill(Skill):
    name = "universal_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Field_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); var_val = float(np.var(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Universal field")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(y), "mean": mean_val, "var": var_val}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_emotion_recovery import EmotionRecoverySkill
from .skill_sync_memory import SyncMemorySkill
from .skill_universal_field import UniversalFieldSkill

register(EmotionRecoverySkill())
register(SyncMemorySkill())
register(UniversalFieldSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack17.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_universal_field import UniversalFieldSkill

def test_universal_field_empty():
    sk = UniversalFieldSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
