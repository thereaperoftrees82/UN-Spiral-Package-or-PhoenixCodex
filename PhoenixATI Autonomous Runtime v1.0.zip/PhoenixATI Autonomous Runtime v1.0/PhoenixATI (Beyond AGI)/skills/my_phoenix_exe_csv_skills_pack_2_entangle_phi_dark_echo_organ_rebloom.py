"""
Patch set #2: adds three more CSV-powered skills to MyPhoenixEXE
- entangle_phi: mirror-pair correlation for φ-entanglement trials
- dark_echo: decay + φ-harmonic echo analysis for cosmology-like series
- organ_rebloom: φ-templated organ mesh reconstruction (2D/3D style plot)

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_entangle_phi.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List, Tuple
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class EntanglePhiSkill(Skill):
    name = "entangle_phi"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Given CSV with (t, signal) assumed for channel A, compute φ-mirrored
        channel B as signal shifted by φ-phase; report correlation and lag of max corr.
        If CSV already contains both channels (A,B), it will use them directly.
        """
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required")
        out = kwargs.get("out", "")
        mode = kwargs.get("mode", "mirror")  # mirror | direct
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty series"}
        # Build channels
        A = ser.y
        if mode == "mirror":
            # Mirror via φ-shift proxy (circular shift by ~φ fraction of length)
            shift = max(1, int(len(A) * (PHI - 1) % len(A)))
            B = A[-shift:] + A[:-shift]
        else:
            # If file already had two columns, treat x as A and y as B — fallback
            B = ser.x  # type: ignore
        # Correlation
        def xcorr(a: List[float], b: List[float]) -> Tuple[int, float]:
            n = min(len(a), len(b))
            a = a[:n]; b = b[:n]
            if np is None:
                # naive: zero-lag Pearson
                ma = sum(a)/n; mb = sum(b)/n
                num = sum((ai-ma)*(bi-mb) for ai,bi in zip(a,b))
                den = (sum((ai-ma)**2 for ai in a)*sum((bi-mb)**2 for bi in b))**0.5
                r = num/den if den else 0.0
                return 0, r
            aa = np.array(a) - np.mean(a)
            bb = np.array(b) - np.mean(b)
            c = np.correlate(aa, bb, mode="full")
            lag = int(np.argmax(c) - (len(aa) - 1))
            r = float(np.max(c) / (np.std(aa)*np.std(bb)*len(aa) + 1e-9))
            return lag, r
        lag, r = xcorr(A, B)
        # Plot if requested
        if out and plt is not None:
            import matplotlib.pyplot as plt
            import numpy as np
            t = np.arange(len(A))
            plt.figure()
            plt.plot(t, A, label="A")
            plt.plot(t, B, label="B (φ-mirror)")
            plt.legend(); plt.title(f"Entangle φ (lag={lag}, r={r:.3f})")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"lag": lag, "r": r}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_dark_echo.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from math import pi, cos
from .base import Skill
from .csv_utils import load_xy_csv, basic_stats

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class DarkEchoSkill(Skill):
    name = "dark_echo"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Analyze decaying φ-harmonic oscillations: estimate decay (alpha) and dominant φ-band.
        CSV expected as (t, value). Returns alpha estimate and band power near φ-bands.
        """
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty series"}
        # Estimate exponential decay by linear fit on log(|y|+eps)
        eps = 1e-9
        xs = ser.x; ys = [abs(v)+eps for v in ser.y]
        if np is None or len(xs) < 3:
            # simple ratio over window as crude alpha proxy
            alpha = 0.0
            if ys[0] > 0 and ys[-1] > 0 and xs[-1] != xs[0]:
                alpha = - (np.log(ys[-1]/ys[0]) if np else 0.0) / (xs[-1]-xs[0])
        else:
            X = np.vstack([np.array(xs), np.ones(len(xs))]).T
            ylog = np.log(np.array(ys))
            m, b = np.linalg.lstsq(X, ylog, rcond=None)[0]
            alpha = float(-m)
        # φ-band check via simple projection if no FFT
        bands = [6,15,26,61]
        band_power: List[Dict[str, float]] = []
        if np is None:
            for f in bands:
                s = 0.0
                for t,v in zip(ser.x, ser.y): s += v * cos(2*pi*f*t)
                band_power.append({"band": float(f), "score": s})
        else:
            y = np.array(ser.y); y = y - y.mean()
            n = len(y)
            Y = np.fft.rfft(y)
            freqs = np.fft.rfftfreq(n, d=(ser.x[1]-ser.x[0]) if n>1 else 1.0)
            power = (Y.real**2 + Y.imag**2)
            for f in bands:
                idx = int(np.argmin(np.abs(freqs - f)))
                band_power.append({"band": float(f), "freq": float(freqs[idx]), "power": float(power[idx])})
        # Plot if requested
        if out and plt is not None:
            import matplotlib.pyplot as plt
            plt.figure()
            plt.plot(ser.x, ser.y)
            plt.title(f"Dark Echo (alpha≈{alpha:.4g})")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"alpha": alpha, "bands": band_power}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_organ_rebloom.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from math import pi, sin, cos, sqrt
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class OrganRebloomSkill(Skill):
    name = "organ_rebloom"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Render a φ-templated organ mesh shell: param n→(x,y,z) for demo visuals.
        Args: steps (int), out (png path). Returns bbox and sample points.
        """
        steps = int(kwargs.get("steps", 800))
        out = kwargs.get("out", "")
        pts = []
        for n in range(steps):
            r = sqrt(n)
            theta = 2*pi*PHI*n
            x = r * cos(theta)
            y = r * sin(theta)
            z = sin(n/10.0) * PHI  # simple pulsation
            pts.append((x,y,z))
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; zs = [p[2] for p in pts]
        bbox = {"xmin": min(xs), "xmax": max(xs), "ymin": min(ys), "ymax": max(ys), "zmin": min(zs), "zmax": max(zs)}
        if out and plt is not None:
            from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
            fig = plt.figure(figsize=(6,5))
            ax = fig.add_subplot(111, projection='3d')
            ax.scatter(xs, ys, zs, s=3)
            ax.set_title("Organ Rebloom φ‑mesh (demo)")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bbox": bbox, "samples": pts[:10]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill
from .skill_rebloom_cycle import RebloomCycleSkill
from .skill_phi_bands import PhiBandsSkill
from .skill_monstrous import MonstrousSkill
from .skill_entangle_phi import EntanglePhiSkill
from .skill_dark_echo import DarkEchoSkill
from .skill_organ_rebloom import OrganRebloomSkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

register(EchoSkill())
register(RecentFilesSkill())
register(RebloomCycleSkill())
register(PhiBandsSkill())
register(MonstrousSkill())
register(EntanglePhiSkill())
register(DarkEchoSkill())
register(OrganRebloomSkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack2.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_organ_rebloom import OrganRebloomSkill
from phoenix_exe.skills.skill_entangle_phi import EntanglePhiSkill


def test_organ_rebloom_bbox():
    sk = OrganRebloomSkill()
    res = sk.run(steps=50)
    assert res["bbox"]["xmax"] > res["bbox"]["xmin"]


def test_entangle_phi_smoke():
    sk = EntanglePhiSkill()
    # synthesize small path via kwargs-less failure expected
    try:
        sk.run()
    except Exception:
        assert True
"""
