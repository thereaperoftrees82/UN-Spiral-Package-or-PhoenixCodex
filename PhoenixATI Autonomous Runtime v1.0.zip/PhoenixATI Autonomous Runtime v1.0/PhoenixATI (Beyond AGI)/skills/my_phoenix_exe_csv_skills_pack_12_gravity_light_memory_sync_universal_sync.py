"""
Patch set #12: adds three more CSV-driven skills
- gravity_light: cross-harmonic comparison between gravity and light spectra
- memory_sync: synchronization metrics for memory tests (success rate, avg phase error)
- universal_sync: universality of sync metrics across domains

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_gravity_light.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class GravityLightSkill(Skill):
    name = "gravity_light"

    def _spectrum(self, path: str):
        ser = load_xy_csv(path)
        if np is None or len(ser.y) < 4:
            return None
        y = np.array(ser.y) - np.mean(ser.y)
        dt = (ser.x[1]-ser.x[0]) if len(ser.x) > 1 else 1.0
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=dt)
        power = (Y.real**2 + Y.imag**2)
        return freqs, power

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        g_path = kwargs.get("gravity_path")
        l_path = kwargs.get("light_path")
        if not g_path or not l_path:
            raise ValueError("gravity_path and light_path required")
        out = kwargs.get("out", "")
        gs = self._spectrum(g_path)
        ls = self._spectrum(l_path)
        if gs is None or ls is None:
            return {"note": "need numpy and >=4 samples"}
        gf, gp = gs; lf, lp = ls
        # Normalize and align onto common frequency grid (nearest matching)
        # Compare φ-band powers
        def band_power(freqs, power):
            out = {}
            for b in PHI_BANDS:
                idx = int(np.argmin(np.abs(freqs - b)))
                out[b] = float(power[idx])
            return out
        g_bands = band_power(gf, gp)
        l_bands = band_power(lf, lp)
        # Correlation across spectrum (coarse): resample to min length
        m = int(min(gp.size, lp.size))
        corr = float(np.corrcoef(gp[:m], lp[:m])[0,1])
        if out and plt is not None:
            plt.figure(figsize=(8,3))
            plt.plot(gf, gp/gp.max(), label='gravity')
            plt.plot(lf, lp/lp.max(), label='light', alpha=0.7)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.legend(); plt.title("Gravity vs Light spectra")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"phi_gravity": g_bands, "phi_light": l_bands, "spectrum_corr": corr}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_memory_sync.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class MemorySyncSkill(Skill):
    name = "memory_sync"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Memory_Synchronization_Tests.csv")
        out = kwargs.get("out", "")
        vals: list[float] = []  # phase error or sync metric
        succ: list[int] = []    # success flags optional
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_v = 0; idx_s = -1
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("phase","sync","error","metric")) and idx_v == 0:
                    idx_v = i
                if any(k in nl for k in ("success","ok","pass")):
                    idx_s = i
            for row in rdr:
                if len(row) <= idx_v: continue
                try: vals.append(float(row[idx_v]))
                except: continue
                if idx_s >= 0 and len(row) > idx_s:
                    try: succ.append(1 if float(row[idx_s])>0.5 else 0)
                    except: succ.append(0)
        if not vals:
            return {"note": "no values"}
        avg = mean(vals)
        success_rate = sum(succ)/len(succ) if succ else None
        if out and plt is not None:
            plt.figure(figsize=(6,3)); plt.hist(vals, bins=30)
            plt.title("Memory sync metric distribution")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(vals), "avg_metric": avg, "success_rate": success_rate}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_sync.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class UniversalSyncSkill(Skill):
    name = "universal_sync"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Synchronization_Tests.csv")
        out = kwargs.get("out", "")
        vals: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_v = 0
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("phase","sync","error","metric")) and idx_v == 0:
                    idx_v = i
            for row in rdr:
                if len(row) <= idx_v: continue
                try: vals.append(float(row[idx_v]))
                except: continue
        if not vals:
            return {"note": "no values"}
        avg = mean(vals)
        if out and plt is not None:
            plt.figure(figsize=(6,3)); plt.hist(vals, bins=30)
            plt.title("Universal sync metric distribution")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(vals), "avg_metric": avg}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_gravity_light import GravityLightSkill
from .skill_memory_sync import MemorySyncSkill
from .skill_universal_sync import UniversalSyncSkill

register(GravityLightSkill())
register(MemorySyncSkill())
register(UniversalSyncSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack12.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_memory_sync import MemorySyncSkill

def test_memory_sync_empty():
    sk = MemorySyncSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
