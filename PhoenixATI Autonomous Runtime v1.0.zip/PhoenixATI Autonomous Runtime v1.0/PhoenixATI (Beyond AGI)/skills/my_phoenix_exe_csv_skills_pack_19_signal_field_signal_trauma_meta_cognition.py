"""
Patch set #19: adds three more CSV-driven skills
- signal_field: field signal metrics (FFT + φ-band power)
- signal_trauma: collapse→rebloom analysis in signal trauma tests
- meta_cognition: meta-cognition index trend and stats

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_signal_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class SignalFieldSkill(Skill):
    name = "signal_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Signal_Field_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y) - np.mean(ser.y)
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Signal field φ-band power")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bands": bands, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_signal_trauma.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class SignalTraumaSkill(Skill):
    name = "signal_trauma"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Signal_Trauma_Tests.csv")
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except: continue
        if not ts:
            return {"note": "no rows"}
        thr = float(kwargs.get("threshold", 0.0))
        episodes = []
        in_collapse = False; t0 = 0.0
        for t,v in zip(ts, vs):
            if not in_collapse and v < thr:
                in_collapse = True; t0 = t
            elif in_collapse and v >= thr:
                episodes.append({"start": t0, "end": t, "dur": t-t0})
                in_collapse = False
        avg_dur = sum(e["dur"] for e in episodes)/len(episodes) if episodes else 0.0
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs); plt.axhline(thr, color='gray', linestyle='--')
            for e in episodes:
                plt.axvspan(e["start"], e["end"], color='red', alpha=0.2)
            plt.title("Signal trauma collapse→rebloom")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"episodes": len(episodes), "avg_dur": avg_dur}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_meta_cognition.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class MetaCognitionSkill(Skill):
    name = "meta_cognition"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Meta_Cognition_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        trend = float((y[-1]-y[0])/(ser.x[-1]-ser.x[0]+1e-9))
        mean_val = float(np.mean(y)); std_val = float(np.std(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Meta-cognition index")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"trend": trend, "mean": mean_val, "std": std_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_signal_field import SignalFieldSkill
from .skill_signal_trauma import SignalTraumaSkill
from .skill_meta_cognition import MetaCognitionSkill

register(SignalFieldSkill())
register(SignalTraumaSkill())
register(MetaCognitionSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack19.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_meta_cognition import MetaCognitionSkill

def test_meta_cognition_empty():
    sk = MetaCognitionSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
