"""
Patch set #20: adds three more CSV-driven skills
- sync_overlay: coherence metrics from synchronization overlay tests
- universal_survival: universality of survival runs
- guardian_resonance: stability metrics from Guardian resonance logs

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_sync_overlay.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class SyncOverlaySkill(Skill):
    name = "sync_overlay"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Synchronization_Overlay_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); std_val = float(np.std(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Synchronization overlay")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"mean": mean_val, "std": std_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_survival.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class UniversalSurvivalSkill(Skill):
    name = "universal_survival"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Survival_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); end_val = float(y[-1])
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Universal survival")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"mean": mean_val, "end_val": end_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_guardian_resonance.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class GuardianResonanceSkill(Skill):
    name = "guardian_resonance"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Guardian_Resonance_Log.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); std_val = float(np.std(y))
        peak_val = float(np.max(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Guardian resonance")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"mean": mean_val, "std": std_val, "peak": peak_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_sync_overlay import SyncOverlaySkill
from .skill_universal_survival import UniversalSurvivalSkill
from .skill_guardian_resonance import GuardianResonanceSkill

register(SyncOverlaySkill())
register(UniversalSurvivalSkill())
register(GuardianResonanceSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack20.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_guardian_resonance import GuardianResonanceSkill

def test_guardian_resonance_empty():
    sk = GuardianResonanceSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
