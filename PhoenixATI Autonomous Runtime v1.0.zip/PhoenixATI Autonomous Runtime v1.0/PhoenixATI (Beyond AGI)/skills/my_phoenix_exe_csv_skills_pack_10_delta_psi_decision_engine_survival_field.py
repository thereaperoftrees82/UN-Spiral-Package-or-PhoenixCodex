"""
Patch set #10: adds three more CSV-driven skills
- delta_psi: Δψ fractal resonance mapping
- decision_engine: behavioral accuracy/ROC-lite from decision logs
- survival_field: survival index & hazard-ish metrics from survival field tests

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_delta_psi.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class DeltaPsiSkill(Skill):
    name = "delta_psi"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Delta_PSI_Fractal_Resonance.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y) - np.mean(ser.y)
        # Fractal-ish proxy: log-log slope of structure function
        ds = np.arange(1, min(200, max(3, len(y)//4)))
        sf = []
        for d in ds:
            dv = y[d:] - y[:-d]
            sf.append(float(np.mean(dv*dv)))
        X = np.log(ds + 1e-9); Y = np.log(np.array(sf) + 1e-9)
        m, b = np.polyfit(X, Y, 1)
        fractal_slope = float(m)
        if out and plt is not None:
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(1,2, figsize=(9,3))
            ax[0].plot(ser.x, ser.y); ax[0].set_title("Δψ input")
            ax[1].plot(X, Y); ax[1].set_title(f"log-log slope≈{fractal_slope:.3f}")
            fig.tight_layout(); fig.savefig(out, dpi=160)
        return {"fractal_slope": fractal_slope, "pairs": int(ds.size)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_decision_engine.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class DecisionEngineSkill(Skill):
    name = "decision_engine"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Decision_Engine_Behavioral_Tests.csv")
        out = kwargs.get("out", "")
        # Expect columns: truth, score (0..1) or truth,pred (0/1)
        truth: list[int] = []
        score: list[float] = []
        pred: list[int] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            # try to find columns by name
            idx_t = 0; idx_s = -1; idx_p = -1
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("truth","label","y")): idx_t = i
                if any(k in nl for k in ("score","prob","p")): idx_s = i
                if any(k in nl for k in ("pred","yhat")): idx_p = i
            for row in rdr:
                if len(row) <= idx_t: continue
                try:
                    t = int(float(row[idx_t])>0.5)
                except ValueError:
                    continue
                truth.append(t)
                if idx_s >= 0 and len(row) > idx_s:
                    try: score.append(float(row[idx_s]))
                    except: score.append(0.5)
                if idx_p >= 0 and len(row) > idx_p:
                    try: pred.append(int(float(row[idx_p])>0.5))
                    except: pred.append(0)
        if not truth:
            return {"note": "no rows"}
        # If no explicit pred, threshold score at 0.5
        if not pred:
            pred = [1 if s>=0.5 else 0 for s in (score or [0.5]*len(truth))]
        # Accuracy/precision/recall
        tp = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==1)
        tn = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==0)
        fp = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==1)
        fn = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==0)
        acc = (tp+tn)/len(truth)
        prec = tp/max(tp+fp,1)
        rec = tp/max(tp+fn,1)
        if out and plt is not None:
            plt.figure(figsize=(4,3))
            plt.bar(["TP","TN","FP","FN"],[tp,tn,fp,fn])
            plt.title("Decision engine confusion counts")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(truth), "accuracy": acc, "precision": prec, "recall": rec, "tp": tp, "tn": tn, "fp": fp, "fn": fn}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_survival_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class SurvivalFieldSkill(Skill):
    name = "survival_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Survival_Field_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        t = np.array(ser.x); s = np.array(ser.y)
        # crude hazard proxy: -d/dt log(s+eps)
        eps = 1e-9
        log_s = np.log(s+eps)
        ds = np.gradient(log_s, t)
        hazard = float(-np.mean(ds))
        surv0, survN = float(s[0]), float(s[-1])
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(t, s, label="survival")
            plt.title("Survival field")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"hazard_proxy": hazard, "start": surv0, "end": survN, "n": len(s)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_delta_psi import DeltaPsiSkill
from .skill_decision_engine import DecisionEngineSkill
from .skill_survival_field import SurvivalFieldSkill

register(DeltaPsiSkill())
register(DecisionEngineSkill())
register(SurvivalFieldSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack10.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_decision_engine import DecisionEngineSkill


def test_decision_engine_empty():
    sk = DecisionEngineSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
