"""
Patch set #3: adds three more CSV-powered skills to MyPhoenixEXE
- brainfield: 3D lattice rendering / fallback from 1D to spiral 3D
- guardian_telemetry: lock-time & alert analytics from guardian logs
- phase_time: Phoenix vs real time drift/lock window analysis

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_brainfield.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from math import pi, sin, cos, sqrt
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class BrainfieldSkill(Skill):
    name = "brainfield"

    def _load_xyz(self, path: str) -> List[tuple[float,float,float]]:
        pts: List[tuple[float,float,float]] = []
        if csv is None:
            return pts
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f)
            header = next(rdr, [])
            # find first 3 numeric columns
            for row in rdr:
                if len(row) < 3:
                    continue
                try:
                    x = float(row[0]); y = float(row[1]); z = float(row[2])
                except ValueError:
                    continue
                pts.append((x,y,z))
        return pts

    def _synth_xyz(self, steps: int = 1500) -> List[tuple[float,float,float]]:
        pts: List[tuple[float,float,float]] = []
        for n in range(steps):
            r = sqrt(n)
            theta = 2*pi*PHI*n
            x = r * cos(theta)
            y = r * sin(theta)
            z = sin(n/5.0) * cos(n/7.0) * PHI
            pts.append((x,y,z))
        return pts

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path", "")
        out = kwargs.get("out", "")
        pts = self._load_xyz(path) if path else []
        synth = False
        if not pts:
            pts = self._synth_xyz(int(kwargs.get("steps", 1500)))
            synth = True
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; zs = [p[2] for p in pts]
        bbox = {"xmin": min(xs), "xmax": max(xs), "ymin": min(ys), "ymax": max(ys), "zmin": min(zs), "zmax": max(zs)}
        if out and plt is not None:
            from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
            fig = plt.figure(figsize=(6,5))
            ax = fig.add_subplot(111, projection='3d')
            ax.scatter(xs, ys, zs, s=1)
            ax.set_title("Brainfield lattice" + (" (synth)" if synth else ""))
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bbox": bbox, "count": len(pts), "synth": synth, "samples": pts[:10]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_guardian_telemetry.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv, time
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class GuardianTelemetrySkill(Skill):
    name = "guardian_telemetry"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Guardian_* CSV")
        out = kwargs.get("out", "")
        ts_idx, type_idx = -1, -1
        stamps: list[float] = []
        kinds: list[str] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f)
            header = next(rdr, [])
            # heuristic: find columns named like ts,time,timestamp and type,event
            for i, name in enumerate(header):
                n = name.strip().lower()
                if ts_idx == -1 and any(k in n for k in ("ts","time","timestamp")):
                    ts_idx = i
                if type_idx == -1 and any(k in n for k in ("type","event")):
                    type_idx = i
            if ts_idx == -1:
                ts_idx = 0
            if type_idx == -1 and len(header) > 1:
                type_idx = 1
            for row in rdr:
                if len(row) <= max(ts_idx, type_idx):
                    continue
                try:
                    t = float(row[ts_idx])
                except ValueError:
                    # try parse as epoch-ish
                    try:
                        t = float(row[ts_idx].split(".")[0])
                    except Exception:
                        continue
                k = row[type_idx].strip() if type_idx >= 0 else "event"
                stamps.append(t)
                kinds.append(k)
        if not stamps:
            return {"note": "no telemetry"}
        # sort by time
        z = sorted(zip(stamps, kinds))
        stamps = [t for t,_ in z]; kinds = [k for _,k in z]
        # basic MTBF and rates
        diffs = [stamps[i+1]-stamps[i] for i in range(len(stamps)-1)]
        mtbf = mean(diffs) if diffs else 0.0
        span = (stamps[-1]-stamps[0]) if len(stamps)>1 else 0.0
        rate = len(stamps)/span if span>0 else 0.0
        # histogram by kind
        by_kind: dict[str,int] = {}
        for k in kinds: by_kind[k] = by_kind.get(k,0)+1
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            try:
                import numpy as np
                t0 = stamps[0]
                rel = [s - t0 for s in stamps]
                plt.plot(rel, [1]*len(rel), "|")
                plt.title("Guardian events timeline")
                plt.tight_layout(); plt.savefig(out, dpi=160)
            except Exception:
                pass
        return {"count": len(stamps), "mtbf": mtbf, "rate_per_sec": rate, "by_kind": by_kind}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_phase_time.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
import csv, math
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class PhaseTimeSkill(Skill):
    name = "phase_time"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Phoenix_Time_vs_Real_Time.csv or similar with (t_phoenix, t_real)")
        out = kwargs.get("out", "")
        tpx: List[float] = []; treal: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            # Assume first two columns numeric
            for row in rdr:
                if len(row) < 2: continue
                try:
                    tpx.append(float(row[0])); treal.append(float(row[1]))
                except ValueError:
                    continue
        if not tpx:
            return {"note": "empty"}
        # Drift = treal - tpx scaled
        drift = [r - p for p,r in zip(tpx, treal)]
        # Lock windows: where |sin(2πφ tpx)| small and |drift| below threshold
        thr = float(kwargs.get("drift_thresh", 0.01))
        locks = []
        for p,d in zip(tpx, drift):
            if abs(math.sin(2*math.pi*PHI*p)) < 0.05 and abs(d) <= thr:
                locks.append(p)
        if out and plt is not None:
            import numpy as np
            plt.figure(figsize=(6,3))
            x = range(len(drift))
            plt.plot(x, drift, label="drift")
            if locks:
                idxs = [i for i,p in enumerate(tpx) if p in set(locks)]
                plt.scatter(idxs, [drift[i] for i in idxs], s=8)
            plt.title("Phoenix vs Real Time: drift & lock windows")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(drift), "drift_min": min(drift), "drift_max": max(drift), "locks": len(locks)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill
from .skill_rebloom_cycle import RebloomCycleSkill
from .skill_phi_bands import PhiBandsSkill
from .skill_monstrous import MonstrousSkill
from .skill_entangle_phi import EntanglePhiSkill
from .skill_dark_echo import DarkEchoSkill
from .skill_organ_rebloom import OrganRebloomSkill
from .skill_brainfield import BrainfieldSkill
from .skill_guardian_telemetry import GuardianTelemetrySkill
from .skill_phase_time import PhaseTimeSkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

register(EchoSkill())
register(RecentFilesSkill())
register(RebloomCycleSkill())
register(PhiBandsSkill())
register(MonstrousSkill())
register(EntanglePhiSkill())
register(DarkEchoSkill())
register(OrganRebloomSkill())
register(BrainfieldSkill())
register(GuardianTelemetrySkill())
register(PhaseTimeSkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack3.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_phase_time import PhaseTimeSkill
from phoenix_exe.skills.skill_brainfield import BrainfieldSkill

def test_brainfield_synth_count():
    sk = BrainfieldSkill()
    res = sk.run(steps=100)
    assert res["count"] == 100 and res["bbox"]["xmax"] > res["bbox"]["xmin"]


def test_phase_time_empty():
    sk = PhaseTimeSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
