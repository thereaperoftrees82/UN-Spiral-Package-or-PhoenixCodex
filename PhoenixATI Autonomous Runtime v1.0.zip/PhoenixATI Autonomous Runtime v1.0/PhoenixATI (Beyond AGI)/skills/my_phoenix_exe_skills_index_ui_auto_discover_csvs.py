"""
Extends Skills Index UI with auto-discovery of CSVs in settings.data_dir.
- Adds a CSV datalist to the Run form (type-ahead)
- Limits to first 500 files for performance
- Adds /ui/csvs to view the discovered list (debug)
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/server.py (extend UI with CSV discovery)
# ──────────────────────────────────────────────────────────────────────────────
from pathlib import Path

_MAX_CSV = 500

def _discover_csvs(root: str) -> list[str]:
    try:
        base = Path(root)
        if not base.exists():
            return []
        found: list[str] = []
        for p in base.rglob('*.csv'):
            rel = str(p.relative_to(base))
            found.append(str(p) if len(found) < 200 else rel)  # mix of abs/rel
            if len(found) >= _MAX_CSV:
                break
        return sorted(found)
    except Exception:
        return []

@app.get("/ui/csvs", response_class=HTMLResponse)
async def ui_csvs():
    files = _discover_csvs(settings.data_dir)
    items = "\n".join(f"<li>{f}</li>" for f in files)
    return f"""
<!doctype html><html><head><meta charset='utf-8'><title>CSV List</title>
<style>body{{font-family:system-ui,Segoe UI,Arial;margin:24px}}</style></head>
<body>
<h3>Discovered CSVs (root: {settings.data_dir}) — {len(files)} shown</h3>
<ol>{items}</ol>
<p><a href='/ui/index'>back to index</a></p>
</body></html>
"""

# Replace the existing ui_index() with CSV datalist support
@app.get("/ui/index", response_class=HTMLResponse)
async def ui_index():
    skills = all_skills()
    rows = []
    for s in skills:
        rows.append(f"<tr><td>{s}</td><td></td></tr>")
    table = "\n".join(rows)
    csvs = _discover_csvs(settings.data_dir)
    csv_options = "\n".join(f"<option value='{Path(c).as_posix()}'>" for c in csvs)
    return f"""
<!doctype html><html><head><meta charset='utf-8'>
<title>MyPhoenixEXE Skills Index</title>
<style>
body{{font-family:system-ui,Segoe UI,Arial;margin:24px}}
table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ccc;padding:4px}}
th{{background:#eee}}
input,select{{padding:6px;margin:4px}}
small{{color:#666}}
</style></head><body>
<h2>Skills Index</h2>
<p>Total skills: {len(skills)} · CSV root: <code>{settings.data_dir}</code> · <a href='/ui/csvs'>view CSV list</a></p>
<table><thead><tr><th>Skill</th><th>Description</th></tr></thead><tbody>
{table}
</tbody></table>
<hr>
<h3>Run a Skill</h3>
<form action='/ui/run_index' method='post'>
  <label>Skill:</label>
  <input name='skill' list='skills'>
  <datalist id='skills'>
    {"".join(f"<option value='{s}'>" for s in skills)}
  </datalist>
  <label>CSV path:</label>
  <input name='path' size='50' list='csvs' placeholder='./data/…'>
  <datalist id='csvs'>
    {csv_options}
  </datalist>
  <br>
  <label>Args (JSON dict):</label>
  <input name='args' size='60' placeholder='{"out":"./data/out.png","threshold":0.0}'>
  <button type='submit'>Run</button>
</form>
<small>Tip: Drop your CSVs into <code>{settings.data_dir}</code> to have them appear in the list (reload this page).</small>
</body></html>
"""
