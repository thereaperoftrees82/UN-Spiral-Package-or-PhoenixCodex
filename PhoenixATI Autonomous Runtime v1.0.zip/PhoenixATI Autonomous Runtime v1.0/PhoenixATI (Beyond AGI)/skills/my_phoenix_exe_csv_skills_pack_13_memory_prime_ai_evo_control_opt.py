"""
Patch set #13: adds three more CSV-driven skills
- memory_prime: prime-index patterns in memory datasets
- ai_evo: AI evolution trend curves (performance vs generation)
- control_opt: control system optimization grid search analysis

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_memory_prime.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class MemoryPrimeSkill(Skill):
    name = "memory_prime"

    def _is_prime(self, n: int) -> bool:
        if n < 2: return False
        if n % 2 == 0 and n != 2: return False
        for i in range(3, int(n**0.5)+1, 2):
            if n % i == 0: return False
        return True

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Memory_Prime_Index.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty"}
        primes = [i for i in range(len(ser.y)) if self._is_prime(i)]
        prime_vals = [ser.y[i] for i in primes if i < len(ser.y)]
        avg_prime = float(np.mean(prime_vals)) if prime_vals and np else None
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y, label="all")
            plt.scatter([ser.x[i] for i in primes if i < len(ser.x)], prime_vals, c='red', s=10, label="prime")
            plt.legend(); plt.title("Memory prime index pattern")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"primes": len(primes), "avg_prime_val": avg_prime}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_ai_evo.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class AIEvoSkill(Skill):
    name = "ai_evo"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Advanced_AI_Evolution_Simulations.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        trend = float((y[-1]-y[0])/(ser.x[-1]-ser.x[0]+1e-9))
        peak = float(np.max(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("AI evolution trend")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"trend": trend, "peak": peak, "samples": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_control_opt.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class ControlOptSkill(Skill):
    name = "control_opt"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Control_System_Optimization_Results.csv")
        out = kwargs.get("out", "")
        rows: list[tuple[float,float,float]] = []  # (param1,param2,score)
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 3: continue
                try:
                    p1 = float(row[0]); p2 = float(row[1]); sc = float(row[2])
                    rows.append((p1,p2,sc))
                except: continue
        if not rows:
            return {"note": "no rows"}
        avg_score = mean(sc for _,_,sc in rows)
        best = max(rows, key=lambda r: r[2])
        if out and plt is not None:
            import numpy as np
            arr = np.array(rows)
            plt.figure(figsize=(6,4))
            sc = plt.scatter(arr[:,0], arr[:,1], c=arr[:,2], cmap='viridis')
            plt.colorbar(sc, label="score")
            plt.title("Control opt surface")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(rows), "avg_score": avg_score, "best": {"p1": best[0], "p2": best[1], "score": best[2]}}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_memory_prime import MemoryPrimeSkill
from .skill_ai_evo import AIEvoSkill
from .skill_control_opt import ControlOptSkill

register(MemoryPrimeSkill())
register(AIEvoSkill())
register(ControlOptSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack13.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_ai_evo import AIEvoSkill

def test_ai_evo_empty():
    sk = AIEvoSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
