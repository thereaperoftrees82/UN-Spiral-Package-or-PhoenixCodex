"""
Extends Skills Index UI with auto-discovery of CSVs in ./data folder.
- /ui/index shows list of discovered CSVs below the skills table.
- Runner form has a dropdown of discovered CSV files to auto-fill the path.
"""

from fastapi.responses import HTMLResponse
from fastapi import Form
from .skills import all_skills
import inspect, os

@app.get("/ui/index", response_class=HTMLResponse)
async def ui_index():
    skills = all_skills()
    rows = []
    for s in skills:
        doc = ""
        try:
            mod = __import__(f"phoenix_exe.skills.skill_{s}", fromlist=["Skill"])
            cls = [c for c in mod.__dict__.values() if isinstance(c,type) and getattr(c,'name','')==s]
            if cls: doc = inspect.getdoc(cls[0]) or ""
        except Exception:
            pass
        rows.append(f"<tr><td>{s}</td><td>{doc.splitlines()[0] if doc else ''}</td></tr>")
    table = "\n".join(rows)

    # Discover CSVs
    data_dir = os.path.join(os.getcwd(), "data")
    csvs = []
    if os.path.isdir(data_dir):
        for fn in os.listdir(data_dir):
            if fn.lower().endswith(".csv"):
                csvs.append(fn)
    csv_opts = "\n".join(f"<option value='./data/{fn}'>{fn}</option>" for fn in csvs)

    return f"""
<!doctype html><html><head><meta charset='utf-8'>
<title>MyPhoenixEXE Skills Index</title>
<style>
body{{font-family:system-ui,Segoe UI,Arial;margin:24px}}
table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ccc;padding:4px}}
th{{background:#eee}}
</style></head><body>
<h2>Skills Index</h2>
<p>Total: {len(skills)}</p>
<table><thead><tr><th>Skill</th><th>Description</th></tr></thead><tbody>
{table}
</tbody></table>
<hr>
<h3>Run a Skill</h3>
<form action='/ui/run_index' method='post'>
<label>Skill:</label><input name='skill'>
<label>CSV path:</label><select name='path'><option value=''>--none--</option>{csv_opts}</select>
<label>Args (JSON dict):</label><input name='args' size='40'>
<button type='submit'>Run</button>
</form>
</body></html>
"""

@app.post("/ui/run_index", response_class=HTMLResponse)
async def ui_run_index(skill: str = Form(...), path: str = Form(""), args: str = Form("")):
    a = get_agent()
    try:
        kwargs = {}
        if path: kwargs["path"] = path
        if args:
            import json
            kwargs.update(json.loads(args))
        res = a.call_skill(skill, **kwargs)
    except Exception as e:
        res = {"error": str(e)}
    return f"<pre>{res}</pre><p><a href='/ui/index'>back</a></p>"
