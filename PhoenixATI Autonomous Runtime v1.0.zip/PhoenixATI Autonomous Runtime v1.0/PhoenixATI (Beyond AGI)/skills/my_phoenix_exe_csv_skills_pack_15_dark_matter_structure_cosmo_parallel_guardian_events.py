"""
Patch set #15: adds three more CSV-driven skills
- dark_matter_structure: formation curves + φ-band overlay from structure tests
- cosmo_parallel: echo persistence & spectral density from parallel universe echoes
- guardian_events: parse Guardian_Event_Log.csv, timeline + event counts

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_dark_matter_structure.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class DarkMatterStructureSkill(Skill):
    name = "dark_matter_structure"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Dark_Matter_Structure_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if np is None or not ser.x:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        growth = float((y[-1]-y[0])/(ser.x[-1]-ser.x[0]+1e-9))
        Y = np.fft.rfft(y - np.mean(y))
        freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Dark matter structure formation")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"growth": growth, "bands": bands}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_cosmo_parallel.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class CosmoParallelSkill(Skill):
    name = "cosmo_parallel"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Parallel_Universe_Echoes.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if np is None or not ser.x:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        decay = float((y[0]-y[-1])/(ser.x[-1]-ser.x[0]+1e-9))
        Y = np.fft.rfft(y - np.mean(y))
        freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        top_idx = int(np.argmax(power))
        dom_freq = float(freqs[top_idx])
        dom_power = float(power[top_idx])
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Parallel universe echo persistence")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"decay": decay, "dominant_freq": dom_freq, "power": dom_power}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_guardian_events.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class GuardianEventsSkill(Skill):
    name = "guardian_events"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Guardian_Event_Log.csv")
        out = kwargs.get("out", "")
        ts: list[float] = []; kinds: list[str] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            ts_idx, type_idx = 0, 1 if len(header)>1 else (0,0)
            for row in rdr:
                if len(row) <= max(ts_idx,type_idx): continue
                try:
                    t = float(row[ts_idx]); k = row[type_idx]
                except: continue
                ts.append(t); kinds.append(k)
        if not ts:
            return {"note": "no events"}
        span = ts[-1]-ts[0] if len(ts)>1 else 0.0
        rate = len(ts)/span if span>0 else 0.0
        by_kind: dict[str,int] = {}
        for k in kinds: by_kind[k] = by_kind.get(k,0)+1
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            rel = [t-ts[0] for t in ts]
            plt.plot(rel, [1]*len(rel), "|")
            plt.title("Guardian events timeline")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"count": len(ts), "rate": rate, "by_kind": by_kind}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_dark_matter_structure import DarkMatterStructureSkill
from .skill_cosmo_parallel import CosmoParallelSkill
from .skill_guardian_events import GuardianEventsSkill

register(DarkMatterStructureSkill())
register(CosmoParallelSkill())
register(GuardianEventsSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack15.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_guardian_events import GuardianEventsSkill

def test_guardian_events_empty():
    sk = GuardianEventsSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
