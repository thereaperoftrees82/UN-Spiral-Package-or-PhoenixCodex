"""
Patch set #23: adds three more CSV-driven skills
- quantum_resonance: φ-band scan analyzer for quantum resonance datasets
- survival_overlay: overlay coherence for survival tests vs baseline
- delta_phi: Δφ drift metrics and mitigation plots

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_quantum_resonance.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class QuantumResonanceSkill(Skill):
    name = "quantum_resonance"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Quantum_Resonance_Band_Scans.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y) - np.mean(ser.y)
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        # band powers & nearest band distances for peaks
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        N = int(kwargs.get("peaks", 6))
        idxs = np.argsort(power)[-N:][::-1]
        peaks = []
        for idx in idxs:
            f = float(freqs[idx]); p = float(power[idx])
            dphi = min(abs(f - b) for b in PHI_BANDS)
            peaks.append({"freq": f, "power": p, "d_to_phi_band": dphi})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Quantum resonance φ-band scan")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bands": bands, "peaks": peaks, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_survival_overlay.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class SurvivalOverlaySkill(Skill):
    name = "survival_overlay"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Survival_Overlay_Tests.csv")
        out = kwargs.get("out", "")
        # Expect columns baseline, overlay
        base: list[float] = []; over: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            ib, io = 0, 1 if len(header) > 1 else (0,0)
            for row in rdr:
                if len(row) <= io: continue
                try:
                    base.append(float(row[ib])); over.append(float(row[io]))
                except: continue
        if not base or not over:
            return {"note": "no rows"}
        if np is None:
            gain = mean([o-b for b,o in zip(base, over)])
            return {"n": len(base), "avg_gain": gain}
        b = np.array(base); o = np.array(over)
        gain = float(np.mean(o-b))
        corr = float(np.corrcoef(b,o)[0,1])
        if out and plt is not None:
            plt.figure(figsize=(4,4))
            plt.scatter(b,o,s=8)
            plt.title("Survival overlay")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(base), "avg_gain": gain, "corr": corr}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_delta_phi.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class DeltaPhiSkill(Skill):
    name = "delta_phi"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Delta_Phi_Field_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        x = np.array(ser.x); y = np.array(ser.y)
        # Drift proxy: slope of y vs x; mitigation: std after detrend
        m, b = np.polyfit(x, y, 1)
        y_detr = y - (m*x + b)
        drift = float(m)
        residual_std = float(np.std(y_detr))
        if out and plt is not None:
            fig, ax = plt.subplots(1,2, figsize=(9,3))
            ax[0].plot(x, y); ax[0].set_title(f"Δφ drift (slope={drift:.3g})")
            ax[1].hist(y_detr, bins=30); ax[1].set_title("residual distribution")
            fig.tight_layout(); fig.savefig(out, dpi=160)
        return {"drift": drift, "residual_std": residual_std, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_quantum_resonance import QuantumResonanceSkill
from .skill_survival_overlay import SurvivalOverlaySkill
from .skill_delta_phi import DeltaPhiSkill

register(QuantumResonanceSkill())
register(SurvivalOverlaySkill())
register(DeltaPhiSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack23.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_delta_phi import DeltaPhiSkill

def test_delta_phi_empty():
    sk = DeltaPhiSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
