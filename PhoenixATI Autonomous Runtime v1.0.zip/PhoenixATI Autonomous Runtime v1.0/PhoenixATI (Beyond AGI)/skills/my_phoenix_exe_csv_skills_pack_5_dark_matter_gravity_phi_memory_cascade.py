"""
Patch set #5: adds three more CSV/physics-powered skills to MyPhoenixEXE
- dark_matter: structure function & φ overlay from density/field series
- gravity_phi: harmonic peak finder for gravity-related spectra
- memory_cascade: collapse→propagation→recovery timeline metrics

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_dark_matter.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class DarkMatterSkill(Skill):
    name = "dark_matter"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Compute a simple structure function S(Δ) = ⟨(f(x+Δ)−f(x))^2⟩, report φ-band overlay on spectrum.
        CSV expected as (x, f). Returns structure minima, spectrum band powers.
        """
        path = kwargs.get("path")
        out = kwargs.get("out", "")
        if not path:
            raise ValueError("path required")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty series"}
        # Structure function
        if np is None:
            # discrete coarse Δs
            ds = list(range(1, min(50, len(ser.y)//4)))
            sf = []
            for d in ds:
                acc = 0.0; n = 0
                for i in range(len(ser.y)-d):
                    dv = ser.y[i+d]-ser.y[i]; acc += dv*dv; n += 1
                sf.append(acc/max(n,1))
        else:
            y = np.array(ser.y)
            ds = np.arange(1, min(200, max(2, len(y)//4)))
            sf = []
            for d in ds:
                dv = y[d:] - y[:-d]
                sf.append(float(np.mean(dv*dv)))
        # Spectrum & φ-band overlay
        bands = []
        if np is not None and len(ser.y) > 4:
            y = np.array(ser.y) - np.mean(ser.y)
            Y = np.fft.rfft(y)
            freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(y)>1 else 1.0)
            power = (Y.real**2 + Y.imag**2)
            for f in PHI_BANDS:
                idx = int(np.argmin(np.abs(freqs - f)))
                bands.append({"band": float(f), "freq": float(freqs[idx]), "power": float(power[idx])})
        if out and plt is not None:
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(1,2, figsize=(9,3))
            ax[0].plot(ds, sf); ax[0].set_title("Structure function S(Δ)")
            if bands and np is not None:
                ax[1].plot(freqs, power)
                for b in PHI_BANDS:
                    ax[1].axvline(b, alpha=0.2)
                ax[1].set_title("Spectrum with φ bands")
            fig.tight_layout(); fig.savefig(out, dpi=160)
        return {"structure_points": len(sf), "structure_min": min(sf) if sf else 0.0, "phi_bands": bands}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_gravity_phi.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class GravityPhiSkill(Skill):
    name = "gravity_phi"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Find harmonic peaks in gravity-related series and check φ-band proximity.
        CSV expected as (t, g). Returns peak freqs and closest φ-band distances.
        """
        path = kwargs.get("path")
        out = kwargs.get("out", "")
        if not path:
            raise ValueError("path required")
        ser = load_xy_csv(path)
        if np is None or len(ser.y) < 4:
            return {"note": "need numpy and >=4 samples"}
        y = np.array(ser.y) - np.mean(ser.y)
        dt = (ser.x[1]-ser.x[0]) if len(ser.x) > 1 else 1.0
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=dt)
        power = (Y.real**2 + Y.imag**2)
        # Find top-N peaks
        N = int(kwargs.get("peaks", 5))
        idxs = np.argsort(power)[-N:][::-1]
        peaks = []
        for idx in idxs:
            f = float(freqs[idx]); p = float(power[idx])
            dphi = min(abs(f - b) for b in PHI_BANDS)
            peaks.append({"freq": f, "power": p, "d_to_phi_band": dphi})
        if out and plt is not None:
            import matplotlib.pyplot as plt
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Gravity φ harmonics")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"peaks": peaks}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_memory_cascade.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class MemoryCascadeSkill(Skill):
    name = "memory_cascade"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Analyze collapse→propagation→recovery cascades from a log with (t, state) or (t, value) and threshold.
        Args: path, threshold (float), out.
        Returns counts and average durations for collapse/recovery episodes.
        """
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required")
        thr = float(kwargs.get("threshold", 0.0))
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except ValueError:
                    continue
        if not ts:
            return {"note": "empty"}
        # Define collapse when value < thr; recovery when back >= thr
        episodes = []
        in_collapse = False; t0 = 0.0
        for t,v in zip(ts, vs):
            if not in_collapse and v < thr:
                in_collapse = True; t0 = t
            elif in_collapse and v >= thr:
                episodes.append({"start": t0, "end": t, "dur": t - t0})
                in_collapse = False
        avg = sum(e["dur"] for e in episodes)/len(episodes) if episodes else 0.0
        if out and plt is not None:
            import matplotlib.pyplot as plt
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs); plt.axhline(thr, color='gray', linestyle='--')
            for e in episodes:
                plt.axvspan(e["start"], e["end"], color='red', alpha=0.2)
            plt.title("Memory cascade")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"episodes": len(episodes), "avg_dur": avg, "samples": episodes[:10]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill
from .skill_rebloom_cycle import RebloomCycleSkill
from .skill_phi_bands import PhiBandsSkill
from .skill_monstrous import MonstrousSkill
from .skill_entangle_phi import EntanglePhiSkill
from .skill_dark_echo import DarkEchoSkill
from .skill_organ_rebloom import OrganRebloomSkill
from .skill_brainfield import BrainfieldSkill
from .skill_guardian_telemetry import GuardianTelemetrySkill
from .skill_phase_time import PhaseTimeSkill
from .skill_hyperstar_loop import HyperstarLoopSkill
from .skill_utphi1_node import UTPhi1NodeSkill
from .skill_guardian_anomaly import GuardianAnomalySkill
from .skill_dark_matter import DarkMatterSkill
from .skill_gravity_phi import GravityPhiSkill
from .skill_memory_cascade import MemoryCascadeSkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

register(EchoSkill())
register(RecentFilesSkill())
register(RebloomCycleSkill())
register(PhiBandsSkill())
register(MonstrousSkill())
register(EntanglePhiSkill())
register(DarkEchoSkill())
register(OrganRebloomSkill())
register(BrainfieldSkill())
register(GuardianTelemetrySkill())
register(PhaseTimeSkill())
register(HyperstarLoopSkill())
register(UTPhi1NodeSkill())
register(GuardianAnomalySkill())
register(DarkMatterSkill())
register(GravityPhiSkill())
register(MemoryCascadeSkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack5.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_dark_matter import DarkMatterSkill
from phoenix_exe.skills.skill_memory_cascade import MemoryCascadeSkill


def test_dark_matter_empty():
    sk = DarkMatterSkill()
    try:
        sk.run()
    except Exception:
        assert True


def test_memory_cascade_empty():
    sk = MemoryCascadeSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
