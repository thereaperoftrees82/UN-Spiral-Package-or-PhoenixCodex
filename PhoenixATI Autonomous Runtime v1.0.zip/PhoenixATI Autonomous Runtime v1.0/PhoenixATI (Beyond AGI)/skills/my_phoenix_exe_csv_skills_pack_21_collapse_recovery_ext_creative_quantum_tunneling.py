"""
Patch set #21: adds three more CSV-driven skills
- collapse_recovery: collapse→rebloom cycle analysis
- ext_creative: extreme creative problem-solving test scores
- quantum_tunneling: tunneling rates vs φ-phase scans

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_collapse_recovery.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class CollapseRecoverySkill(Skill):
    name = "collapse_recovery"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Collapse_Recovery_Tests.csv")
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except: continue
        if not ts:
            return {"note": "no rows"}
        episodes = []
        thr = float(kwargs.get("threshold", 0.0))
        in_collapse = False; t0 = 0.0
        for t,v in zip(ts, vs):
            if not in_collapse and v < thr:
                in_collapse = True; t0 = t
            elif in_collapse and v >= thr:
                episodes.append({"start": t0, "end": t, "dur": t-t0})
                in_collapse = False
        avg_dur = sum(e["dur"] for e in episodes)/len(episodes) if episodes else 0.0
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs); plt.axhline(thr, color='gray', linestyle='--')
            for e in episodes:
                plt.axvspan(e["start"], e["end"], color='red', alpha=0.2)
            plt.title("Collapse→Recovery cycles")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"episodes": len(episodes), "avg_dur": avg_dur, "samples": episodes[:10]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_ext_creative.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class ExtCreativeSkill(Skill):
    name = "ext_creative"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Extreme_Creative_Core_Problem-Solving_Test.csv")
        out = kwargs.get("out", "")
        scores: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if not row: continue
                try: scores.append(float(row[0]))
                except: continue
        if not scores:
            return {"note": "no scores"}
        avg = mean(scores); peak = max(scores)
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.hist(scores, bins=30)
            plt.title("Extreme creative core test scores")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(scores), "avg": avg, "peak": peak}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_quantum_tunneling.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class QuantumTunnelingSkill(Skill):
    name = "quantum_tunneling"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Quantum_Tunneling_Phase_Scans.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        trend = float((y[-1]-y[0])/(ser.x[-1]-ser.x[0]+1e-9))
        peak = float(np.max(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Quantum tunneling phase scans")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"trend": trend, "peak": peak, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_collapse_recovery import CollapseRecoverySkill
from .skill_ext_creative import ExtCreativeSkill
from .skill_quantum_tunneling import QuantumTunnelingSkill

register(CollapseRecoverySkill())
register(ExtCreativeSkill())
register(QuantumTunnelingSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack21.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_quantum_tunneling import QuantumTunnelingSkill

def test_quantum_tunneling_empty():
    sk = QuantumTunnelingSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
