"""
Patch set #4: adds three more CSV/physics-powered skills to MyPhoenixEXE
- hyperstar_loop: simulate PHX997 adaptive gain + QS256 saturation + PLL tuning; contours
- utphi1_node: φ‑filter jitter suppression + phase‑safe load curves
- guardian_anomaly: anomaly scoring + alert thresholds from Guardian index CSV

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_hyperstar_loop.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, Tuple

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

from .base import Skill

class HyperstarLoopSkill(Skill):
    name = "hyperstar_loop"

    def _simulate(self, As0: float, alpha: float, pll_kp: float, pll_ki: float, steps: int = 2000) -> Tuple[float, float, float]:
        """Return (lock_time, overshoot, final_eta). Simple discrete loop:
        - field energy E[k+1] = E[k] + As(E) - loss(E) + noise
        - As(E) = As0 / (1 + alpha*E)  (adaptive gain)
        - QS256 saturation: clamp E to soft ceiling via tanh
        - PLL phase error reduced by PI controller acting on recomb factor eta
        """
        if np is None:
            return 0.0, 0.0, 0.0
        E = 0.0
        eta = 0.2
        integ = 0.0
        lock = 0
        overshoot = 0.0
        for k in range(1, steps+1):
            As = As0 / (1.0 + alpha*max(E, 0.0))
            # soft saturation like QS256
            E = E + As - 0.02*E
            E = np.tanh(E)
            # phase error ~ 1-eta, PI update
            err = 1.0 - eta
            integ += err
            eta += pll_kp*err + pll_ki*integ*1e-3
            eta = float(np.clip(eta, 0.0, 1.0))
            if eta > 0.95 and lock == 0:
                lock = k
            overshoot = max(overshoot, E)
        lock_time = float(lock)
        final_eta = float(eta)
        return lock_time, overshoot, final_eta

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        As0 = float(kwargs.get("As0", 2.56))
        alpha = float(kwargs.get("alpha", 0.1))
        kp = float(kwargs.get("kp", 0.08))
        ki = float(kwargs.get("ki", 0.02))
        grid = int(kwargs.get("grid", 25))
        out = kwargs.get("out", "")
        if np is None or grid <= 1:
            lt, os_, eta = self._simulate(As0, alpha, kp, ki)
            return {"lock_time": lt, "overshoot": os_, "final_eta": eta}
        # contour of lock_time over kp/ki
        Kp = np.linspace(kp*0.25, kp*2.0, grid)
        Ki = np.linspace(ki*0.25, ki*2.0, grid)
        Z = np.zeros((grid, grid))
        for i,a in enumerate(Kp):
            for j,b in enumerate(Ki):
                lt, _, _ = self._simulate(As0, alpha, a, b)
                Z[j,i] = lt if lt>0 else np.nan
        if out and plt is not None:
            X, Y = np.meshgrid(Kp, Ki)
            plt.figure(figsize=(6,4))
            cs = plt.contourf(X, Y, Z, levels=12)
            plt.colorbar(cs, label="lock time")
            plt.xlabel("kp"); plt.ylabel("ki")
            plt.title("Hyperstar lock-time contours")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        finite = np.isfinite(Z)
        min_lt = float(np.nanmin(Z)) if np.any(finite) else 0.0
        return {"grid": grid, "min_lock_time": min_lt}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_utphi1_node.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

from .base import Skill

class UTPhi1NodeSkill(Skill):
    name = "utphi1_node"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        """Model UT‑Φ1 jitter filtering + phase‑safe load curve.
        Inputs: jitter_rms, cutoff_hz, load_set, steps. Returns filtered jitter, stability score.
        """
        jitter = float(kwargs.get("jitter_rms", 0.02))
        cutoff = float(kwargs.get("cutoff_hz", 10.0))
        load_set = float(kwargs.get("load_set", 0.7))
        steps = int(kwargs.get("steps", 2000))
        out = kwargs.get("out", "")
        if np is None:
            return {"note": "numpy not available"}
        t = np.linspace(0, 10, steps)
        # incoming jitter as colored noise
        rng = np.random.default_rng(42)
        n = rng.normal(0, jitter, size=steps)
        # φ-harmonic filter kernel (simple low-pass approx)
        from numpy.fft import rfft, irfft, rfftfreq
        N = len(n)
        Nf = rfft(n)
        freqs = rfftfreq(N, d=t[1]-t[0])
        H = 1.0/(1.0 + (freqs/cutoff)**2)
        nf = irfft(Nf*H, n=N)
        # phase‑safe load curve: track to setpoint with soft limiter
        load = np.zeros_like(nf)
        for i in range(1, N):
            err = load_set - load[i-1]
            load[i] = load[i-1] + 0.05*err - 0.01*nf[i]  # suppress jitter
            # soft bounds
            load[i] = np.tanh(load[i])
        filt_rms = float(np.sqrt(np.mean(nf**2)))
        stab = float(1.0 - abs(load[-1]-load_set))
        if out and plt is not None:
            plt.figure(figsize=(6,4))
            plt.plot(t, n, alpha=0.4, label="in jitter")
            plt.plot(t, nf, alpha=0.8, label="filtered")
            plt.plot(t, load, label="load")
            plt.legend(); plt.title("UT‑Φ1 filter & load")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"filtered_jitter_rms": filt_rms, "stability": stab, "load_final": float(load[-1])}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_guardian_anomaly.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean, pstdev
from .base import Skill

class GuardianAnomalySkill(Skill):
    name = "guardian_anomaly"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Guardian_Strand_Anomaly_Index.csv")
        thresh = float(kwargs.get("z_thresh", 3.0))
        scores = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            # find first numeric column named like score/anomaly/index
            idx = 0
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("score","anomaly","index")):
                    idx = i; break
            for row in rdr:
                if len(row) <= idx: continue
                try:
                    v = float(row[idx])
                except ValueError:
                    continue
                scores.append(v)
        if not scores:
            return {"note": "no scores"}
        mu = mean(scores)
        sd = pstdev(scores) if len(scores) > 1 else 0.0
        alerts = []
        for i,v in enumerate(scores):
            z = (v - mu) / (sd + 1e-9)
            if z >= thresh:
                alerts.append({"idx": i, "value": v, "z": z})
        return {"count": len(scores), "mean": mu, "stdev": sd, "alerts": alerts[:100]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill
from .skill_rebloom_cycle import RebloomCycleSkill
from .skill_phi_bands import PhiBandsSkill
from .skill_monstrous import MonstrousSkill
from .skill_entangle_phi import EntanglePhiSkill
from .skill_dark_echo import DarkEchoSkill
from .skill_organ_rebloom import OrganRebloomSkill
from .skill_brainfield import BrainfieldSkill
from .skill_guardian_telemetry import GuardianTelemetrySkill
from .skill_phase_time import PhaseTimeSkill
from .skill_hyperstar_loop import HyperstarLoopSkill
from .skill_utphi1_node import UTPhi1NodeSkill
from .skill_guardian_anomaly import GuardianAnomalySkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

register(EchoSkill())
register(RecentFilesSkill())
register(RebloomCycleSkill())
register(PhiBandsSkill())
register(MonstrousSkill())
register(EntanglePhiSkill())
register(DarkEchoSkill())
register(OrganRebloomSkill())
register(BrainfieldSkill())
register(GuardianTelemetrySkill())
register(PhaseTimeSkill())
register(HyperstarLoopSkill())
register(UTPhi1NodeSkill())
register(GuardianAnomalySkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack4.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_hyperstar_loop import HyperstarLoopSkill
from phoenix_exe.skills.skill_utphi1_node import UTPhi1NodeSkill


def test_hyperstar_single():
    sk = HyperstarLoopSkill()
    res = sk.run(As0=2.56, alpha=0.1, kp=0.08, ki=0.02, grid=0)
    assert "final_eta" in res or "min_lock_time" in res


def test_utphi1_returns():
    sk = UTPhi1NodeSkill()
    res = sk.run()
    assert "stability" in res or "note" in res
"""
