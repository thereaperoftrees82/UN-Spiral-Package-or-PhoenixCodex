"""
Patch set #14: adds three more CSV-driven skills
- entanglement_stress: correlation persistence under noise; φ-band alignment optional
- observer_bias: outcome bias vs emotional amplitude (regression)
- dark_energy: decay (alpha) + φ-harmonic echo power from dark-energy logs

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_entanglement_stress.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
import csv
from statistics import mean
from .base import Skill

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class EntanglementStressSkill(Skill):
    name = "entanglement_stress"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Quantum_Entanglement_Stress_Tests.csv")
        out = kwargs.get("out", "")
        # Expect columns: A, B, (optional) noise
        A: List[float] = []; B: List[float] = []; noise: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_a, idx_b, idx_n = 0, 1, -1
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("a","ch_a","channel_a")): idx_a = i
                if any(k in nl for k in ("b","ch_b","channel_b")): idx_b = i
                if any(k in nl for k in ("noise","snr")): idx_n = i
            for row in rdr:
                if len(row) <= idx_b: continue
                try:
                    av = float(row[idx_a]); bv = float(row[idx_b])
                except ValueError:
                    continue
                A.append(av); B.append(bv)
                if idx_n >= 0 and len(row) > idx_n:
                    try: noise.append(float(row[idx_n]))
                    except: pass
        if not A or not B:
            return {"note": "no channels"}
        if np is None:
            # zero-lag Pearson
            n = min(len(A), len(B))
            ma = mean(A[:n]); mb = mean(B[:n])
            num = sum((A[i]-ma)*(B[i]-mb) for i in range(n))
            den = (sum((A[i]-ma)**2 for i in range(n))*sum((B[i]-mb)**2 for i in range(n)))**0.5
            r0 = num/den if den else 0.0
            return {"corr": r0, "n": n}
        a = np.array(A); b = np.array(B)
        a = a - a.mean(); b = b - b.mean()
        corr = float(np.corrcoef(a, b)[0,1])
        # Optional φ-band alignment: FFT of A and check band powers
        bands = []
        if len(a) > 4:
            Ya = np.fft.rfft(a); fa = np.fft.rfftfreq(len(a), d=1.0)
            pa = (Ya.real**2 + Ya.imag**2)
            for f in PHI_BANDS:
                j = int(np.argmin(np.abs(fa - f)))
                bands.append({"band": float(f), "power": float(pa[j])})
        if out and plt is not None:
            import matplotlib.pyplot as plt
            plt.figure(figsize=(4,3))
            plt.scatter(a, b, s=6)
            plt.title(f"Entanglement stress r={corr:.3f}")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"corr": corr, "bands_A": bands, "n": int(len(a))}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_observer_bias.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class ObserverBiasSkill(Skill):
    name = "observer_bias"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Observer_Effect_Emotion_Bias.csv")
        out = kwargs.get("out", "")
        # Expect columns: emotion_amp, outcome (numeric or 0/1)
        emo: list[float] = []; outc: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            i_e, i_o = 0, 1 if len(header)>1 else (0, 0)
            for row in rdr:
                if len(row) <= i_o: continue
                try:
                    emo.append(float(row[i_e])); outc.append(float(row[i_o]))
                except ValueError:
                    continue
        if not emo or not outc:
            return {"note": "no rows"}
        if np is None:
            # simple Pearson
            m1, m2 = mean(emo), mean(outc)
            num = sum((e-m1)*(o-m2) for e,o in zip(emo, outc))
            den = (sum((e-m1)**2 for e in emo)*sum((o-m2)**2 for o in outc))**0.5
            r = num/den if den else 0.0
            return {"n": len(emo), "r": r}
        x = np.array(emo); y = np.array(outc)
        X = np.vstack([x, np.ones(len(x))]).T
        m, b = np.linalg.lstsq(X, y, rcond=None)[0]
        r = float(np.corrcoef(x, y)[0,1])
        if out and plt is not None:
            plt.figure(figsize=(4,3))
            plt.scatter(x, y, s=6)
            xs = np.linspace(float(x.min()), float(x.max()), 50)
            ys = m*xs + b
            plt.plot(xs, ys, 'r-')
            plt.title(f"Observer bias r={r:.3f}")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(emo), "slope": float(m), "intercept": float(b), "r": r}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_dark_energy.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from math import pi, cos
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class DarkEnergySkill(Skill):
    name = "dark_energy"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Dark_Energy_Simulation_Log.csv or Dark_Energy_Field_Echo.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty"}
        # decay alpha
        eps = 1e-9
        if np is None or len(ser.x) < 3:
            alpha = 0.0
        else:
            xs = np.array(ser.x); ys = np.abs(np.array(ser.y))+eps
            X = np.vstack([xs, np.ones(len(xs))]).T
            ylog = np.log(ys)
            m, b = np.linalg.lstsq(X, ylog, rcond=None)[0]
            alpha = float(-m)
        # φ-band power (projection without FFT if numpy absent)
        bands = []
        if np is None:
            for f in PHI_BANDS:
                s = 0.0
                for t,v in zip(ser.x, ser.y): s += v * cos(2*pi*f*t)
                bands.append({"band": float(f), "score": s})
        else:
            y = np.array(ser.y) - np.mean(ser.y)
            Y = np.fft.rfft(y); freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
            power = (Y.real**2 + Y.imag**2)
            for f in PHI_BANDS:
                j = int(np.argmin(np.abs(freqs - f)))
                bands.append({"band": float(f), "freq": float(freqs[j]), "power": float(power[j])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title(f"Dark energy (alpha≈{alpha:.4g})")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"alpha": alpha, "bands": bands, "n": len(ser.y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_entanglement_stress import EntanglementStressSkill
from .skill_observer_bias import ObserverBiasSkill
from .skill_dark_energy import DarkEnergySkill

register(EntanglementStressSkill())
register(ObserverBiasSkill())
register(DarkEnergySkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack14.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_observer_bias import ObserverBiasSkill

def test_observer_bias_empty():
    sk = ObserverBiasSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
