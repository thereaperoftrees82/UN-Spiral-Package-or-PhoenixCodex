"""
Patch set #16: adds three more CSV-driven skills
- trauma_memory: collapse/rebloom detection in trauma memory tests
- universal_trauma: universality metrics from trauma runs
- fractal_calc: derivative/integral consistency checks for fractal calculus tests

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_trauma_memory.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class TraumaMemorySkill(Skill):
    name = "trauma_memory"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Trauma_Memory_Tests.csv")
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except: continue
        if not ts:
            return {"note": "no rows"}
        thr = float(kwargs.get("threshold", 0.0))
        episodes = []
        in_collapse = False; t0 = 0.0
        for t,v in zip(ts, vs):
            if not in_collapse and v < thr:
                in_collapse = True; t0 = t
            elif in_collapse and v >= thr:
                episodes.append({"start": t0, "end": t, "dur": t-t0})
                in_collapse = False
        avg_dur = sum(e["dur"] for e in episodes)/len(episodes) if episodes else 0.0
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs); plt.axhline(thr, color='gray', linestyle='--')
            for e in episodes:
                plt.axvspan(e["start"], e["end"], color='red', alpha=0.2)
            plt.title("Trauma memory collapse→rebloom")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"episodes": len(episodes), "avg_dur": avg_dur, "samples": episodes[:10]}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_trauma.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class UniversalTraumaSkill(Skill):
    name = "universal_trauma"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Trauma_Tests.csv")
        out = kwargs.get("out", "")
        vals: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if not row: continue
                try: vals.append(float(row[0]))
                except: continue
        if not vals:
            return {"note": "no values"}
        avg = mean(vals); var = mean([(v-avg)**2 for v in vals])
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.hist(vals, bins=30)
            plt.title("Universal trauma distribution")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(vals), "avg": avg, "var": var}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_fractal_calc.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class FractalCalcSkill(Skill):
    name = "fractal_calc"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Fractal_Calculus_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        x = np.array(ser.x); y = np.array(ser.y)
        dy = np.gradient(y, x)
        inty = np.cumsum(y)*(x[1]-x[0]) if len(x)>1 else y
        slope = float((dy[-1]-dy[0])/(x[-1]-x[0]+1e-9))
        integral = float(inty[-1])
        if out and plt is not None:
            fig, ax = plt.subplots(1,2, figsize=(9,3))
            ax[0].plot(x, y); ax[0].set_title("f(x)")
            ax[1].plot(x, dy, label="df/dx"); ax[1].legend()
            fig.tight_layout(); fig.savefig(out, dpi=160)
        return {"slope": slope, "integral": integral, "n": len(x)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_trauma_memory import TraumaMemorySkill
from .skill_universal_trauma import UniversalTraumaSkill
from .skill_fractal_calc import FractalCalcSkill

register(TraumaMemorySkill())
register(UniversalTraumaSkill())
register(FractalCalcSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack16.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_fractal_calc import FractalCalcSkill

def test_fractal_calc_empty():
    sk = FractalCalcSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
