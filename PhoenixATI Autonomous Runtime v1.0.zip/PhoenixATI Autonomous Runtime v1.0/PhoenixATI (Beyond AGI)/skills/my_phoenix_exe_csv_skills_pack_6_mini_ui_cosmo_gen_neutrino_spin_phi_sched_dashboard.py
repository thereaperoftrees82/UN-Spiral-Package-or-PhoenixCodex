"""
Patch set #6: adds two more skills + a tiny web UI to run skills from the browser
- cosmo_gen: seed → φ-structure growth (synthetic or from CSV)
- neutrino_spin: spin-state harmonics + φ-band alignment from time series
- phi_sched_dashboard: simple HTML upload + run interface at /ui

Notes
- Adds python-multipart to enable file uploads via FastAPI.
"""

# ──────────────────────────────────────────────────────────────────────────────
# pyproject.toml (append dependency)
# ──────────────────────────────────────────────────────────────────────────────
# Add to [project].dependencies list:
#   "python-multipart>=0.0.9",

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_cosmo_gen.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from math import pi, sin, cos, sqrt
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class CosmoGenSkill(Skill):
    name = "cosmo_gen"

    def _load_seeds(self, path: str) -> List[float]:
        seeds: List[float] = []
        if csv is None:
            return seeds
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f)
            header = next(rdr, [])
            for row in rdr:
                if not row: continue
                try:
                    seeds.append(float(row[0]))
                except ValueError:
                    continue
        return seeds

    def _grow(self, seeds: List[float] | None, steps: int) -> List[tuple[float,float]]:
        pts: List[tuple[float,float]] = []
        if not seeds:
            seeds = [1.0]
        for s in seeds:
            for n in range(steps):
                r = sqrt(s * (n+1))
                theta = 2*pi*PHI*(n+1)
                x = r * cos(theta)
                y = r * sin(theta)
                pts.append((x,y))
        return pts

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path", "")
        steps = int(kwargs.get("steps", 1500))
        out = kwargs.get("out", "")
        seeds = self._load_seeds(path) if path else []
        pts = self._grow(seeds, steps)
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        bbox = {"xmin": min(xs), "xmax": max(xs), "ymin": min(ys), "ymax": max(ys)}
        if out and plt is not None:
            plt.figure(figsize=(6,6))
            plt.scatter(xs, ys, s=0.6)
            plt.title("Cosmological φ-structure (seed→growth)")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"seeds": seeds[:10], "bbox": bbox, "count": len(pts)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_neutrino_spin.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class NeutrinoSpinSkill(Skill):
    name = "neutrino_spin"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: (t, value) CSV for spin state")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if np is None or len(ser.y) < 4:
            return {"note": "need numpy and >=4 samples"}
        y = np.array(ser.y) - np.mean(ser.y)
        dt = (ser.x[1]-ser.x[0]) if len(ser.x) > 1 else 1.0
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=dt)
        power = (Y.real**2 + Y.imag**2)
        # Dominant spin peaks
        N = int(kwargs.get("peaks", 6))
        idxs = np.argsort(power)[-N:][::-1]
        peaks = []
        for idx in idxs:
            f = float(freqs[idx]); p = float(power[idx])
            dphi = min(abs(f - b) for b in PHI_BANDS)
            peaks.append({"freq": f, "power": p, "d_to_phi_band": dphi})
        # φ-band alignment power
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Neutrino spin harmonics")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"peaks": peaks, "phi_bands": bands}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/server.py (append mini UI)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import HTMLResponse, RedirectResponse
import os, uuid
from .config import settings
from .agent import get_agent
from .models import SayRequest, RememberRequest, TaskResult, SkillCall, RunMode
from .skills import all_skills

# Existing app and endpoints remain unchanged above…

@app.get("/ui", response_class=HTMLResponse)
async def ui_index():
    skills = all_skills()
    return """
<!doctype html><html><head><meta charset='utf-8'><title>MyPhoenixEXE</title>
<style>body{font-family:system-ui,Segoe UI,Arial;margin:24px}input,select{padding:6px;margin:4px}</style>
</head><body>
<h2>MyPhoenixEXE — Skills Runner</h2>
<form action="/ui/upload" method="post" enctype="multipart/form-data">
  <label>Upload CSV (optional):</label>
  <input type="file" name="file">
  <button type="submit">Upload</button>
</form>
<hr>
<form action="/ui/run" method="post">
  <label>Skill:</label>
  <select name="skill">
    %s
  </select>
  <label>CSV path (server):</label>
  <input type="text" name="path" placeholder="./data/example.csv" size="40">
  <label>PNG out (optional):</label>
  <input type="text" name="out" placeholder="./data/out.png" size="30">
  <button type="submit">Run</button>
</form>
</body></html>
""" % ("\n".join(f"<option value='{s}'>{s}</option>" for s in skills))

@app.post("/ui/upload")
async def ui_upload(file: UploadFile = File(...)):
    os.makedirs(settings.data_dir, exist_ok=True)
    fn = f"{uuid.uuid4().hex}_{file.filename}"
    dest = os.path.join(settings.data_dir, fn)
    with open(dest, "wb") as f:
        f.write(await file.read())
    return RedirectResponse(url=f"/ui", status_code=303)

@app.post("/ui/run", response_class=HTMLResponse)
async def ui_run(skill: str = Form(...), path: str = Form(""), out: str = Form("")):
    a = get_agent()
    try:
        res = a.call_skill(skill, **({"path": path} if path else {}), **({"out": out} if out else {}))
    except Exception as e:
        res = {"error": str(e)}
    return f"<pre>{res}</pre><p><a href='/ui'>back</a></p>"

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register cosmo_gen + neutrino_spin)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
# (imports for previously registered skills remain)
from .skill_cosmo_gen import CosmoGenSkill
from .skill_neutrino_spin import NeutrinoSpinSkill

# …existing _registry, register(), and earlier registrations…
register(CosmoGenSkill())
register(NeutrinoSpinSkill())

"""
