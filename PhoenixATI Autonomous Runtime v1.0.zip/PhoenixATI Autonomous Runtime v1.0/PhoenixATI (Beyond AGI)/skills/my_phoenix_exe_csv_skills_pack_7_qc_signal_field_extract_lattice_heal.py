"""
Patch set #7: adds three more CSV/field-powered skills to MyPhoenixEXE
- qc_signal: extract signal-to-noise for Quantum Consciousness series
- field_extract: generic consciousness-field SNR + φ-band analyzer
- lattice_heal: healing rate vs φ-bands from lattice CSV

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_qc_signal.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class QCSignalSkill(Skill):
    name = "qc_signal"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Quantum_Consciousness_Signal.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty"}
        if np is None or len(ser.y) < 4:
            snr = 0.0
        else:
            y = np.array(ser.y)
            power = np.mean(y**2)
            noise = np.var(y - np.mean(y))
            snr = float(10*np.log10(power/(noise+1e-9)))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title(f"QC signal SNR={snr:.2f} dB")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"snr_db": snr, "samples": len(ser.y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_field_extract.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class FieldExtractSkill(Skill):
    name = "field_extract"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Consciousness_Field_Signal_Extraction.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty"}
        bands = []
        if np is not None and len(ser.y) > 4:
            y = np.array(ser.y) - np.mean(ser.y)
            Y = np.fft.rfft(y)
            freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
            power = (Y.real**2 + Y.imag**2)
            for b in PHI_BANDS:
                idx = int(np.argmin(np.abs(freqs - b)))
                bands.append({"band": float(b), "power": float(power[idx])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Field extract")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bands": bands, "n": len(ser.y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_lattice_heal.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class LatticeHealSkill(Skill):
    name = "lattice_heal"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Lattice_Field_Healing.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"note": "empty"}
        if np is None:
            return {"note": "need numpy"}
        y = np.array(ser.y)
        heal_rate = float((y[-1]-y[0]) / (ser.x[-1]-ser.x[0]+1e-9))
        # detect φ-band peaks
        Y = np.fft.rfft(y - y.mean())
        freqs = np.fft.rfftfreq(len(y), d=(ser.x[1]-ser.x[0]) if len(ser.x)>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        bands = []
        for b in [6,15,26,61]:
            idx = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[idx])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Lattice healing")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"heal_rate": heal_rate, "bands": bands}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_qc_signal import QCSignalSkill
from .skill_field_extract import FieldExtractSkill
from .skill_lattice_heal import LatticeHealSkill

register(QCSignalSkill())
register(FieldExtractSkill())
register(LatticeHealSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack7.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_qc_signal import QCSignalSkill
from phoenix_exe.skills.skill_field_extract import FieldExtractSkill


def test_qc_signal_empty():
    sk = QCSignalSkill()
    try:
        sk.run()
    except Exception:
        assert True


def test_field_extract_empty():
    sk = FieldExtractSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
