"""
Patch set #11: adds three more CSV-driven skills
- light_field: light structure harmonics + φ-band overlay
- sync_field: synchronization success metrics from sync tests
- universal_overlay: overlay coherence vs baseline across domains

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_light_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class LightFieldSkill(Skill):
    name = "light_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Light_Field_Tests.csv or Light_Structure_Simulations.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if np is None or len(ser.y) < 4:
            return {"note": "need numpy and >=4 samples"}
        y = np.array(ser.y) - np.mean(ser.y)
        dt = (ser.x[1]-ser.x[0]) if len(ser.x) > 1 else 1.0
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=dt)
        power = (Y.real**2 + Y.imag**2)
        # top peaks + φ distances
        N = int(kwargs.get("peaks", 6))
        idxs = np.argsort(power)[-N:][::-1]
        peaks = []
        for idx in idxs:
            f = float(freqs[idx]); p = float(power[idx])
            dphi = min(abs(f - b) for b in PHI_BANDS)
            peaks.append({"freq": f, "power": p, "d_to_phi_band": dphi})
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Light field harmonics")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"peaks": peaks, "phi_bands": bands}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_sync_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class SyncFieldSkill(Skill):
    name = "sync_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Synchronization_Field_Tests.csv")
        out = kwargs.get("out", "")
        # Expect columns: phase_error or sync_metric; success flag optional
        vals: list[float] = []
        succ: list[int] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_v = 0; idx_s = -1
            for i,n in enumerate(header):
                nl = n.lower()
                if any(k in nl for k in ("phase","sync","error","metric")) and idx_v == 0:
                    idx_v = i
                if any(k in nl for k in ("success","ok","pass")):
                    idx_s = i
            for row in rdr:
                if len(row) <= idx_v: continue
                try:
                    vals.append(float(row[idx_v]))
                except ValueError:
                    continue
                if idx_s >= 0 and len(row) > idx_s:
                    try: succ.append(1 if float(row[idx_s])>0.5 else 0)
                    except: succ.append(0)
        if not vals:
            return {"note": "no values"}
        avg = mean(vals)
        success_rate = sum(succ)/len(succ) if succ else None
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            try:
                import numpy as np
                import matplotlib.pyplot as plt
                plt.hist(vals, bins=30)
                plt.title("Synchronization metric distribution")
                plt.tight_layout(); plt.savefig(out, dpi=160)
            except Exception:
                pass
        return {"n": len(vals), "avg_metric": avg, "success_rate": success_rate}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_overlay.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class UniversalOverlaySkill(Skill):
    name = "universal_overlay"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Overlay_Tests.csv")
        out = kwargs.get("out", "")
        # Expect columns: baseline, overlay (numeric)
        base: list[float] = []
        over: list[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            ib, io = 0, 1 if len(header) > 1 else (0, 0)
            for row in rdr:
                if len(row) <= max(ib,io): continue
                try:
                    base.append(float(row[ib])); over.append(float(row[io]))
                except ValueError:
                    continue
        if not base or not over:
            return {"note": "no rows"}
        if np is None:
            # simple stats
            gain = mean([o-b for b,o in zip(base, over)])
            return {"n": len(base), "avg_gain": gain}
        b = np.array(base); o = np.array(over)
        gain = float(np.mean(o-b))
        corr = float(np.corrcoef(b,o)[0,1])
        if out and plt is not None:
            plt.figure(figsize=(4,4))
            plt.scatter(b,o,s=8)
            plt.title("Universal overlay")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(base), "avg_gain": gain, "corr": corr}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_light_field import LightFieldSkill
from .skill_sync_field import SyncFieldSkill
from .skill_universal_overlay import UniversalOverlaySkill

register(LightFieldSkill())
register(SyncFieldSkill())
register(UniversalOverlaySkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack11.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_universal_overlay import UniversalOverlaySkill

def test_universal_overlay_empty():
    sk = UniversalOverlaySkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
