"""
Patch set #24: adds three more CSV-driven skills (final trio before index UI)
- gravity_harmonics: gravity-band peaks & φ alignment
- universal_decision: aggregate decision metrics across domains
- phoenix_time_compare: dedicated Phoenix vs real-time comparer (drift & locks)

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_gravity_harmonics.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class GravityHarmonicsSkill(Skill):
    name = "gravity_harmonics"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Gravity_Field_Harmonics.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if np is None or len(ser.y) < 4:
            return {"note": "need numpy and >=4 samples"}
        y = np.array(ser.y) - np.mean(ser.y)
        dt = (ser.x[1]-ser.x[0]) if len(ser.x) > 1 else 1.0
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(len(y), d=dt)
        power = (Y.real**2 + Y.imag**2)
        # Band powers + top-N peaks & φ-distance
        bands = []
        for b in PHI_BANDS:
            j = int(np.argmin(np.abs(freqs - b)))
            bands.append({"band": float(b), "power": float(power[j])})
        N = int(kwargs.get("peaks", 6))
        idxs = np.argsort(power)[-N:][::-1]
        peaks = []
        for idx in idxs:
            f = float(freqs[idx]); p = float(power[idx])
            dphi = min(abs(f - b) for b in PHI_BANDS)
            peaks.append({"freq": f, "power": p, "d_to_phi_band": dphi})
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(freqs, power)
            for b in PHI_BANDS: plt.axvline(b, alpha=0.2)
            plt.title("Gravity field harmonics")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"bands": bands, "peaks": peaks, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_decision.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class UniversalDecisionSkill(Skill):
    name = "universal_decision"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Decision_Tests.csv")
        out = kwargs.get("out", "")
        truth: list[int] = []
        pred: list[int] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_t, idx_p = 0, 1 if len(header)>1 else (0,0)
            for row in rdr:
                if len(row) <= idx_p: continue
                try:
                    truth.append(int(float(row[idx_t])>0.5))
                    pred.append(int(float(row[idx_p])>0.5))
                except: continue
        if not truth:
            return {"note": "no rows"}
        tp = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==1)
        tn = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==0)
        fp = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==1)
        fn = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==0)
        acc = (tp+tn)/len(truth)
        prec = tp/max(tp+fp,1)
        rec = tp/max(tp+fn,1)
        if out and plt is not None:
            plt.figure(figsize=(4,3))
            plt.bar(["TP","TN","FP","FN"],[tp,tn,fp,fn])
            plt.title("Universal decision tests")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(truth), "accuracy": acc, "precision": prec, "recall": rec,
                "tp": tp, "tn": tn, "fp": fp, "fn": fn}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_phoenix_time_compare.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
import csv, math
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

PHI = (1 + 5 ** 0.5) / 2.0

class PhoenixTimeCompareSkill(Skill):
    name = "phoenix_time_compare"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Phoenix_Time_vs_Real_Time.csv")
        out = kwargs.get("out", "")
        tpx: List[float] = []; treal: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    tpx.append(float(row[0])); treal.append(float(row[1]))
                except: continue
        if not tpx:
            return {"note": "empty"}
        drift = [r - p for p,r in zip(tpx, treal)]
        thr = float(kwargs.get("drift_thresh", 0.01))
        locks = []
        for p,d in zip(tpx, drift):
            if abs(math.sin(2*math.pi*PHI*p)) < 0.05 and abs(d) <= thr:
                locks.append(p)
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(range(len(drift)), drift)
            plt.title("Phoenix vs real time drift")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(drift), "drift_min": min(drift), "drift_max": max(drift), "locks": len(locks)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_gravity_harmonics import GravityHarmonicsSkill
from .skill_universal_decision import UniversalDecisionSkill
from .skill_phoenix_time_compare import PhoenixTimeCompareSkill

register(GravityHarmonicsSkill())
register(UniversalDecisionSkill())
register(PhoenixTimeCompareSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack24.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_phoenix_time_compare import PhoenixTimeCompareSkill

def test_phoenix_time_compare_empty():
    sk = PhoenixTimeCompareSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
