"""
Patch set: adds three CSV-powered skills to MyPhoenixEXE
- rebloom_cycle: collapse→rebloom analysis from a time-series CSV
- phi_bands: φ-band power analyzer (6, 15, 26, 61)
- monstrous: verify Monstrous Number thresholds and plot regime boundaries

Includes small utils, registrations, and optional plotting (matplotlib). If matplotlib
is not installed, skills return numeric summaries only.

Apply these diffs to the scaffold created earlier.
"""

# ──────────────────────────────────────────────────────────────────────────────
# pyproject.toml (append dependencies)
# ──────────────────────────────────────────────────────────────────────────────
# Add to [project].dependencies list:
#   "pandas>=2.0",
#   "matplotlib>=3.8",

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/config.py (add data_root)
# ──────────────────────────────────────────────────────────────────────────────
# Insert into Settings:
#     data_root: str = Field(default=os.getenv("PHOENIX_DATA_ROOT", "./data"))

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/csv_utils.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
import csv, math, os
from dataclasses import dataclass
from typing import List, Dict, Tuple

@dataclass
class Series:
    x: List[float]
    y: List[float]
    cols: Tuple[str, str]


def load_xy_csv(path: str) -> Series:
    """Load a two-column (x,y) CSV or multi-column where the first numeric two are used.
    Returns numeric x,y; non-numeric rows are skipped.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    x: List[float] = []
    y: List[float] = []
    cols: Tuple[str, str] = ("x", "y")
    with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        rdr = csv.reader(f)
        header: List[str] = []
        try:
            header = next(rdr)
        except StopIteration:
            return Series([], [], ("x","y"))
        # pick first two numeric-like columns
        idxs: List[int] = []
        for i, name in enumerate(header):
            idxs.append(i)
        # heuristic: use first two columns
        i0, i1 = idxs[0], idxs[1] if len(idxs) > 1 else (0, 1)
        cols = (header[i0], header[i1])
        for row in rdr:
            if len(row) <= max(i0, i1):
                continue
            try:
                xv = float(row[i0])
                yv = float(row[i1])
            except ValueError:
                continue
            x.append(xv)
            y.append(yv)
    return Series(x, y, cols)


def basic_stats(vals: List[float]) -> Dict[str, float]:
    if not vals:
        return {"min": 0.0, "max": 0.0, "mean": 0.0}
    vmin = min(vals); vmax = max(vals)
    mean = sum(vals) / len(vals)
    return {"min": vmin, "max": vmax, "mean": mean}


def moving_minima(y: List[float], w: int = 5) -> List[float]:
    out: List[float] = []
    n = len(y)
    for i in range(n):
        a = max(0, i - w)
        b = min(n, i + w + 1)
        out.append(min(y[a:b]))
    return out

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_rebloom_cycle.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
import os
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv, basic_stats, moving_minima

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:  # plotting optional
    plt = None  # type: ignore

class RebloomCycleSkill(Skill):
    name = "rebloom_cycle"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: CSV with two columns (t, value)")
        out = kwargs.get("out", "")
        window = int(kwargs.get("window", 5))
        ser = load_xy_csv(path)
        stats = basic_stats(ser.y)
        mins = moving_minima(ser.y, w=window)
        # detect collapse (local minima) and rebloom (recover above median)
        median = sorted(ser.y)[len(ser.y)//2] if ser.y else 0.0
        events = []
        for i, (t, v, m) in enumerate(zip(ser.x, ser.y, mins)):
            if v <= m and v < median:
                events.append({"t": t, "kind": "collapse", "v": v})
        # plot if requested and matplotlib present
        if out and plt is not None and ser.x:
            plt.figure()
            plt.plot(ser.x, ser.y)
            plt.plot(ser.x, mins)
            plt.xlabel(ser.cols[0])
            plt.ylabel(ser.cols[1])
            plt.title("Rebloom Cycle")
            plt.tight_layout()
            plt.savefig(out, dpi=160)
        return {"stats": stats, "events": events[:50], "count": len(events)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_phi_bands.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
import math
from typing import Dict, Any, List
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

PHI_BANDS = [6, 15, 26, 61]

class PhiBandsSkill(Skill):
    name = "phi_bands"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: time-series CSV (t, value)")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x:
            return {"bands": [], "note": "empty series"}
        if np is None:
            # simple band proxy: sample sin(2π f t) correlation
            scores: List[Dict[str, float]] = []
            for f in PHI_BANDS:
                s = 0.0
                for t, v in zip(ser.x, ser.y):
                    s += v * math.sin(2 * math.pi * f * t)
                scores.append({"band": float(f), "score": s})
            return {"bands": scores}
        # FFT power spectrum
        y = np.array(ser.y)
        y = y - y.mean()
        n = len(y)
        Y = np.fft.rfft(y)
        freqs = np.fft.rfftfreq(n, d=(ser.x[1]-ser.x[0]) if n>1 else 1.0)
        power = (Y.real**2 + Y.imag**2)
        hits: List[Dict[str, float]] = []
        for f in PHI_BANDS:
            # nearest bin
            idx = int(np.argmin(np.abs(freqs - f)))
            hits.append({"band": float(f), "freq": float(freqs[idx]), "power": float(power[idx])})
        if out and plt is not None:
            plt.figure()
            plt.plot(freqs, power)
            plt.xlabel("frequency")
            plt.ylabel("power")
            plt.title("φ-band power")
            plt.tight_layout()
            plt.savefig(out, dpi=160)
        return {"bands": hits}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_monstrous.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

MONSTROUS_SET = [13, 584, 914, 1443, 2295, 3669, 5885, 9466, 15254, 24613, 39751, 64238, 103853, 167943, 271637]

class MonstrousSkill(Skill):
    name = "monstrous"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: CSV with thresholds or index,value columns")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        # verify known thresholds appear in y (or x)
        hits = [m for m in MONSTROUS_SET if (m in ser.y) or (m in ser.x)]
        if out and plt is not None and ser.x:
            plt.figure()
            plt.plot(ser.x, ser.y)
            # mark thresholds if within range
            for m in MONSTROUS_SET:
                try:
                    plt.axhline(m)
                except Exception:
                    pass
            plt.xlabel(ser.cols[0]); plt.ylabel(ser.cols[1])
            plt.title("Monstrous thresholds")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"monstrous_hits": hits, "known": MONSTROUS_SET}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict
from .base import Skill
from .builtin_echo import EchoSkill
from .builtin_files import RecentFilesSkill
from .skill_rebloom_cycle import RebloomCycleSkill
from .skill_phi_bands import PhiBandsSkill
from .skill_monstrous import MonstrousSkill

_registry: Dict[str, Skill] = {}

def register(skill: Skill) -> None:
    _registry[skill.name] = skill

# Register built‑ins
register(EchoSkill())
register(RecentFilesSkill())
register(RebloomCycleSkill())
register(PhiBandsSkill())
register(MonstrousSkill())


def get(name: str) -> Skill | None:
    return _registry.get(name)


def all_skills() -> list[str]:
    return sorted(_registry.keys())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_csv_utils.py (tiny tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.csv_utils import basic_stats, moving_minima

def test_basic_stats():
    s = basic_stats([1,2,3])
    assert s["min"] == 1 and s["max"] == 3 and abs(s["mean"]-2.0) < 1e-9

def test_moving_minima_simple():
    arr = [3,2,1,2,3]
    mins = moving_minima(arr, w=1)
    assert mins[2] == 1 and mins[0] == 2
"""
