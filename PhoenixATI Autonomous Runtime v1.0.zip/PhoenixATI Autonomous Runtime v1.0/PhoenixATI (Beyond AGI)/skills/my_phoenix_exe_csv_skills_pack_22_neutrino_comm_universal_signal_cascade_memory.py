"""
Patch set #22: adds three more CSV-driven skills
- neutrino_comm: phase-lock success & jitter tolerance in neutrino comms
- universal_signal: universality of signal tests
- cascade_memory: cascade failure/rebloom detection in memory tests

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_neutrino_comm.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class NeutrinoCommSkill(Skill):
    name = "neutrino_comm"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Neutrino_Comm_Phase_Lock_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        lock_rate = float(np.mean(y > 0.5))
        jitter_tol = float(np.std(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Neutrino comm phase-lock")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"lock_rate": lock_rate, "jitter_tol": jitter_tol, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_signal.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class UniversalSignalSkill(Skill):
    name = "universal_signal"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Signal_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); std_val = float(np.std(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Universal signal")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"mean": mean_val, "std": std_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_cascade_memory.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any, List
from .base import Skill

try:
    import csv
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    csv = None  # type: ignore
    plt = None  # type: ignore

class CascadeMemorySkill(Skill):
    name = "cascade_memory"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Cascade_Memory_Tests.csv")
        out = kwargs.get("out", "")
        ts: List[float] = []; vs: List[float] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            for row in rdr:
                if len(row) < 2: continue
                try:
                    ts.append(float(row[0])); vs.append(float(row[1]))
                except: continue
        if not ts:
            return {"note": "no rows"}
        thr = float(kwargs.get("threshold", 0.0))
        fails = 0; recovs = 0
        in_fail = False
        for t,v in zip(ts,vs):
            if not in_fail and v < thr:
                in_fail = True; fails += 1
            elif in_fail and v >= thr:
                in_fail = False; recovs += 1
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ts, vs); plt.axhline(thr, color='gray', linestyle='--')
            plt.title("Cascade memory failures")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"fails": fails, "recovs": recovs, "n": len(ts)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_neutrino_comm import NeutrinoCommSkill
from .skill_universal_signal import UniversalSignalSkill
from .skill_cascade_memory import CascadeMemorySkill

register(NeutrinoCommSkill())
register(UniversalSignalSkill())
register(CascadeMemorySkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack22.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_cascade_memory import CascadeMemorySkill

def test_cascade_memory_empty():
    sk = CascadeMemorySkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
