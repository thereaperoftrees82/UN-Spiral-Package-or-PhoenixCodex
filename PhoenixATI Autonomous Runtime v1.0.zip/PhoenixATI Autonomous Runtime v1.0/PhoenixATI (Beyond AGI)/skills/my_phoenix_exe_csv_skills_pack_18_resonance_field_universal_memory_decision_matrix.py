"""
Patch set #18: adds three more CSV-driven skills
- resonance_field: parse resonance logs, report peaks
- universal_memory: universality tests for memory metrics
- decision_matrix: behavioral accuracy/ROC-like metrics from matrix tests

Optional plotting via matplotlib; numeric summaries always returned.
"""

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_resonance_field.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class ResonanceFieldSkill(Skill):
    name = "resonance_field"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Resonance_Field_Log.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        peak_val = float(np.max(y))
        peak_idx = int(np.argmax(y))
        peak_t = float(ser.x[peak_idx]) if peak_idx < len(ser.x) else None
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.axvline(peak_t, color='red', linestyle='--')
            plt.title("Resonance field log")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"peak_val": peak_val, "peak_time": peak_t, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_universal_memory.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
from .base import Skill
from .csv_utils import load_xy_csv

try:
    import numpy as np  # type: ignore
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    np = None  # type: ignore
    plt = None  # type: ignore

class UniversalMemorySkill(Skill):
    name = "universal_memory"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Universal_Memory_Tests.csv")
        out = kwargs.get("out", "")
        ser = load_xy_csv(path)
        if not ser.x or np is None:
            return {"note": "empty or need numpy"}
        y = np.array(ser.y)
        mean_val = float(np.mean(y)); std_val = float(np.std(y))
        if out and plt is not None:
            plt.figure(figsize=(6,3))
            plt.plot(ser.x, ser.y)
            plt.title("Universal memory tests")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"mean": mean_val, "std": std_val, "n": len(y)}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/skill_decision_matrix.py
# ──────────────────────────────────────────────────────────────────────────────
from __future__ import annotations
from typing import Dict, Any
import csv
from statistics import mean
from .base import Skill

try:
    import matplotlib.pyplot as plt  # type: ignore
except Exception:
    plt = None  # type: ignore

class DecisionMatrixSkill(Skill):
    name = "decision_matrix"

    def run(self, **kwargs: Any) -> Dict[str, Any]:
        path = kwargs.get("path")
        if not path:
            raise ValueError("path required: Decision_Matrix_Tests.csv")
        out = kwargs.get("out", "")
        truth: list[int] = []
        pred: list[int] = []
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            rdr = csv.reader(f); header = next(rdr, [])
            idx_t, idx_p = 0, 1 if len(header)>1 else (0,0)
            for row in rdr:
                if len(row) <= idx_p: continue
                try:
                    truth.append(int(float(row[idx_t])>0.5))
                    pred.append(int(float(row[idx_p])>0.5))
                except: continue
        if not truth:
            return {"note": "no rows"}
        tp = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==1)
        tn = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==0)
        fp = sum(1 for y,ph in zip(truth, pred) if y==0 and ph==1)
        fn = sum(1 for y,ph in zip(truth, pred) if y==1 and ph==0)
        acc = (tp+tn)/len(truth)
        prec = tp/max(tp+fp,1)
        rec = tp/max(tp+fn,1)
        if out and plt is not None:
            plt.figure(figsize=(4,3))
            plt.bar(["TP","TN","FP","FN"],[tp,tn,fp,fn])
            plt.title("Decision matrix results")
            plt.tight_layout(); plt.savefig(out, dpi=160)
        return {"n": len(truth), "accuracy": acc, "precision": prec, "recall": rec,
                "tp": tp, "tn": tn, "fp": fp, "fn": fn}

# ──────────────────────────────────────────────────────────────────────────────
# phoenix_exe/skills/__init__.py (register new skills)
# ──────────────────────────────────────────────────────────────────────────────
from .skill_resonance_field import ResonanceFieldSkill
from .skill_universal_memory import UniversalMemorySkill
from .skill_decision_matrix import DecisionMatrixSkill

register(ResonanceFieldSkill())
register(UniversalMemorySkill())
register(DecisionMatrixSkill())

# ──────────────────────────────────────────────────────────────────────────────
# tests/test_skills_pack18.py (smoke tests)
# ──────────────────────────────────────────────────────────────────────────────
from phoenix_exe.skills.skill_resonance_field import ResonanceFieldSkill

def test_resonance_field_empty():
    sk = ResonanceFieldSkill()
    try:
        sk.run()
    except Exception:
        assert True
"""
